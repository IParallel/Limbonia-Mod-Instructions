#!/usr/bin/env python
"""Draw the placeholder character that ships in Assets/CustomCharacter/Sprites/.

It exists so a fresh copy of this project BUILDS AND WORKS before you have drawn
anything. Press the button once, watch a blue stick figure swing a sword in a
real battle, and you know the whole chain -- Unity, the bundle, mod.json,
Limbonia, the curve binding path -- is fine. Then delete these files and put your
own art in the same folders.

Every frame is drawn feet-down and centred, because the build imports sprites
with a bottom-centre pivot (0.5, 0) and that is what puts the character's feet on
the floor line and on the ground in game.

    pip install Pillow
    python make_example_art.py
"""

from __future__ import annotations

import math
import os
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    raise SystemExit("Pillow is not installed:  pip install Pillow")

W, H = 460, 460
BODY_W = 220
SKIN = (232, 220, 205, 255)
BODY = (86, 122, 178, 255)
DARK = (44, 60, 92, 255)
BLADE = (214, 222, 235, 255)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "Assets", "CustomCharacter", "Sprites")

def figure(draw, *, lean=0.0, crouch=0.0, arm=-60.0, leg_split=0.20, blade=None, bob=0.0):
    """One frame of a very plain humanoid, feet on the bottom edge of the canvas.

    lean       -- how far the whole body tips forward, in pixels at the head
    crouch     -- 0..1, how much shorter the legs get
    arm        -- weapon-arm angle in degrees (0 = straight right, -90 = straight up)
    leg_split  -- how far apart the feet are, as a fraction of the width
    blade      -- length of the sword in pixels, or None for no weapon
    bob        -- vertical offset of everything above the feet
    """
    cx = W / 2.0
    ground = H - 4
    hip_y = ground - (150 - 40 * crouch) + bob
    shoulder_y = hip_y - 105
    head_y = shoulder_y - 34

    def tilt(y, x):
        f = max(0.0, (hip_y - y) / 150.0)
        return x + lean * f

    foot = BODY_W * leg_split
    draw.line([(cx, hip_y), (tilt(ground, cx) - foot, ground)], fill=DARK, width=16)
    draw.line([(cx, hip_y), (tilt(ground, cx) + foot, ground)], fill=DARK, width=16)

    draw.line([(cx, hip_y), (tilt(shoulder_y, cx), shoulder_y)], fill=BODY, width=44)

    draw.line([(tilt(shoulder_y, cx), shoulder_y),
               (tilt(shoulder_y, cx) - 34, shoulder_y + 46)], fill=BODY, width=14)

    a = math.radians(arm)
    sx, sy = tilt(shoulder_y, cx), shoulder_y
    hx, hy = sx + math.cos(a) * 62, sy + math.sin(a) * 62
    draw.line([(sx, sy), (hx, hy)], fill=BODY, width=14)
    if blade:
        draw.line([(hx, hy), (hx + math.cos(a) * blade, hy + math.sin(a) * blade)],
                  fill=BLADE, width=9)

    r = 26
    hxc, hyc = tilt(head_y, cx), head_y
    draw.ellipse([hxc - r, hyc - r, hxc + r, hyc + r], fill=SKIN)

def frame(fallen=0.0, **kw):
    """One frame. `fallen` tips the whole figure over, pivoting on its feet.

    The rig has no joints, so "lying down" cannot be posed -- crouching only
    shortens the legs, which reads as standing with a wide stance rather than as
    dead. Rotating the finished drawing about the point the sprite pivot sits on
    (bottom centre) keeps the contact point exactly where it was while the body
    goes over, which is the whole trick.
    """
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    figure(ImageDraw.Draw(img), **kw)
    if fallen:
        img = img.rotate(fallen, resample=Image.BICUBIC, center=(W / 2.0, H - 4.0))
    return img

def write(motion, images):
    folder = os.path.abspath(os.path.join(OUT, motion))
    os.makedirs(folder, exist_ok=True)
    for i, img in enumerate(images, start=1):
        img.save(os.path.join(folder, "%02d.png" % i))
    print("  %-9s %d frame(s) -> %s" % (motion, len(images), folder))

def main():
    print("drawing the placeholder character")

    write("Default", [frame(bob=0, arm=-60), frame(bob=-2, arm=-58)])

    write("Idle", [frame(bob=0), frame(bob=-4, arm=-55)])

    write("Move", [
        frame(leg_split=0.30, bob=0, lean=8),
        frame(leg_split=0.10, bob=-6, lean=8),
        frame(leg_split=0.30, bob=0, lean=8),
        frame(leg_split=0.10, bob=-6, lean=8),
    ])

    write("Guard", [frame(crouch=0.7, lean=-14, arm=-150, blade=70, leg_split=0.32)])

    write("Damaged", [
        frame(lean=-18, arm=-95, crouch=0.15, leg_split=0.26),
        frame(lean=-26, arm=-110, crouch=0.35, leg_split=0.30),
        frame(lean=-12, arm=-80, crouch=0.2),
    ])

    write("Evade", [
        frame(lean=-10, crouch=0.4, arm=-120, leg_split=0.34),
        frame(lean=-22, crouch=0.85, arm=-140, leg_split=0.38),
        frame(lean=-14, crouch=0.5, arm=-125, leg_split=0.34),
    ])

    write("Dead", [
        frame(lean=-20, crouch=0.40, arm=-30, leg_split=0.30, fallen=-12),
        frame(lean=-26, crouch=0.70, arm=10, leg_split=0.36, fallen=-25),
        frame(lean=-30, crouch=0.90, arm=30, leg_split=0.42, fallen=-38),
    ])

    write("Parrying", [
        frame(lean=6, arm=-20, blade=95),
        frame(lean=16, arm=0, blade=110, crouch=0.2),
        frame(lean=10, arm=-10, blade=100),
    ])

    write("S1", [
        frame(arm=-115, blade=110, lean=-10),
        frame(arm=-75, blade=115, lean=0),
        frame(arm=-15, blade=120, lean=14, crouch=0.25),
        frame(arm=20, blade=110, lean=18, crouch=0.4),
    ])

    write("S2/0", [
        frame(arm=-140, blade=100, lean=-14),
        frame(arm=-120, blade=105, lean=-6),
        frame(arm=-8, blade=125, lean=18, crouch=0.2, leg_split=0.34),
        frame(arm=-4, blade=130, lean=22, crouch=0.3, leg_split=0.36),
        frame(arm=-30, blade=110, lean=6),
    ])
    write("S2/1", [
        frame(arm=30, blade=110, lean=-12, crouch=0.35, leg_split=0.34),
        frame(arm=-10, blade=120, lean=4, crouch=0.25),
        frame(arm=-60, blade=125, lean=14, crouch=0.15),
        frame(arm=-100, blade=110, lean=6),
    ])

    write("S3", [
        frame(arm=-100, blade=110, lean=-12),
        frame(arm=-30, blade=120, lean=8, crouch=0.2),
        frame(arm=40, blade=115, lean=16, crouch=0.4),
        frame(arm=-160, blade=110, lean=-10, crouch=0.1),
        frame(arm=-60, blade=125, lean=12, crouch=0.3, leg_split=0.34),
        frame(arm=-45, blade=100, lean=0),
    ])

    print("done. Open the project in Unity and press BUILD THE MOD.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
