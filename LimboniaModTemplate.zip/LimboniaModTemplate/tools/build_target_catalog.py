#!/usr/bin/env python
"""Rebuild the character list the Unity window offers, from the installed game.

The list lives in Assets/Editor/limbus-targets.json and is a snapshot of the
characters the game had when it was made. Run this only if a game update added
a character the dropdown does not know about; everything else works without it.

    pip install UnityPy==1.10.18
    python build_target_catalog.py
"""

from __future__ import annotations

import argparse
import datetime
import glob
import json
import os
import re
import sys
import zlib

FALLBACK_UNITY_VERSION = "6000.3.12f1"

MOTION_NAMES = {
    0: "Default", 1: "Dead", 2: "Evade", 3: "Guard", 4: "Damaged", 5: "Move",
    6: "Attack", 7: "S1", 8: "S2", 9: "S3", 10: "S4", 11: "S5", 12: "S6",
    13: "S7", 14: "S8", 15: "S9", 16: "S10", 17: "Parrying", 18: "Idle",
    19: "Parrying_Range", 20: "Special1", 21: "Special2", 22: "Special3",
    23: "Parrying_Lose", 35: "Empty", 36: "Duel_Ready", 37: "Duel_Win",
    38: "Duel_Lose", 39: "Damaged_2", 40: "Damaged_3", 44: "Retire",
    45: "Retreat", 46: "UnRetreat", 47: "Break", 48: "Reload",
}

BUNDLE_RE = re.compile(rb"([A-Za-z0-9_.\-]{3,160})_([0-9a-f]{32})\.bundle")

DEFAULT_GAME_DIRS = [
    r"C:\Program Files (x86)\Steam\steamapps\common\Limbus Company",
    r"C:\SteamLibrary\steamapps\common\Limbus Company",
    r"D:\SteamLibrary\steamapps\common\Limbus Company",
    r"E:\SteamLibrary\steamapps\common\Limbus Company",
    r"F:\SteamLibrary\steamapps\common\Limbus Company",
]

def crc32_path(path: str) -> int:
    """Exactly how Unity hashes an AnimationClip curve's transform path."""
    return zlib.crc32(path.encode("utf-8")) & 0xFFFFFFFF

def find_game_dir(explicit=None):
    if explicit:
        return explicit
    for candidate in DEFAULT_GAME_DIRS:
        if os.path.isfile(os.path.join(candidate, "LimbusCompany.exe")):
            return candidate
    raise SystemExit("Could not find the Limbus Company install. Pass --game-dir.")

def find_cache_dir(explicit=None):
    if explicit:
        return explicit
    roots = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(os.path.join(os.path.dirname(local), "LocalLow"))
    profile = os.environ.get("USERPROFILE")
    if profile:
        roots.append(os.path.join(profile, "AppData", "LocalLow"))
    for root in roots:
        candidate = os.path.join(root, "Unity", "ProjectMoon_LimbusCompany")
        if os.path.isdir(candidate):
            return candidate
    raise SystemExit("Could not find the Addressables cache. Pass --cache-dir.")

class BundleIndex:
    """Bundle base name -> the `__data` file the game cached it as.

    The game serves content over the Addressables web-request path, so bundles
    land in <LocalLow>/Unity/ProjectMoon_LimbusCompany/<32hex>/<32hex>/__data.
    The INNER directory is the bundle filename's 32-hex hash, and catalog.bin
    holds those filenames as plain readable strings -- so a regex over its raw
    bytes is the whole lookup.
    """

    def __init__(self, game_dir, cache_dir):
        self.cache_dir = cache_dir
        self.aa_dir = os.path.join(game_dir, "LimbusCompany_Data", "StreamingAssets", "aa")
        catalog = os.path.join(self.aa_dir, "catalog.bin")
        if not os.path.isfile(catalog):
            raise SystemExit("catalog.bin not found at %s" % catalog)
        with open(catalog, "rb") as fh:
            data = fh.read()
        self.names = {}
        for match in BUNDLE_RE.finditer(data):
            self.names.setdefault(match.group(1).decode("ascii", "replace"),
                                  match.group(2).decode("ascii"))
        self._inner = None

    def _inner_dirs(self):
        if self._inner is None:
            found = {}
            for path in glob.glob(os.path.join(self.cache_dir, "*", "*")):
                if os.path.isdir(path):
                    found[os.path.basename(path)] = path
            self._inner = found
        return self._inner

    def matching(self, pattern):
        rx = re.compile(pattern)
        return sorted(n for n in self.names if rx.search(n))

    def resolve(self, base):
        digest = self.names.get(base)
        if not digest:
            return None
        inner = self._inner_dirs().get(digest)
        if inner:
            data = os.path.join(inner, "__data")
            if os.path.isfile(data):
                return data
        for path in glob.glob(os.path.join(self.aa_dir, "*", "*%s.bundle" % digest)):
            return path
        return None

def read_tree(obj):
    try:
        return obj.read_typetree()
    except Exception:
        return None

def transform_path_table(objects, by_path_id, appearance_tt):
    """crc32 -> transform path, relative to the appearance root (root excluded).

    The game binds an AnimationTrack to the appearance's Animator, and that
    Animator sits on the ROOT GameObject -- so this is the space a clip's curve
    paths live in.
    """
    index = {}
    for obj in objects:
        if obj.type.name not in ("Transform", "RectTransform"):
            continue
        tt = read_tree(obj)
        if not tt:
            continue
        go_ref = tt.get("m_GameObject") or {}
        go = None
        if isinstance(go_ref, dict) and not go_ref.get("m_FileID"):
            go_obj = by_path_id.get(go_ref.get("m_PathID"))
            go = read_tree(go_obj) if go_obj is not None else None
        index[obj.path_id] = {
            "name": str((go or {}).get("m_Name") or ""),
            "children": [(c or {}).get("m_PathID") for c in (tt.get("m_Children") or [])],
        }

    root_go_ref = appearance_tt.get("m_GameObject") or {}
    root_go_obj = by_path_id.get(root_go_ref.get("m_PathID")) if isinstance(root_go_ref, dict) else None
    root_go = read_tree(root_go_obj) if root_go_obj is not None else None
    if not root_go:
        return {}
    root = None
    for component in root_go.get("m_Component") or []:
        if isinstance(component, dict):
            ref = component.get("component") or component.get("second") or component
        elif isinstance(component, (list, tuple)):
            ref = component[1] if len(component) > 1 else component[0]
        else:
            continue
        pid = ref.get("m_PathID") if isinstance(ref, dict) else None
        if pid in index:
            root = pid
            break
    if root is None:
        return {}

    table = {}
    seen = set()

    def walk(path_id, prefix):
        node = index.get(path_id)
        if node is None or path_id in seen:
            return
        seen.add(path_id)
        if prefix is None:
            current = None
        else:
            current = node["name"] if not prefix else "%s/%s" % (prefix, node["name"])
            table.setdefault(crc32_path(current), current)
        for child in node["children"]:
            walk(child, "" if current is None else current)

    walk(root, None)
    return table

def sprite_curve_hashes(objects):
    """How many sprite-swap curves target each transform-path hash.

    A flipbook curve is a PPtr curve on SpriteRenderer.m_Sprite, which Unity
    records as attribute 0 / customType 23 in the clip's binding constant.
    """
    counts = {}
    for obj in objects:
        if obj.type.name != "AnimationClip":
            continue
        tt = read_tree(obj)
        if not tt:
            continue
        for b in ((tt.get("m_ClipBindingConstant") or {}).get("genericBindings") or []):
            if b.get("attribute") == 0 and b.get("customType") == 23:
                h = int(b.get("path") or 0) & 0xFFFFFFFF
                counts[h] = counts.get(h, 0) + 1
    return counts

STANDARD_PATH = "[Transform,Fixed]ScaleAndPositionPivot/[Transform]PivotForAnim/[SpRenderer]"

def pick_binding_path(table, curve_counts):
    """Which transform path should a CUSTOM clip's sprite curve target?

    Returns (best, second_best).

    Rule 1 -- if the appearance's hierarchy contains the standard path, use it.
    Measured on the whole sinner roster, 177 of 178 appearances have that node
    and it is the character's main sprite renderer on every one of them.

    Rule 2 -- otherwise take the SHALLOWEST path that receives sprite-swap
    curves, breaking ties by curve count. Depth matters more than popularity:
    an effect layer is always a CHILD of the character's renderer, and a
    character with heavy VFX can easily have more curves on its effects than on
    itself (measured: 4 appearances where the busiest curve target is a
    grandchild like `[SpRenderer]/AnimRenderRoot/p1/Layer_1`). Picking by volume
    alone would point a custom animation at an effect node, and the character's
    own art would never change -- while everything still "worked".
    """
    if crc32_path(STANDARD_PATH) in table:
        alt = None
        for h, _n in sorted(curve_counts.items(), key=lambda kv: -kv[1]):
            if h in table and table[h] != STANDARD_PATH:
                alt = table[h]
                break
        return STANDARD_PATH, alt

    candidates = []
    for h, n in curve_counts.items():
        if h in table:
            candidates.append((table[h].count("/"), -n, table[h]))
    if not candidates:
        return None, None
    candidates.sort()
    return candidates[0][2], (candidates[1][2] if len(candidates) > 1 else None)

def scan_bundle(path, label, out, problems):
    import UnityPy

    env = UnityPy.load(path)
    objects = list(env.objects)
    by_path_id = {o.path_id: o for o in objects}

    appearances = []
    for obj in objects:
        if obj.type.name != "MonoBehaviour":
            continue
        tt = read_tree(obj)
        if not tt or "motionList" not in tt:
            continue
        go_ref = tt.get("m_GameObject") or {}
        go_obj = by_path_id.get(go_ref.get("m_PathID")) if isinstance(go_ref, dict) else None
        go = read_tree(go_obj) if go_obj is not None else None
        name = str((go or {}).get("m_Name") or "")
        if name:
            appearances.append((name, tt))
    if not appearances:
        return 0

    curve_counts = sprite_curve_hashes(objects)

    for name, tt in appearances:
        table = transform_path_table(objects, by_path_id, tt)
        binding, alt = pick_binding_path(table, curve_counts)
        if binding is None:
            problems.append("%s: no sprite curve resolves against its own hierarchy" % name)

        motions = []
        for entry in tt.get("motionList") or []:
            if not isinstance(entry, dict):
                continue
            detail = entry.get("_motiondetail")
            try:
                detail = int(detail)
            except (TypeError, ValueError):
                continue
            motions.append({
                "motion": MOTION_NAMES.get(detail, "Motion_%d" % detail),
                "detail": detail,
                "coins": len(entry.get("timelineAssets") or []),
                "spine": bool(entry.get("isSpineAnim")),
            })

        head = name.split("_", 1)[0]
        row = {
            "name": name,
            "id": int(head) if head.isdigit() else 0,
            "bundle": label,
            "bindingPath": binding,
            "motions": motions,
        }
        if alt and alt != binding:
            row["bindingPathAlt"] = alt
        out.append(row)
    return len(appearances)

def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--game-dir")
    ap.add_argument("--cache-dir")
    ap.add_argument("--out", default=None,
                    help="output path (default: ../Assets/Editor/limbus-targets.json)")
    ap.add_argument("--pattern", default=r"^(sd_p\d+_assets_all|p\d{5}_assets_all)$",
                    help="which catalog bundle names to scan")
    args = ap.parse_args()

    try:
        import UnityPy
    except ImportError:
        raise SystemExit("UnityPy is not installed:  pip install UnityPy==1.10.18")
    UnityPy.config.FALLBACK_UNITY_VERSION = FALLBACK_UNITY_VERSION

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    out_path = args.out
    if not out_path:
        here = os.path.dirname(os.path.abspath(__file__))
        out_path = os.path.join(here, "..", "Assets", "Editor", "limbus-targets.json")
    out_path = os.path.abspath(out_path)

    index = BundleIndex(find_game_dir(args.game_dir), find_cache_dir(args.cache_dir))
    names = index.matching(args.pattern)
    print("scanning %d bundle(s)" % len(names))

    rows = []
    problems = []
    for base in names:
        path = index.resolve(base)
        if not path:
            continue
        try:
            found = scan_bundle(path, base, rows, problems)
        except Exception as exc:
            problems.append("%s: %s: %s" % (base, type(exc).__name__, exc))
            continue
        if found:
            print("  %-28s %d appearance(s)" % (base, found))

    rows.sort(key=lambda r: (r["id"], r["name"]))
    seen = set()
    unique = []
    for row in rows:
        if row["name"] in seen:
            continue
        seen.add(row["name"])
        unique.append(row)

    doc = {
        "_comment": "Generated by tools/build_target_catalog.py. A snapshot of the "
                    "installed game: which characters exist, how many coin animations "
                    "each motion has, and the transform path an AnimationClip curve "
                    "must target. Regenerate after a game update if a character is missing.",
        "generated": datetime.datetime.now().strftime("%Y-%m-%d"),
        "unityVersion": FALLBACK_UNITY_VERSION,
        "appearances": unique,
    }
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=1, ensure_ascii=False)
        fh.write("\n")

    paths = {}
    for row in unique:
        paths[row["bindingPath"]] = paths.get(row["bindingPath"], 0) + 1
    print("")
    print("wrote %d appearance(s) -> %s" % (len(unique), out_path))
    print("binding paths in use:")
    for path, count in sorted(paths.items(), key=lambda kv: -kv[1]):
        print("  %4d  %s" % (count, path))
    for problem in problems:
        print("problem: %s" % problem)
    return 0

if __name__ == "__main__":
    sys.exit(main())
