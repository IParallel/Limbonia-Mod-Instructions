# Limbonia Mod Template

Draw a character, press one button, get a Limbus Company mod.

Eleven animations — **Default, Idle, Move, Guard, Damaged, Evade, Dead, Parrying
(the clash), S1, S2, S3** — each one a folder of PNGs. The button imports them,
builds the animations, packs them into an AssetBundle the game can load, writes
`mod.json`, and opens a preview scene so you can watch the result in Unity
instead of launching a battle.

**Sound too**: drag a `.wav` onto a motion's timeline in Unity, where you can hear
it against the drawings, and the build writes it into the mod for you.

**And your own effects**: drag an effect prefab onto the same timeline, watch it
fire against the drawings, and the build reads where you put it.

You do not need to know anything about Unity, AssetBundles, Timeline or
Limbonia's mod format. All of that is done for you, and this file explains the
few things that are genuinely yours to decide.

---

## Contents

- [The one thing to understand before you start](#the-one-thing-to-understand-before-you-start)
- [What you need](#what-you-need)
- [Step by step](#step-by-step)
- [Your drawings](#your-drawings)
- [A different animation on each clash](#a-different-animation-on-each-clash)
- [Getting the art right](#getting-the-art-right)
- [Timing](#timing)
- [The preview scene](#the-preview-scene)
- [Sound](#sound)
- [Visual effects](#visual-effects)
- [The window, field by field](#the-window-field-by-field)
- [Sharing your mod](#sharing-your-mod)
- [Changing things by hand, and keeping them](#changing-things-by-hand-and-keeping-them)
- [Troubleshooting](#troubleshooting)
- [What is in this folder](#what-is-in-this-folder)
- [Extras](#extras)

---

## The one thing to understand before you start

**A mod replaces a character the game already has. It cannot add a new one.**

Limbonia installs an animation onto an existing character. There is no way to
introduce a thirteenth sinner. So "custom character" means: you pick a character
in the game, and *your* drawings play instead of theirs.

That is why the window's first question is **"Replaces"**. Pick someone whose
skill count and general shape suit what you are drawing.

Everything else about them stays theirs — their name, portrait, stats, skill
names, damage numbers, sounds and effects. You are replacing the **animation**,
not the character.

---

## What you need

| | |
|---|---|
| **Unity 6000.3.12f1** | Exactly this version. Not 6000.3.11, not 2022.3. See below. |
| **Limbus Company with Limbonia** | The mod goes into the `Mods` folder beside `LimbusCompany.exe`. |
| A drawing program | Anything that exports PNG with transparency. |
| Python 3 *(optional)* | Only for an extra safety check on the built bundle. The build works without it. |

### Why the Unity version is exact

The game refuses AssetBundles in the older archive format. Shipped game bundles
are `UnityFS` **format 8**; a Unity 2022.3-class editor writes format 7 and the
game rejects it. `6000.3.12f1` is the version the game itself is built with. The
build checks the header and stops if it is wrong, so you cannot ship a bundle
nobody can load — but it is easier to install the right editor than to find out
at that point.

Get it from the Unity Hub: **Installs → Install Editor → Archive → download
archive**, then find `6000.3.12f1`.

That one version decides the renderer too. This project uses **URP 17.3.0** — the
same renderer, at the same version, the game runs — and you do not choose it or
install it: URP ships inside the `6000.3.12f1` editor, so getting the editor
version right gets the renderer version right for free.

---

## Step by step

### 1. Open the project

Unity Hub → **Add** → choose this folder → open it with 6000.3.12f1. The first
open takes a few minutes while Unity imports.

If Unity offers to upgrade the project to a newer version, **say no** and install
6000.3.12f1 instead.

The first open also imports URP and Shader Graph. They come out of the editor
install rather than off the internet, so this works offline, but it does add a
few minutes and a long stream of "importing" the first time. If a dialog offers
to run a **render pipeline converter** or to **upgrade materials**, say **no** —
the materials in this project are already correct, and the converter would
rewrite them to something narrower.

### 2. Open the window

**Window → Limbonia → Custom Character**

Dock it wherever you like. It remembers your settings.

### 3. Build the example first, before you draw anything

The project ships with a placeholder: a blue stick figure with all eleven
animations already drawn. Build **that** first.

1. **Replaces** — pick any character. Anyone. You are going to undo this.
2. **Mod name** — leave it as `MyCharacter`.
3. **Mods folder** — the `Mods` folder beside `LimbusCompany.exe`. The window
   tries to guess it; press **Browse** if the guess is wrong. If there is no
   `Mods` folder yet, create one.
4. Press **BUILD THE MOD**.
5. In game (or in the Limbonia companion), rescan mods, then enter a battle with
   that character and use their skills.

If a blue stick figure swings a sword at something, **the whole chain works** —
your Unity install, the bundle format, `mod.json`, Limbonia and the animation
binding. Everything after that is drawing. If it does *not*, fix that before you
spend a day on artwork; see [Troubleshooting](#troubleshooting).

Then delete the placeholder PNGs and put yours in the same folders.

### 4. Draw

See [Your drawings](#your-drawings) and [Getting the art
right](#getting-the-art-right).

### 5. Build again, and test

Press **BUILD THE MOD**. It takes seconds. Read the Console, or
`Assets/CustomCharacter/_Generated/BUILD-REPORT.txt`, which says exactly what it
made and what will happen in game.

The build **stops and deploys nothing** if anything is wrong, so a broken mod
never reaches your game folder.

Then rescan mods in the Limbonia companion (or relaunch the game) and enter a
battle with the character you replaced.

---

## Your drawings

```
Assets/CustomCharacter/Sprites/
    Default/     01.png  02.png ...      the neutral standing pose -- draw this one
    Idle/        01.png  02.png ...      the between-turns idle
    Move/        01.png  02.png ...      walking
    Guard/       01.png ...              bracing
    Damaged/     01.png ...              recoiling from a hit
    Evade/       01.png ...              dodging
    Dead/        01.png ...              downed
    Parrying/    01.png ...              the clash, when two attacks meet
    S1/          01.png  02.png ...      first skill
    S2/          0/ 01.png ...           second skill, one animation per clash
                 1/ 01.png ...
    S3/          01.png  02.png ...      third skill
```

* **One folder = one animation.** Files play in name order.
* **Numbers sort as numbers**, so `2.png` comes before `10.png`. Names with no
  digits sort alphabetically.
* An **empty folder is skipped**, and that character keeps their original
  animation there. A mod that only replaces `S1` is perfectly valid.
* PNG (also JPG, TGA, PSD). Transparent background — a real PNG, not another
  format renamed.
* The file names inside a folder are yours. `1.png`, `001.png`, `a.png` — use
  whatever your drawing program exports.

The window lists how many frames it found in each folder, so you can see it
picked up your files without building.

**The shipped placeholder uses both layouts on purpose.** `S1` is a plain folder,
which gives that skill one animation played on all of its clashes. `S2` is split
into `0/` and `1/`, which gives its first two clashes an animation each. See the
next section.

### Those eleven are not always the whole list

Every character has those eleven. Plenty of characters have **more** — an `S4`, a
`Duel_Win`, an `S5`, a `Special1`, a `Retreat`, even a `Reload`. Which extras a
character has is a fact about that character, and an animation you never drew
does not fail loudly: it just plays the original character.

So pick who you are replacing and press **"Set up the folders for this
character"**. It reads that character's real motion list and makes a folder for
every motion they have, putting a copy of your `Default` pose in each new one so
the character is covered everywhere from the first build. Redraw them in your own
time; until you do, the build report lists them under **STILL PLACEHOLDERS, NOT
DRAWN**.

**It never touches a folder that has any drawing in it**, and it is a button,
never part of building: pressing BUILD THE MOD never changes your drawings.

You can also just make the folder yourself. `Sprites/S4/` is built exactly like
the other eleven. A folder whose name is not a motion any character has (a typo,
usually) is reported as a warning rather than silently ignored.

### `Default` vs `Idle` — draw both, and `Default` first

This is the one that catches everybody, and it shows up as something that looks
like a bug rather than a missing drawing.

**`Default` is the neutral standing state.** The character passes through it on
the way back to standing after *every* action — after a skill, after being hit,
before settling into `Idle`. The game also falls back to `Default` outright
whenever `Idle` is not what actually plays.

**So `Default` is on the path out of everything.** Leave it undrawn and the
original character flashes through on every transition, which reads as flickering
rather than as one missing pose. If you draw only one standing pose, draw
`Default`. A single frame is enough to stop it.

**`Idle` is the between-turns loop**, and it is worth drawing too — but check it
in a battle. The game switches to a character's Spine skeleton for `Idle` before
it ever looks at your animation, so on some characters yours can be installed,
running, and hidden behind the skeleton. It is the one to verify per character
rather than assume.

The window shows a warning if `Default` has no drawings, and so does the build
report.

### A motion you do not draw

Not a blank and not a skip. Every motion is optional, an empty folder is skipped
cleanly and named in the report, and in game:

* if you drew `Idle` or `Default`, that animation plays instead — the original
  character is never shown;
* if you drew neither, Limbonia has nothing to show, so the character you
  replaced shows through. **Draw `Idle` or `Default`.**

---

## A different animation on each clash

A three-coin skill clashes three times, and by default your one animation plays
on all three. To draw them separately, **give each clash its own numbered folder
inside the motion folder**:

```
Assets/CustomCharacter/Sprites/S1/
    0/  1.png  2.png  3.png  4.png     <- the FIRST clash
    1/  1.png  2.png  3.png            <- the SECOND clash
    2/  1.png  2.png  3.png  4.png     <- the THIRD clash
```

That is the whole feature. There is nothing to tick and nothing to configure —
the build reads the folders, makes one animation per folder, and declares each
one for its own clash. The window shows you what it read (`clash 0, clash 1,
clash 2 (3 animations, one per clash)`) before you build, and each clash gets its
own station in the preview scene, so each one can have its own **sound**, its own
**effects** and its own **camera work**.

**Counting starts at 0.** `0/` is the first clash, `1/` the second. That is the
number the game itself uses and the number that ends up in `mod.json`.

**Any skill works this way, not just S1 to S3.** If the character has an `S7`,
then `Sprites/S7/0/`, `Sprites/S7/1/` … does exactly the same thing.

**How many folders you make is how many clashes you have drawn** — it does not,
and cannot, change how many coins the skill has. That is fixed by the character.
The window shows each motion's coin count beside it.

Five things to know:

- **A clash you do not draw keeps the ORIGINAL character's animation.** It does
  *not* fall back to your other clashes. So if you make only a `0/` folder on a
  three-coin skill, clash one is yours and clashes two and three are the
  character you replaced. The build report lists exactly which clashes you
  covered and which you did not, per motion.
- **A folder that is not a number is not a clash, and nothing in it is built.**
  `S1/old/` or `S1/rough/` is left alone rather than guessed at, and the build
  report names it so a folder full of drawings can never go quietly unused. Same
  for a gap in the numbering (`0/` and `2/` but no `1/`), an empty numbered
  folder, and two folders that mean the same number (`0/` and `00/`).
- **A clash the skill does not have does nothing.** Make a `3/` folder on a
  two-coin skill and the game refuses it. The build says so before you get there.
- **Still poses cannot be split.** Idle, Default, Move, Guard, Damaged, Evade and
  Dead have no clashes to number. A `0/` folder is harmless on them; anything
  above it is refused.
- **Drawings left loose beside the numbered folders are still built**, as one
  animation for the whole skill, with each numbered folder replacing its own
  clash on top. The report says when it found both, in case the loose ones were
  leftovers.

An older naming still works: a clash named at the front of the file (`0_1.png`,
`0_2.png` for the first clash, `1_1.png` for the second), flat in the motion
folder with no subfolders. Folders are only read when there are folders, so you
never have to migrate anything.

---

## Getting the art right

Only three things about your drawings matter mechanically. Everything else is
taste.

### 1. Every frame the same size

One canvas size for the whole character. The placeholder art is 460 × 460.

### 2. Feet at the bottom, body at the centre

A sprite is positioned by its **pivot** — the point of the drawing that sits on
the transform origin. The default here is **bottom-centre (0.5, 0)**, which puts
the character's contact point with the ground exactly where the game expects it.
The game's own art does the same.

So: **draw the feet on the bottom edge and the body in the horizontal middle.**

If a sword swings out to the side, **make the canvas wider** — do not shift the
character across the canvas to make room. Shifting the drawing shifts the
character in game, on that frame only, and it reads as a jerk.

The preview scene's yellow line at y = 0 is the floor, and it is how you check
this. Worth checking before you draw fifty more frames.

### 3. Pixels per unit decides the size on screen

`100` means 100 pixels of your art is one world unit — the value the game itself
uses throughout. A 400 px tall drawing is a 4-unit tall character, which is about
right next to a sinner.

If your art is a different scale, **change the number under Advanced, do not
resize the files**:

* art drawn at **twice** the size → set pixels-per-unit to **200**;
* art drawn at **half** the size → set it to **50**;
* character comes out too big in the preview → **raise** the number.

---

## Timing

Duration is simply `frames ÷ frames-per-second`. Ten frames at 12 fps is 0.83
seconds. The window's **Frames per second** (12 by default) applies to
everything.

To give one animation its own speed, put a file called **`fps.txt`** in that
folder with a single number in it:

```
Assets/CustomCharacter/Sprites/S3/fps.txt      containing:   20
```

On a split skill it goes in the clash folder it applies to — `S2/1/fps.txt`.

For reference, the game's own skill animations run roughly **0.5 to 1.5 seconds
per coin**, from 6 to 15 drawings. The placeholder art is deliberately shorter
than that — four frames is enough to prove the pipeline, not to look good. If
your skill feels rushed, draw more frames rather than lowering the frame rate:
fewer frames per second makes it choppy, not slower to read.

An animation must last at least **0.05 seconds** or Limbonia refuses it. At 12
fps a single frame is already 0.083 s, so this only bites at very high frame
rates — and when it does, the build stretches the animation and says so.

---

## The preview scene

Building opens a preview scene automatically. **Your character is standing there
the moment it opens** — the build puts `Default`'s first frame on it as a resting
pose, so you can check the drawing, the size and the pivot without playing
anything.

There is no custom preview window — the animations are on a character in the
scene, so Unity's own tools do it:

1. Select **Character** in the Hierarchy.
2. **Window → Animation → Animation.**
3. Pick a motion from the clip dropdown and drag along the timeline.

The Scene view updates as you drag. No Play mode. To reopen it later, press
**Open the preview scene** in the window.

**What the preview deliberately cannot show:** movement, camera shake, and the
damage/hit/end beats. None of those are in the bundle — Limbonia produces them at
runtime from `mod.json`. **A preview that animates on the spot is correct**, not
broken.

**Sound and your own effects are the exceptions, and both really do play here.**

---

## Sound

You drag a sound onto the animation, in Unity, where you can **hear it against
the drawings**. The build reads it back out and writes it into the mod.

### Where the files go

```
Assets/CustomCharacter/Sounds/
    example-swish.wav               ships with the project, so you can try this now
    slash.wav
    hit.ogg
```

**`.wav` and `.ogg` only.** Those are the two formats Limbonia can play. Unity
will happily import an mp3, an aiff or an m4a, and it will sound fine in the
Timeline window — and then be **silence in game, with no error anywhere**. So the
build checks every file and names any that will not play, in the Console and in
`BUILD-REPORT.txt`. It checks the file's actual contents too, so renaming
`song.mp3` to `song.wav` is caught as well. A bad sound is a warning, not a
failed build.

### Placing it

1. **Build once**, so the timelines exist.
2. Open the preview scene. In the Hierarchy there is a **Sound and effects**
   object with one child per motion — `S1`, `Default`, `Guard` and so on.
3. **Select the motion you want.**
4. **Window → Sequencing → Timeline.**
5. **Drag your `.wav` onto the timeline** at the moment it should play.
6. **Scrub.** You hear the sound against the drawings.
7. **Build again.** The sound is written into `mod.json` and the file is copied
   into `Mods/MyCharacter/audio/`.

Step 6 is the point of the whole thing. Unity plays audio tracks while you scrub,
and Limbonia fires the sound off the same clock at the same number of seconds —
so **the timing you hear in Unity is the timing you get in game**.

You can drop as many sounds on a motion as you like, on one audio track or
several. Muting a track leaves its sounds out.

### What ships and what does not

The bundle contains no audio track — the sound is read at build time and written
into `mod.json` instead. So the timeline clip is an *instruction to the build*,
and only part of it is read:

| In Unity | In game |
|---|---|
| **Where the clip starts** | yes — this is what ships |
| The clip's **length** | no — the file plays once, to its own end. Trimming it changes nothing. |
| **Loop** | no — fires once |
| Fades, blends, `clipIn` | no — ignored |
| Volume, and the track's volume | yes — multiplied together, as Unity does |
| Stereo pan, spatial blend | no — ignored |

**Volume can only go down.** Unity caps a volume at 1.0 (the recording as it is).

### Your placements survive rebuilding

The build regenerates every timeline from scratch, so it **takes your audio
tracks off, builds the bundle, and puts them straight back**. You do not have to
re-drag anything, and a build that fails half way still puts them back.

Two things follow from that:

* **Deleting `_Generated/` deletes your sound placements** along with everything
  else in it. The sound *files* are safe in `Sounds/`; where you put them is not.
* **Renaming the mod** orphans them, because the timelines are named after the
  mod.

### On a multi-clash skill, the sound plays on the first clash only

A plain motion folder's animation is declared for **every** clash, so you never
have to count them. Sound does not broadcast the same way: a cue on a broadcast
animation lands on the first clash.

So on a three-coin S1 built from a plain folder, **your animation plays three
times and your sound plays once**. The build says so per motion.

**The way round it is to draw the clashes separately** — see [A different
animation on each clash](#a-different-animation-on-each-clash). Each clash then
becomes its own animation with its own station in the preview scene, and
therefore its own sounds.

### If you hear nothing

**In Unity:** check the speaker / **Mute Audio** toggle in the Scene view
toolbar, and make sure you selected a motion under **Sound and effects** rather
than the character.

**In game:** custom sound rides the game's **voice** volume slider, so a low
voice setting makes every custom sound quiet no matter how the file is mastered.
Check that before treating it as a mastering problem. After that, check
Limbonia's log — it names a clip it could not find or could not decode.

---

## Visual effects

A clash can play a flash, a slash, a burst of sparks. There are two sources: one
the character already has (picked from a list in the companion's animation
editor, nothing to build), and one **you** ship. This section is the second.

### Where the files go

```
Assets/CustomCharacter/Effects/
    particle_effect.prefab
    sparks.prefab
```

**Every prefab in that folder is packed into the bundle and declared in
`mod.json`** — nothing else to configure. The prefab's **own name** is the name
you address it by, so name it something you will recognise. Two prefabs with the
same name **stop the build**.

### What goes on the prefab

Anything Unity itself provides:

* **Particle System** — the usual one. **Turn Play On Awake ON.** Limbonia
  switches the whole object on and off and never calls `Play()`, so a system that
  does not start itself is permanently silent. The build warns if it finds one.
* **Animator** with its own controller, for a hand-animated flash.
* **Trail Renderer**, **Line Renderer**, **Sprite Renderer** — whatever draws.

Materials and shaders travel inside the bundle with it.

### The one hard rule: no scripts of your own

**A prefab carrying a `MonoBehaviour` you wrote stops the build.**

A script compiled in this project has no counterpart inside the game, so the
prefab would be created with a dead script reference — no crash, no error, no
warning, just an effect that does nothing forever with nothing anywhere to say
why. The build catches it here instead, and names the script.

**You do not need one.** The component the game uses to drive an effect is the
game's own, and Limbonia adds it to your prefab as the mod is loaded. Everything
Unity provides works exactly as it does in the editor.

### Which shaders you can use: all of them

Unity's older built-in shaders, URP's, Shader Graph, or your own `.shader` file
— all of them work in this game.

| | Where it is in the dropdown | Notes |
|---|---|---|
| **`Particles/Standard Unlit`** | `Particles > Standard Unlit` | What the game uses on its own particles, so it is the safest bet there is. Rendering Mode → **Fade** or **Additive**. |
| **`Universal Render Pipeline/Particles/Unlit`** | `Universal Render Pipeline > Particles > Unlit` | The URP equivalent. Same look, clearer inspector. Surface Type → **Transparent**. |
| **Shader Graph** | `Assets > Create > Shader Graph > URP` | Use the **Unlit** target, not Lit — the preview scene has no light in it, and the game's own effects are all Unlit. Surface Type → **Transparent**. |
| **Your own `.shader` file** | wherever you put it | Fine. Write it unlit. |

**What does matter is that the material draws see-through.** Limbus draws its
whole battle scene — background, board, character, and the game's own attack
effects — as see-through, and sorting layers are only obeyed for see-through
renderers. A material left in Unity's default **Opaque** mode is drawn underneath
the entire scene, and no amount of placing it in front of the character can
rescue it: the effect plays perfectly and you see nothing.

So on a URP shader set **Surface Type** to **Transparent**; on one of Unity's
older ones set **Rendering Mode** to **Fade** (or **Additive**, for a glow) —
never Opaque. **The build checks this for you and fixes it**, naming what it
changed; a material it cannot fix is reported instead.

### A shader that bends the screen — heat haze, refraction, a warping aura

**If your effect appears with the default material and disappears the moment you
put your own material on it, read this.**

**A `GrabPass` cannot work in this game.** A grab pass is the step that copies the
screen so a shader can bend it, and it belongs to Unity's *older* renderer. Limbus
uses the newer one, which has no such step — so the copy is never made, your
shader reads an empty screen, and the effect vanishes with no error anywhere.
**The build stops on this**, names the shader and the line the grab pass is on.

Use the shader this project ships instead: in the material's shader dropdown pick
**`Limbus/Screen Distortion Particle`**
(`Assets/CustomCharacter/Shaders/LimbusScreenDistortionParticle.shader`). It has
the same **Distortion Strength**, **Aura Tint**, **Scroll Speed X/Y** and **Edge
Softness**, and it reads the copy of the screen the game makes for its *own*
distortion effects, so it bends the whole battle.

Also **avoid Shader Graph's Scene Color node** for the same job. It reads Unity's
own copy of the screen, which is taken *before* anything see-through is drawn —
and Limbus draws its entire battle see-through, so in a battle that copy is very
nearly blank. The build notes this if it sees one.

**The prefab's Layer is set for you.** Your effect prefab's root object wants
**Layer = `Distortion`**. If a material on the prefab uses a shader that reads the
game's screen copy and the prefab is still on `Default`, the build moves it and
says so. A prefab already on some other layer is left alone and mentioned
instead.

**You can see it in the preview.** The preview scene makes a screen copy of its
own, the same way the game does, so a refraction is something you can watch while
you tune it. One difference worth knowing: the game re-draws the `Distortion`
layer *after* taking its copy, so in game a refraction bends the **current**
frame; the preview bends the **previous** one. On a heat shimmer that is
invisible. On something whipping across the screen it lags by a single frame — so
judge fast, snappy refractions in a battle, not here.

**If you get a dark blob instead of a shimmer**, that is the shader working and
the screen copy not arriving. In game, try the other **Screen copy** setting on
the material. In the preview, check the Console for a compile error under
`Assets/CustomCharacter/Rendering`, and check that **Project Settings → Graphics
→ Scriptable Render Pipeline Setting** still holds `Limbonia_URPAsset`.

**And if you do not actually need to bend the screen**, none of this applies. Any
see-through or additive particle shader works, and a bright additive aura reads
better than a subtle refraction at Limbus's size anyway.

### Placing one — drag it onto the timeline

Building the prefab puts it in the mod; it does not make anything play it.
Placing it is the same gesture as placing a sound:

1. **Build once**, then open the preview scene.
2. In the Hierarchy, open **Sound and effects** and select the motion you want.
3. **Window → Sequencing → Timeline.**
4. Drag the prefab from `Assets/CustomCharacter/Effects/` onto the timeline,
   where it should play. If Unity asks what kind of track, choose **Control
   Track**.
5. **Scrub.** The effect appears as the playhead enters the clip and disappears
   as it leaves — which is exactly what happens in game.
6. **Build again.** The time, the length and the prefab's own position are
   written into `mod.json` for you.

Drag the clip to move it; drag its right edge to change how long it is held on.
**To take one back**, mute the effect track — a muted track is not read, and its
placements stay exactly as they are.

**Only the placements the build made are ever rewritten.** They are marked
`"from": "unity"` in `mod.json`, and a build changes those and nothing else — an
effect you added by hand, or in the companion, is left exactly as you wrote it.

### Position, scale and size

**The position comes from the prefab's own root.** The game writes that offset
straight into the effect's position every time it is switched on, so open the
prefab, move its root, build, and it moves in game. It does not track a target or
turn to face one.

**Same effect in two places?** Right-click the prefab → **Create → Prefab
Variant**, move the variant's root, and drop the variant on instead.

**There is no scale setting, on purpose.** Scale the prefab in Unity. The game's
own scale field is *added* to the object's scale every time the effect is
switched on, so a value there would make the effect a little bigger on every
single play.

**In game an effect of yours is drawn twice the size it is in the preview**,
relative to the character — and everything moving inside it crosses the character
twice as fast. The character hangs under a pivot the game scales to half, and so
do the character's own effects; yours is hung one level above, where nothing is
scaled.

---

## The window, field by field

| Field | What it does |
|---|---|
| **Replaces** | Which character in the game your animations take over. A dropdown, grouped by sinner, of every appearance the game has. It is a list and not a text box because Limbonia matches the name *exactly* — one typo and the mod loads, reports no error, and does nothing. |
| **Mod name** | Names the folder in `Mods/`, the bundle and the assets inside it. Letters, digits, `-` and `_`. |
| **Mods folder** | The `Mods` folder beside `LimbusCompany.exe`. |
| **Set up the folders for this character** | Makes a sprite folder for every motion the chosen character has. Never touches a folder that already has a drawing in it. |
| **BUILD THE MOD** | Everything: re-reads your drawings and rebuilds the animations. |
| **Build without regenerating** | Ships what is already in `_Generated/`, untouched. |
| **keep my edits** *(per motion)* | That motion is never regenerated. |

Beside each motion the window shows how many **coins** that character's skill has
— a skill is played one clash at a time, and the game keeps a separate animation
per clash. From a plain motion folder the build declares your animation for
*every* clash, so your S1 plays three times on a three-coin S1. Worth knowing
before you draw a six-second cinematic.

### Advanced (you rarely need it)

| Field | Default | When to change it |
|---|---|---|
| **Frames per second** | 12 | The speed of every animation. A single folder can override it with an `fps.txt` inside it containing one number. |
| **Pixels per unit** | 100 | How big the character is on screen. See [Getting the art right](#getting-the-art-right). |
| **Pivot X / Y** | 0.5 / 0 | Which point of the drawing sits on the ground. |
| **Step towards the target** | on | Writes movement into `mod.json` for S1/S2/S3 so the character walks up to whatever it is attacking. Turn it off if your animation should happen where it stands. |
| **Let Limbonia draw the character** | on | **Leave it on.** With it off, the mod is built for a way of drawing Limbonia has removed, and nothing of yours appears. |
| **Binding path override** | blank | Leave blank. The escape hatch described under [Troubleshooting](#troubleshooting). |

---

## Sharing your mod

Everything the mod needs is in one folder:

```
Mods/MyCharacter/
    mod.json
    motions/
        customchar_mycharacter_7f3ab210.bundle
    audio/                          only if you added sound
        slash.wav
```

**Zip that folder.** Whoever you send it to drops it into their own
`Limbus Company/Mods/` and it works — the drawings are inside the bundle and the
sound files are copied in beside `mod.json`, so nothing travels separately.

Do **not** include:

* the Unity project — nobody needs it to *use* the mod;
* `Assets/CustomCharacter/_Generated/` — rebuilt every time you press the button
  (but your sound and effect **placements** live in there, so do not delete it on
  your own machine);
* `mod.json.backup` — the build writes one whenever it overwrites an existing
  `mod.json`; it is for you, not for the person you are sending it to.

If you want to share the *source* so others can build on it, zip the whole
project **minus** `Library/`, `Temp/`, `Logs/`, `UserSettings/` and
`Assets/CustomCharacter/_Generated/`. That is what `.gitignore` already lists.

### The same animations on a second character

**Nothing in the bundle names a character.** It holds drawings, animations and
your effects, and that is all. The only thing that decides who a mod replaces is
the `"appearance"` line in `mod.json`.

So to put the same character on somebody else, you do not build again:

1. **Copy the whole `Mods/MyCharacter/` folder** to a new name beside it.
2. Open the copy's `mod.json` and change **`"appearance"`** to the other
   character.
3. Change `"name"` too, so the two are told apart in the mods list.

Both can be switched on at once. Two things to know:

* **If your mod has sound**, a cue names its sound as `"<mod folder>/<file>"` —
  so every `"clip"` in the copy still points at the *original* folder's audio.
  Search the copy's `mod.json` for `MyCharacter/` and change that part to the
  copy's folder name.
* **The two folders hold the same archive**, and the game will only open one copy
  of an archive at a time. If the copy reports that its bundle would not open,
  that is why: set this window's **Mod name** to the copy's folder name and build
  it once, and it gets an archive of its own.

The archive is named `customchar_<mod name>_<bundle id>`. The bundle id is made
once, the first time you build a mod, and recorded as `"bundleId"` at the top of
its `mod.json` — so rebuilding never renames the file, and two different mods
never collide even if both authors left the mod name as `MyCharacter`.

---

## Changing things by hand, and keeping them

Curves you keyed by hand — position, rotation, scale — **do** survive a normal
build. The build carries them across when it regenerates a motion.

Anything *structural* — retimed sprite keys, extra tracks, a timeline you rebuilt
— is replaced by **BUILD THE MOD**. Two ways to protect it:

* Tick **keep my edits** beside that motion. It is then never regenerated, and
  its `.anim` and `.playable` in `_Generated/` are shipped exactly as they are.
  The list is stored in `Assets/CustomCharacter/hand-edited.json`, which appears
  the first time you use it.
* Or press **Build without regenerating**, which ships everything in
  `_Generated/` untouched.

The first line of the build report always says which mode ran and which motions
were kept.

The safety checks do not relax for either: an animation that is empty, aims at
the wrong transform path or holds the wrong number of drawings still stops the
build.

---

## Troubleshooting

### The mod does not appear at all

Check Limbonia's own log or the companion's Mods panel. `mod.json` sitting in the
wrong folder, or a bundle path that does not resolve, is reported there by name.

### Unity says the bundle is "not compatible with this newer version of the Unity runtime"

**That message is misleading about the cause.** It almost always means the
AssetBundle module was disabled while the bundle was built, so Unity wrote an
archive with no `AssetBundle` object in it — silently, while still reporting a
successful build.

The fix is one line in `Packages/manifest.json`:

```json
"com.unity.modules.assetbundle": "1.0.0"
```

It is already there in this project. If you ever see that error, check that
`Packages/manifest.json` still exists and still has that line.

### The mod loads, Limbonia reports no problem, and the character does not change

This is the one failure that looks like success, and it has one likely cause:
**the curve binding path**.

An animation does not store the *name* of what it animates. It stores a checksum
of a transform path relative to the character's root. If that path does not match
the character's real internal structure, the animation binds to nothing and plays
perfectly — invisibly, with no error anywhere.

The build looks the right path up per character in `limbus-targets.json`, so you
should never have to think about it. If you are targeting a character added by a
game update *after* that catalog was made, and nothing shows up, [rebuild the
catalog](#rebuilding-the-character-list) — or paste a path into **Binding path
override** under Advanced. The build report prints the path it used and where it
got it.

If you changed the override *after* the first build, note that nothing overwrites
a key already in `mod.json`: delete the `"spritePath"` line and build again to
have it written fresh. The build report names both values when they disagree.

Otherwise, check the companion's **Mods** panel: every character routed through
the renderer reports there what it is doing, and *"built, but nothing of yours is
on screen"* means the animation bound to nothing.

### My effect works until I put my own material on it, then it vanishes

If that material's shader has a **`GrabPass`** in it, that is the cause — see
[A shader that bends the screen](#a-shader-that-bends-the-screen--heat-haze-refraction-a-warping-aura).
The build stops on it and names the shader.

If it is not a grab pass, work down the effect's line in the companion's mod
panel: `no particle system on it`, `nothing on it has a material` and `SOLID, so
drawn underneath the scene` are three different faults with three different
fixes, and all three look identical from inside the game.

### The preview scene is empty

It should not be — the character is given a resting drawing at build time. An
empty scene means something real went wrong, most likely that the art did not
import or the binding path is wrong. Read `BUILD-REPORT.txt`: it names the
resting drawing it chose, and warns explicitly if it could not choose one.

### The character sinks into the floor, or floats

The pivot. See [Getting the art right](#getting-the-art-right), and check it
against the yellow floor line in the preview scene.

### The character is enormous, or tiny

Pixels per unit. See [Getting the art right](#getting-the-art-right).

### The sound plays in Unity but not in game

In order of likelihood:

1. **It is not a `.wav` or `.ogg`.** Read `BUILD-REPORT.txt` — the build names
   every file it refused, under `SOUNDS THAT WILL NOT PLAY`.
2. **Your in-game *voice* volume is low.** Custom sound rides that slider.
3. **It is placed past the end of the animation.** The build warns about this by
   name; the sound is written out but the animation never reaches it.
4. **It is a multi-clash skill** and you are listening on the second clash. With
   one animation covering the whole skill it only fires on the first — see
   [Sound](#sound).

### The sound does not play in Unity either

Check the **Mute Audio** speaker toggle in the Scene view toolbar, and that you
selected a motion under **Sound and effects** in the Hierarchy rather than the
character.

### My sound placements disappeared

Something deleted `Assets/CustomCharacter/_Generated/`, or the mod was renamed —
the timelines are named after the mod. The sound *files* in `Sounds/` are
untouched; only where you dropped them is gone.

### My hand-made changes keep getting overwritten

Read the first line of the build report: it says which mode ran and which motions
were kept. See [Changing things by hand](#changing-things-by-hand-and-keeping-them).

### "Build without regenerating" says there is nothing to build

That mode ships what is in `_Generated/`, so something has to be there. Press
BUILD THE MOD once first.

### The animation plays but the character never walks up to its target

**Step towards the target** is off, or you are looking at the preview — which
never shows movement, because movement is not in the bundle.

### "EndLayoutGroup: BeginLayoutGroup must be called first" fills the Console

A symptom, not the cause — something threw. Close and reopen the window, then
read `BUILD-REPORT.txt`, which is written even when the build fails.

---

## What is in this folder

```
README.md                       this file
Packages/manifest.json          MUST list com.unity.modules.assetbundle -- see Troubleshooting
                                also pulls in URP + Shader Graph, both out of the editor install
verify_bundle.py                optional extra check on the built bundle (needs Python + UnityPy)
tools/
    build_target_catalog.py     regenerates the character list from your game install
    make_example_art.py         redraws the placeholder stick figure
Assets/
    CustomCharacter/Sprites/    YOUR DRAWINGS GO HERE, one folder per animation
    CustomCharacter/Sounds/     YOUR SOUND FILES GO HERE (.wav / .ogg)
    CustomCharacter/Effects/    YOUR EFFECT PREFABS GO HERE (script-free)
    CustomCharacter/Shaders/    the screen-bending shaders this project ships
    CustomCharacter/Rendering/  the preview's copy of the game's screen-grab step, so a
                                refraction can be seen while it is tuned. Editor-only, in its
                                own assembly; it can never end up in a mod
    Settings/                   the render pipeline settings. Limbonia_URPAsset is the one
                                Project Settings > Graphics points at; Limbonia_Renderer is
                                the renderer it uses. Nothing here ships in a mod
    Editor/
        CcWindow.cs             the window
        CcBuild.cs              the build: images -> clips -> timelines -> bundle
        CcManifest.cs           mod.json: renderer, motion names, clash indices, movement, cues
        CcAudio.cs              sound: reads the timeline's audio tracks, copies the files
        CcEffects.cs            effect prefabs: checks them, packs them, declares them
        CcVfx.cs                effects: reads where you placed them on the timeline
        CcEdits.cs              hand edits: the keep list, and carrying curves across a rebuild
        CcBundle.cs             building, checking and deploying the AssetBundle
        CcPreview.cs            the preview scene
        CcTargets.cs            reads the character list
        CcBatch.cs              a command-line entry point (not used by the window)
        MiniJson.cs             a small JSON reader/writer
        limbus-targets.json     every character in the game, their coin counts and binding path
```

`Assets/CustomCharacter/_Generated/` and `hand-edited.json` appear the first time
you build.

### What actually gets built

```
Assets/CustomCharacter/_Generated/
    MyCharacter_S1.anim         the animation: one keyframe per drawing
    MyCharacter_S1.playable     a Timeline wrapping that animation -- this is what the game loads
    ... one pair per motion, and one per clash on a split skill
    MyCharacter_Standin.prefab  a throwaway character with the game's transform layout, so the
                                animations bind to the right place and Unity can preview them
    MyCharacter_Animations.controller   makes the clips appear in the Animation window
    Preview.unity               the preview scene
    BUILD-REPORT.txt            everything the build did and decided

Mods/MyCharacter/
    motions/customchar_mycharacter_<id>.bundle
    audio/<your sound files>
    mod.json
```

Only the `.anim` and `.playable` pairs go into the bundle; the drawings they
reference come along automatically. The stand-in prefab, the controller and the
preview scene are editor-only — the game supplies the real character.

---

## Extras

### Building from the command line

Not needed for normal use; the window is the workflow.

```sh
"C:\Program Files\Unity\Hub\Editor\6000.3.12f1\Editor\Unity.exe" ^
    -batchmode -nographics -quit ^
    -projectPath "<this folder>" ^
    -executeMethod Limbonia.CustomCharacter.CcBatch.Build ^
    -ccAppearance 10916_Rodion_Thumb_FatherAppearance ^
    -ccName MyCharacter ^
    -ccMods "C:\Program Files (x86)\Steam\steamapps\common\Limbus Company\Mods" ^
    -logFile -
```

Also accepts `-ccFps`, `-ccPpu`, `-ccPivot 0.5,0`, `-ccNoMove`, `-ccBinding` and
`-ccPreview`. Exits non-zero if the build reported an error.

| | |
|---|---|
| `-ccNoGenerate` | Build without regenerating — ship `_Generated/` as it stands. |
| `-ccKeep S1,Parrying` | Do not regenerate these motions. Omit it and `hand-edited.json` is honoured, which is the safe default. |

### Rebuilding the character list

Only needed if a game update added characters the dropdown does not know about.

```sh
pip install UnityPy==1.10.18
python tools/build_target_catalog.py
```

It reads your installed game and rewrites `Assets/Editor/limbus-targets.json`.
Nothing is downloaded and nothing in the game is modified.

### The optional bundle check

If Python is on your PATH, the build also runs `verify_bundle.py` on the archive
it just made and refuses to deploy one that fails. It opens the bundle and
asserts the things that are invisible in the editor: that an `AssetBundle` object
exists, that the internal name is the unique one `mod.json` was written against,
that every declared asset resolves by name, and that every animation inside the
archive still carries its sprite curve, with the right number of drawings, bound
to the right transform path.

```sh
pip install UnityPy==1.10.18
```

Without Python the build says so once and carries on. Set
`LIMBONIA_REQUIRE_BUNDLE_VERIFY=1` to make a missing checker fail the build
instead, or `LIMBONIA_PYTHON` to point at a specific `python.exe`.

### Redrawing the placeholder

```sh
pip install Pillow
python tools/make_example_art.py
```

Puts the blue stick figure back in `Assets/CustomCharacter/Sprites/`, exactly as
it ships.
