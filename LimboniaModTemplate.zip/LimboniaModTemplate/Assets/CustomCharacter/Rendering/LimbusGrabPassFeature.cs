using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.RenderGraphModule.Util;
using UnityEngine.Rendering.Universal;

namespace Limbonia.CustomCharacter
{
    [DisallowMultipleRendererFeature("Limbus Grab Pass")]
    [Tooltip("Copies the screen into a global texture (_GrabbedTexture) after the see-through pass, " +
             "the same way Limbus Company does, so a screen-bending shader can be previewed here.")]
    public class LimbusGrabPassFeature : ScriptableRendererFeature
    {
        [SerializeField]
        string m_GlobalTextureName = "_GrabbedTexture";

        GrabPass m_Pass;

        public override void Create()
        {
            m_Pass = new GrabPass(string.IsNullOrEmpty(m_GlobalTextureName) ? "_GrabbedTexture" : m_GlobalTextureName)
            {
                renderPassEvent = RenderPassEvent.AfterRenderingTransparents,

                requiresIntermediateTexture = true,
            };
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (renderingData.cameraData.cameraType == CameraType.Preview) return;
            if (m_Pass == null) return;
            renderer.EnqueuePass(m_Pass);
        }

        class GrabPass : ScriptableRenderPass
        {
            readonly int m_PropertyId;
            readonly string m_TextureName;

            internal GrabPass(string globalTextureName)
            {
                m_TextureName = globalTextureName;
                m_PropertyId = Shader.PropertyToID(globalTextureName);
            }

            public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
            {
                UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();
                UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
                if (resourceData == null || cameraData == null) return;

                TextureHandle source = resourceData.activeColorTexture;
                if (!source.IsValid()) return;

                RenderTextureDescriptor descriptor = cameraData.cameraTargetDescriptor;
                descriptor.msaaSamples = 1;
                descriptor.depthBufferBits = 0;

                TextureHandle destination = UniversalRenderer.CreateRenderGraphTexture(
                    renderGraph, descriptor, m_TextureName, false, FilterMode.Bilinear);
                if (!destination.IsValid()) return;

                using (var builder = renderGraph.AddBlitPass(
                           source, destination, Vector2.one, Vector2.zero,
                           returnBuilder: true, passName: "Limbus Grab Pass"))
                {
                    builder.SetGlobalTextureAfterPass(destination, m_PropertyId);
                }
            }
        }
    }
}
