Shader "Limbus/Aura Glow Particle"
{
	Properties
	{
		[HDR] _TintColor ("Colour (the thin, outer part)", Color) = (0.18, 1.15, 0.38, 0.35)
		[HDR] _CoreColor ("Hot core colour (push well past 1)", Color) = (2.2, 3.4, 2.4, 1)
		_CoreBias ("Core tightness (LOWER = more of it burns white)", Range(0.3, 8)) = 2.2
		_MainTex ("Texture (optional)", 2D) = "white" {}
		_Intensity ("Brightness", Range(0, 10)) = 1.6
		_SoftEdge ("Edge softness (LOWER is softer)", Range(0.4, 8)) = 1.3
		_Erode ("Hollow out the middle", Range(0, 0.95)) = 0
		_Filament ("Filaments (0 = puff, 1 = threads)", Range(0, 1)) = 0.7
		_Wisp ("Edge tearing", Range(0, 1)) = 0.5
		_Warp ("Shape irregularity", Range(0, 1)) = 0.35
		_NoiseScale ("Detail", Range(1, 12)) = 2.6
		[Enum(UnityEngine.Rendering.BlendMode)] _SrcBlend ("Source blend", Float) = 5
		[Enum(UnityEngine.Rendering.BlendMode)] _DstBlend ("Destination blend", Float) = 1
	}

	SubShader
	{
		Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" "PreviewType"="Plane" }

		Blend [_SrcBlend] [_DstBlend]
		ZWrite Off
		Cull Off
		Lighting Off
		Fog { Mode Off }

		Pass
		{
			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			#pragma multi_compile_particles
			#pragma target 3.0
			#include "UnityCG.cginc"

			sampler2D _MainTex;
			float4 _MainTex_ST;
			fixed4 _TintColor;
			fixed4 _CoreColor;
			half _CoreBias;
			half _Intensity;
			half _SoftEdge;
			half _Erode;
			half _Filament;
			half _Wisp;
			half _Warp;
			half _NoiseScale;

			struct appdata_t {
				float4 vertex : POSITION;
				fixed4 color  : COLOR;
				float2 uv     : TEXCOORD0;
				UNITY_VERTEX_INPUT_INSTANCE_ID
			};

			struct v2f {
				float4 pos    : SV_POSITION;
				fixed4 color  : COLOR;
				float2 uv     : TEXCOORD0;
				float2 raw    : TEXCOORD1;
				UNITY_VERTEX_OUTPUT_STEREO
			};

			float hash21(float2 p)
			{
				p = frac(p * float2(123.34, 456.21));
				p += dot(p, p + 45.32);
				return frac(p.x * p.y);
			}

			float vnoise(float2 p)
			{
				float2 i = floor(p);
				float2 f = frac(p);
				f = f * f * (3.0 - 2.0 * f);
				float a = hash21(i);
				float b = hash21(i + float2(1, 0));
				float c = hash21(i + float2(0, 1));
				float d = hash21(i + float2(1, 1));
				return lerp(lerp(a, b, f.x), lerp(c, d, f.x), f.y);
			}

			static const float FBM_NORM = 1.0 / 0.875;

			float fbm(float2 p)
			{
				float v = 0.0, amp = 0.5;
				[unroll] for (int k = 0; k < 3; ++k) { v += vnoise(p) * amp; p *= 2.03; amp *= 0.5; }
				return saturate(v * FBM_NORM);
			}

			v2f vert (appdata_t v)
			{
				v2f o;
				UNITY_SETUP_INSTANCE_ID(v);
				UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
				o.pos   = UnityObjectToClipPos(v.vertex);
				o.color = v.color;
				o.uv    = TRANSFORM_TEX(v.uv, _MainTex);
				o.raw   = v.uv;
				return o;
			}

			fixed4 frag (v2f i) : SV_Target
			{
				half seed = i.color.r * 7.13 + i.color.g * 3.77 + i.color.b * 1.31;

				float2 q = i.raw * _NoiseScale + float2(seed * 4.0, seed * 7.0);

				float2 warp = float2(fbm(q + 3.1), fbm(q + 7.7)) - 0.5;
				float2 uv   = i.raw + warp * _Warp * 0.4;

				half d    = saturate(length(uv - 0.5) * 2.0);
				half fall = saturate((1.0 - d) / max(1.0 - _Erode, 1e-4));
				fall = pow(fall, _SoftEdge);

				half rid = 1.0 - abs(fbm(q * 1.6) * 2.0 - 1.0);
				rid = pow(saturate(rid), 2.5) * 1.8;
				fall *= lerp(1.0, saturate(rid), _Filament);

				half n   = fbm(q * 0.9);
				half rim = smoothstep(0.0, 0.85, d);
				fall *= lerp(1.0, saturate(n * 1.9), _Wisp * rim);

				half core  = pow(saturate(fall), _CoreBias);
				half3 ramp = lerp(_TintColor.rgb, _CoreColor.rgb, core);

				fixed4 tex = tex2D(_MainTex, i.uv);

				fixed4 col;
				col.rgb = ramp * i.color.rgb * tex.rgb * _Intensity;
				col.a   = fall * tex.a * _TintColor.a * i.color.a;
				return col;
			}
			ENDCG
		}
	}

	Fallback Off
}
