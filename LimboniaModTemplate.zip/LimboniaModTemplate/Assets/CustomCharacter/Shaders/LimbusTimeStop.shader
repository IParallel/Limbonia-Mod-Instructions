Shader "Limbus/Time Stop"
{
	Properties
	{
		_Saturation ("Colour left inside (0 = black and white)", Range(0, 1)) = 0
		_Contrast ("Contrast inside", Range(0.5, 3)) = 1.35
		_Brightness ("Brightness inside", Range(0.2, 2)) = 0.92
		[HDR] _Tint ("Tint inside", Color) = (0.86, 0.88, 1, 1)
		_Strength ("Strength", Range(0, 1)) = 1

		[Header(The wavefront)]
		_Edge ("Where the front sits (in the quad)", Range(0.2, 1)) = 0.94
		_Feather ("Front softness", Range(0.001, 0.4)) = 0.03
		_RingWidth ("Ring width", Range(0, 0.4)) = 0.06
		[HDR] _RingColor ("Ring colour", Color) = (1.6, 1.7, 2.4, 1)
		_RingIntensity ("Ring brightness", Range(0, 6)) = 1.5

		_ScreenSource ("Screen copy: 0 = battle grab, 1 = opaque scene", Range(0, 1)) = 0
		_DebugView ("Debug: show the mask only", Range(0, 1)) = 0
	}

	SubShader
	{
		Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" "PreviewType"="Plane" }

		Blend SrcAlpha OneMinusSrcAlpha
		ZWrite Off
		Cull Off
		Lighting Off
		Fog { Mode Off }

		Pass
		{
			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			#pragma multi_compile_particles
			#pragma target 3.0
			#include "UnityCG.cginc"

			struct appdata {
				float4 vertex : POSITION;
				fixed4 color  : COLOR;
				float2 uv     : TEXCOORD0;
				UNITY_VERTEX_INPUT_INSTANCE_ID
			};

			struct v2f {
				float4 pos       : SV_POSITION;
				fixed4 color     : COLOR;
				float2 quadUV    : TEXCOORD0;
				float4 screenPos : TEXCOORD1;
				UNITY_VERTEX_OUTPUT_STEREO
			};

			sampler2D _GrabbedTexture;
			sampler2D _CameraOpaqueTexture;
			float4 _RTHandleScale;

			fixed4 _Tint, _RingColor;
			float _Saturation, _Contrast, _Brightness, _Strength;
			float _Edge, _Feather, _RingWidth, _RingIntensity;
			float _ScreenSource, _DebugView;

			v2f vert (appdata v)
			{
				v2f o;
				UNITY_SETUP_INSTANCE_ID(v);
				UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
				o.pos       = UnityObjectToClipPos(v.vertex);
				o.quadUV    = v.uv;
				o.screenPos = ComputeScreenPos(o.pos);
				o.color     = v.color;
				return o;
			}

			fixed4 frag (v2f i) : SV_Target
			{
				float d = saturate(length(i.quadUV - 0.5) * 2.0);

				float inside = 1.0 - smoothstep(_Edge - _Feather, _Edge, d);
				float ring = smoothstep(_Edge - _RingWidth, _Edge - _RingWidth * 0.45, d)
				           * (1.0 - smoothstep(_Edge, _Edge + _Feather, d));

				float life = i.color.a;

				if (_DebugView > 0.5)
					return fixed4(inside, ring, 0.0, saturate(inside + ring) * life);

				float2 uv       = i.screenPos.xy / max(i.screenPos.w, 1e-5);
				float2 rtScale  = (_RTHandleScale.x > 0.0) ? _RTHandleScale.xy : float2(1.0, 1.0);
				float2 base     = (_ScreenSource < 0.5) ? uv : uv * rtScale;

				float3 scr = (_ScreenSource < 0.5) ? tex2D(_GrabbedTexture, base).rgb
				                                   : tex2D(_CameraOpaqueTexture, base).rgb;

				float  lum = dot(scr, float3(0.299, 0.587, 0.114));
				float3 col = lerp(lum.xxx, scr, _Saturation);
				col = saturate((col - 0.5) * _Contrast + 0.5) * _Brightness * _Tint.rgb;

				col += _RingColor.rgb * ring * _RingIntensity;

				float a = saturate(inside * _Strength + ring) * life * _Tint.a;
				return fixed4(col, a);
			}
			ENDCG
		}
	}

	Fallback Off
}
