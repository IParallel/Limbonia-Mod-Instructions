Shader "Limbus/Screen Distortion Particle"
{
    Properties
    {
        _MainTex ("Alpha Mask (soft radial)", 2D) = "white" {}
        _BumpMap ("Distortion Normal Map", 2D) = "bump" {}
        [HDR] _TintColor ("Aura Tint (alpha = strength)", Color) = (1, 0.5, 0.2, 0.15)
        _Strength ("Distortion Strength", Range(0, 0.25)) = 0.06
        _Opacity ("Refraction Opacity", Range(0, 1)) = 0.9
        _ScrollX ("Scroll Speed X", Float) = 0.05
        _ScrollY ("Scroll Speed Y (rising heat)", Float) = 0.12
        _EdgeFade ("Edge Softness", Range(0.1, 4)) = 1.0
        _ScreenSource ("Screen copy: 0 = battle grab, 1 = opaque scene", Range(0, 1)) = 0
        [Toggle] _DebugView ("Debug: show distortion as color", Float) = 0
    }

    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" "PreviewType"="Plane" }

        Pass
        {
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            Cull Off
            Lighting Off

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv     : TEXCOORD0;
                fixed4 color  : COLOR;
            };

            struct v2f
            {
                float4 pos       : SV_POSITION;
                float2 uv        : TEXCOORD0;
                float2 quadUV    : TEXCOORD1;
                float4 screenPos : TEXCOORD2;
                fixed4 color     : COLOR;
            };

            sampler2D _MainTex;   float4 _MainTex_ST;
            sampler2D _BumpMap;   float4 _BumpMap_ST;

            sampler2D _GrabbedTexture;
            sampler2D _CameraOpaqueTexture;
            float4 _RTHandleScale;

            fixed4 _TintColor;
            float _Strength, _Opacity, _ScrollX, _ScrollY, _EdgeFade, _ScreenSource, _DebugView;

            v2f vert (appdata v)
            {
                v2f o;
                o.pos       = UnityObjectToClipPos(v.vertex);
                o.uv        = TRANSFORM_TEX(v.uv, _BumpMap);
                o.quadUV    = v.uv;
                o.screenPos = ComputeScreenPos(o.pos);
                o.color     = v.color;
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                float2 flow = float2(_ScrollX, _ScrollY) * _Time.y;

                fixed3 n1 = UnpackNormal(tex2D(_BumpMap, i.uv + flow));
                fixed3 n2 = UnpackNormal(tex2D(_BumpMap, i.uv * 1.3 - flow * 0.7));
                float2 distort = (n1.xy + n2.xy) * 0.5;

                float2 c = i.quadUV - 0.5;
                float dist = length(c) * 2.0;
                fixed radial = smoothstep(0.0, 1.0, saturate(1.0 - dist));

                fixed texMask = tex2D(_MainTex, TRANSFORM_TEX(i.quadUV, _MainTex)).a;
                fixed mask = pow(saturate(radial * texMask), _EdgeFade);

                float amount = _Strength * i.color.a;

                if (_DebugView > 0.5)
                {
                    return fixed4(distort * 0.5 + 0.5, 0.5, mask * i.color.a);
                }

                float2 uv = i.screenPos.xy / max(i.screenPos.w, 1e-5);
                uv += distort * amount;

                float2 rtScale = (_RTHandleScale.x > 0.0) ? _RTHandleScale.xy : float2(1.0, 1.0);

                fixed3 grabbed = tex2D(_GrabbedTexture, uv).rgb;
                fixed3 opaque  = tex2D(_CameraOpaqueTexture, uv * rtScale).rgb;
                fixed3 scene   = lerp(grabbed, opaque, saturate(_ScreenSource));

                float tintAmt = _TintColor.a * mask * i.color.a;
                fixed3 rgb = scene + _TintColor.rgb * tintAmt;

                float outA = mask * _Opacity;
                return fixed4(rgb, outA);
            }
            ENDCG
        }
    }
    Fallback Off
}
