Shader "Limbus/Screen Effect Particle"
{
	Properties
	{
		_Blur ("Blur radius (% of screen)", Range(0, 5)) = 1.2
		_Amount ("Strength", Range(0, 1)) = 1
		[HDR] _Tint ("Tint (multiplies)", Color) = (1, 1, 1, 1)
		_Saturation ("Saturation (0 = grey)", Range(0, 2)) = 1
		_Brightness ("Brightness", Range(0, 3)) = 1
		_MainTex ("Mask texture (optional, alpha)", 2D) = "white" {}
		_EdgeFade ("Edge fade", Range(0.2, 6)) = 1.5
		_ScreenSource ("Screen copy: 0 = battle grab, 1 = opaque scene", Range(0, 1)) = 0
		_DebugView ("Debug: show the mask only", Range(0, 1)) = 0
	}

	SubShader
	{
		Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" "PreviewType"="Plane" }

		Blend SrcAlpha OneMinusSrcAlpha
		ZWrite Off
		Cull Off
		Lighting Off
		Fog { Mode Off }

		Pass
		{
			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			#pragma multi_compile_particles
			#pragma target 3.0
			#include "UnityCG.cginc"

			struct appdata {
				float4 vertex : POSITION;
				fixed4 color  : COLOR;
				float2 uv     : TEXCOORD0;
				UNITY_VERTEX_INPUT_INSTANCE_ID
			};

			struct v2f {
				float4 pos       : SV_POSITION;
				fixed4 color     : COLOR;
				float2 quadUV    : TEXCOORD0;
				float4 screenPos : TEXCOORD1;
				UNITY_VERTEX_OUTPUT_STEREO
			};

			sampler2D _MainTex;   float4 _MainTex_ST;

			sampler2D _GrabbedTexture;
			sampler2D _CameraOpaqueTexture;
			float4 _RTHandleScale;

			fixed4 _Tint;
			float _Blur, _Amount, _Saturation, _Brightness, _EdgeFade, _ScreenSource, _DebugView;

			v2f vert (appdata v)
			{
				v2f o;
				UNITY_SETUP_INSTANCE_ID(v);
				UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
				o.pos       = UnityObjectToClipPos(v.vertex);
				o.quadUV    = v.uv;
				o.screenPos = ComputeScreenPos(o.pos);
				o.color     = v.color;
				return o;
			}

			float3 SampleScreen(float2 t)
			{
				return (_ScreenSource < 0.5) ? tex2D(_GrabbedTexture, t).rgb
				                             : tex2D(_CameraOpaqueTexture, t).rgb;
			}

			fixed4 frag (v2f i) : SV_Target
			{
				float2 c    = i.quadUV - 0.5;
				fixed radial = smoothstep(0.0, 1.0, saturate(1.0 - length(c) * 2.0));
				fixed texMask = tex2D(_MainTex, TRANSFORM_TEX(i.quadUV, _MainTex)).a;
				fixed mask   = pow(saturate(radial * texMask), _EdgeFade);

				if (_DebugView > 0.5)
					return fixed4(mask.xxx, mask * i.color.a);

				float2 uv = i.screenPos.xy / max(i.screenPos.w, 1e-5);

				float2 rtScale  = (_RTHandleScale.x > 0.0) ? _RTHandleScale.xy : float2(1.0, 1.0);
				float2 srcScale = (_ScreenSource < 0.5) ? float2(1.0, 1.0) : rtScale;
				float2 base     = uv * srcScale;

				float2 aspect = float2(_ScreenParams.y / max(_ScreenParams.x, 1.0), 1.0);
				float2 r      = _Blur * 0.01 * aspect * srcScale * mask;

				static const float2 TAPS[12] = {
					float2( 1.000,  0.000), float2( 0.500,  0.866), float2(-0.500,  0.866),
					float2(-1.000,  0.000), float2(-0.500, -0.866), float2( 0.500, -0.866),
					float2( 0.383,  0.924), float2(-0.924,  0.383), float2(-0.383, -0.924),
					float2( 0.924, -0.383), float2( 0.707,  0.707), float2(-0.707, -0.707)
				};

				float3 sum = SampleScreen(base) * 2.0;
				float  wsum = 2.0;
				[unroll] for (int k = 0; k < 12; ++k)
				{
					float scale = (k < 6) ? 1.0 : 0.55;
					sum  += SampleScreen(base + TAPS[k] * r * scale);
					wsum += 1.0;
				}
				float3 col = sum / wsum;

				float lum = dot(col, float3(0.299, 0.587, 0.114));
				col = lerp(lum.xxx, col, _Saturation);
				col *= _Tint.rgb * _Brightness;

				return fixed4(col, mask * _Amount * _Tint.a * i.color.a);
			}
			ENDCG
		}
	}

	Fallback Off
}
