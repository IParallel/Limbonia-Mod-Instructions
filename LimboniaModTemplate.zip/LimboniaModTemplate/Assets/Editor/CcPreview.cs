using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;
using UnityEngine.Timeline;

namespace Limbonia.CustomCharacter
{
    public static class CcPreview
    {
        public const string ScenePath = CcBuild.GeneratedRoot + "/Preview.unity";
        public const string CharacterObjectName = "Character";

        const float FallbackHeight = 5f;

        public static bool Build(string prefabPath, string modName, List<CcBuild.MotionBuild> built,
                                 Action<string> log)
        {
            if (log == null) log = s => { };

            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            if (prefab == null)
                throw new Exception("the stand-in character is not at " + prefabPath +
                                    ", so the preview has nothing to show");

            CcBuild.EnsureFolder(CcBuild.GeneratedRoot);

            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                log("preview scene: skipped -- you chose not to save the scene that was open. Everything else " +
                    "was built and deployed. Use \"Open the preview scene\" in the window when you are ready.");
                return false;
            }

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var root = new GameObject(modName + " preview");

            var character = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
            character.name = CharacterObjectName;
            character.transform.position = Vector3.zero;
            character.transform.SetParent(root.transform, true);

            var animator = character.GetComponent<Animator>();
            if (animator == null) animator = character.AddComponent<Animator>();
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            if (animator.runtimeAnimatorController == null)
                log("WARNING: the character has no animation list, so the Animation window will not offer the " +
                    "clips. Build again; if it keeps happening, drag the .controller from " +
                    CcBuild.GeneratedRoot + " onto the character's Animator.");

            bool visibleAtRest = false;
            foreach (SpriteRenderer sr in character.GetComponentsInChildren<SpriteRenderer>(true))
                if (sr.sprite != null) { visibleAtRest = true; break; }
            if (!visibleAtRest)
                log("WARNING: the character has no resting drawing, so this scene will look EMPTY until you " +
                    "scrub an animation. That is a preview problem, not a broken mod -- but it also means an " +
                    "empty scene here cannot tell you anything. See the stand-in section of the build report.");

            float height = MeasureHeight(prefabPath);

            var camGo = new GameObject("Preview Camera");
            camGo.transform.SetParent(root.transform, false);
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = Mathf.Max(1.5f, height * 0.62f);
            cam.transform.position = new Vector3(0f, height * 0.5f, -10f);
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.16f, 0.16f, 0.19f, 1f);
            cam.nearClipPlane = 0.01f;
            cam.farClipPlane = 100f;
            camGo.tag = "MainCamera";
            if (camGo.GetComponent<AudioListener>() == null) camGo.AddComponent<AudioListener>();

            BuildGuides(root.transform, height, log);
            BuildSoundStations(root.transform, character, built, log);
            BuildNotes(root.transform, built);

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new Exception("Unity refused to save the preview scene to " + ScenePath);

            Selection.activeGameObject = character;
            SceneView sv = SceneView.lastActiveSceneView;
            if (sv != null)
            {
                sv.in2DMode = true;
                sv.Frame(new Bounds(new Vector3(0f, height * 0.5f, 0f),
                                    new Vector3(height * 1.6f, height * 1.3f, 1f)), false);
            }

            log("");
            log("preview scene: " + ScenePath + "   (open, with " + CharacterObjectName + " selected)");
            log("  To ADD OR MOVE A SOUND: select a motion under \"Sound and effects\" in the Hierarchy, open");
            log("  Window > Sequencing > Timeline, and drag a .wav or .ogg from " + CcAudio.SoundsRoot);
            log("  onto the audio track. Scrub -- Unity plays it against the drawings, off the same clock");
            log("  Limbonia uses. Build again and it is written into mod.json for you.");
            log("  To ADD OR MOVE AN EFFECT OF YOUR OWN: same place, but drag a prefab from " +
                CcEffects.EffectsRoot);
            log("  onto the timeline (choose \"Control Track\" if Unity asks which kind of track). Scrub -- the");
            log("  effect appears and disappears exactly as it will in game. Build again and its time, its");
            log("  length and the prefab's own position are written into mod.json for you.");
            log("  " + CcVfx.PreviewScaleNote);
            log("  This preview camera frames the character at about 81% of the view's height, whatever size your " +
                "art is. A different camera in game scales the character and your effect together, so it cannot " +
                "make an effect look faster THAN THE CHARACTER -- only the pivot above can do that.");
            log("  Window > Animation > Animation, pick a motion from the dropdown, and scrub. The Scene view");
            log("  follows. No Play mode needed.");
            log("  The yellow line at y=0 is the floor: with the pivot right, the feet touch it on every frame.");
            log("  The character is visible before you play anything -- that is the resting drawing. An EMPTY");
            log("  scene now means something is genuinely wrong, rather than being the normal state.");
            return true;
        }

        public static bool Open()
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) return false;
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return false;
            EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            return true;
        }

        static float MeasureHeight(string prefabPath)
        {
            float tallest = 0f;
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);

            if (prefab != null)
                foreach (SpriteRenderer sr in prefab.GetComponentsInChildren<SpriteRenderer>(true))
                    if (sr.sprite != null && sr.sprite.pixelsPerUnit > 0f)
                        tallest = Mathf.Max(tallest, sr.sprite.rect.height / sr.sprite.pixelsPerUnit);

            var animator = prefab != null ? prefab.GetComponent<Animator>() : null;
            var controller = animator != null ? animator.runtimeAnimatorController : null;
            if (controller != null)
                foreach (AnimationClip clip in controller.animationClips)
                {
                    if (clip == null) continue;
                    foreach (EditorCurveBinding b in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                        foreach (ObjectReferenceKeyframe k in AnimationUtility.GetObjectReferenceCurve(clip, b))
                        {
                            var sprite = k.value as Sprite;
                            if (sprite == null || sprite.pixelsPerUnit <= 0f) continue;
                            tallest = Mathf.Max(tallest, sprite.rect.height / sprite.pixelsPerUnit);
                        }
                }
            return tallest > 0.1f ? tallest : FallbackHeight;
        }

        static void BuildGuides(Transform parent, float height, Action<string> log)
        {
            Sprite pixel = EnsurePixelSprite(log);
            if (pixel == null) return;

            var guides = new GameObject("Guides  (the feet should touch the floor line on every frame)");
            guides.transform.SetParent(parent, false);

            float span = Mathf.Max(8f, height * 2.5f);

            Bar(guides.transform, "Floor  y=0  <- your pivot puts the character here", pixel,
                new Vector3(0f, 0f, 0.5f), new Vector3(span, 0.02f, 1f),
                new Color(0.95f, 0.85f, 0.35f, 0.85f));

            Bar(guides.transform, "Centre  x=0", pixel,
                new Vector3(0f, height * 0.5f, 0.5f), new Vector3(0.015f, height * 1.2f, 1f),
                new Color(0.45f, 0.65f, 0.95f, 0.55f));

            Bar(guides.transform, "1 world unit tall (= pixels-per-unit pixels of your art)", pixel,
                new Vector3(-span * 0.45f, 0.5f, 0.5f), new Vector3(0.02f, 1f, 1f),
                new Color(0.55f, 0.9f, 0.55f, 0.7f));
        }

        static void Bar(Transform parent, string name, Sprite pixel, Vector3 pos, Vector3 scale, Color colour)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = scale;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = pixel;
            sr.color = colour;
            sr.sortingOrder = -50;
        }

        static Sprite EnsurePixelSprite(Action<string> log)
        {
            string assetPath = CcBuild.GeneratedRoot + "/PreviewGuide.png";
            var existing = AssetDatabase.LoadAssetAtPath<Sprite>(assetPath);
            if (existing != null) return existing;

            try
            {
                var tex = new Texture2D(4, 4, TextureFormat.RGBA32, false);
                var px = new Color32[16];
                for (int i = 0; i < px.Length; i++) px[i] = new Color32(255, 255, 255, 255);
                tex.SetPixels32(px);
                tex.Apply();
                byte[] png = tex.EncodeToPNG();
                UnityEngine.Object.DestroyImmediate(tex);

                File.WriteAllBytes(Path.GetFullPath(assetPath), png);
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);

                var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                if (importer != null)
                {
                    importer.textureType = TextureImporterType.Sprite;
                    importer.spriteImportMode = SpriteImportMode.Single;
                    importer.mipmapEnabled = false;
                    importer.alphaIsTransparency = true;
                    importer.filterMode = FilterMode.Point;
                    importer.textureCompression = TextureImporterCompression.Uncompressed;
                    var s = new TextureImporterSettings();
                    importer.ReadTextureSettings(s);
                    s.spriteAlignment = (int)SpriteAlignment.Center;
                    s.spritePixelsPerUnit = 4f;
                    s.spriteMeshType = SpriteMeshType.FullRect;
                    importer.SetTextureSettings(s);
                    importer.SaveAndReimport();
                }
                return AssetDatabase.LoadAssetAtPath<Sprite>(assetPath);
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                if (log != null)
                    log("preview: the floor/centre guide could not be created (" + e.Message + "). The preview " +
                        "still works; you just have no reference line for the pivots.");
                return null;
            }
        }

        static void BuildSoundStations(Transform parent, GameObject character,
                                       List<CcBuild.MotionBuild> built, Action<string> log)
        {
            if (built == null || built.Count == 0) return;

            var root = new GameObject("Sound and effects  (pick an animation below, then Window > Sequencing > " +
                                      "Timeline, and drag a .wav or an effect prefab on)");
            root.transform.SetParent(parent, false);

            var source = root.AddComponent<AudioSource>();
            source.playOnAwake = false;
            source.loop = false;
            source.spatialBlend = 0f;

            Animator animator = character != null ? character.GetComponent<Animator>() : null;

            int wired = 0, withSound = 0, withEffects = 0;
            foreach (CcBuild.MotionBuild mb in built)
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(mb.TimelinePath);
                if (timeline == null) continue;

                var go = new GameObject(mb.Label);
                go.transform.SetParent(root.transform, false);

                var director = go.AddComponent<PlayableDirector>();
                director.playableAsset = timeline;
                director.playOnAwake = false;
                director.extrapolationMode = DirectorWrapMode.None;
                director.time = 0.0;

                foreach (TrackAsset track in timeline.GetOutputTracks())
                {
                    if (animator != null && track is AnimationTrack) director.SetGenericBinding(track, animator);
                    else if (track is AudioTrack) { director.SetGenericBinding(track, source); withSound++; }
                    else if (track is ControlTrack) withEffects++;
                }
                wired++;
            }

            if (log != null && wired > 0)
            {
                log("");
                log("timeline stations: " + wired + " timeline(s) under \"Sound and effects\" in the " +
                    "Hierarchy -- one per animation, so a motion split into coins has one station per clash" +
                    (withSound > 0 ? ", " + withSound + " already carrying an audio track" : "") +
                    (withEffects > 0 ? ", " + withEffects + " already carrying an effect track" : ""));
            }
        }

        static void BuildNotes(Transform parent, List<CcBuild.MotionBuild> built)
        {
            var how = new GameObject("HOW TO WATCH THE ANIMATIONS");
            how.transform.SetParent(parent, false);
            Child(how, "1. Select 'Character', open Window > Animation > Animation");
            Child(how, "2. Pick a motion from the clip dropdown (" + (built != null ? built.Count : 0) +
                       " of them) and scrub the timeline");
            Child(how, "3. The Scene view follows as you drag -- no Play mode needed");
            Child(how, "4. The feet should touch the yellow floor line on EVERY frame; if not, your pivot is off");
            Child(how, "5. The pose you see BEFORE playing anything is the resting drawing (Default's first " +
                       "frame). If this scene ever opens EMPTY, something IS wrong -- art that did not import, " +
                       "or a wrong binding path.");

            var sound = new GameObject("HOW TO ADD A SOUND  (and hear it here, before the game)");
            sound.transform.SetParent(parent, false);
            Child(sound, "1. Put a .wav or .ogg in " + CcAudio.SoundsRoot + "   (those two formats ONLY)");
            Child(sound, "2. Select the motion you want under 'Sound and effects' in this Hierarchy");
            Child(sound, "3. Window > Sequencing > Timeline, then drag the file onto the timeline where it " +
                         "should play");
            Child(sound, "4. Scrub. You hear it against the drawings -- Unity and Limbonia use the same clock, " +
                         "so this IS the timing you will get in game");
            Child(sound, "5. Build again: the build writes it into mod.json and copies the file into the mod " +
                         "folder for you");
            Child(sound, "The audio track is never put in the bundle -- the game's runtime cannot read one. " +
                         "It is a build-time instruction, not shipped data.");
            Child(sound, "Only the START time carries over: in game the file plays once, to its own end. " +
                         "Trimming or looping the clip here changes nothing.");
            Child(sound, "On a multi-coin skill declared for every coin, the sound plays on the FIRST clash " +
                         "only. To get one on every clash, name that motion's drawings by coin -- 0_1.png, " +
                         "0_2.png for the first clash, 1_1.png, 1_2.png for the second -- and each clash gets " +
                         "its own station here, with its own sound.");

            var vfx = new GameObject("HOW TO PLACE AN EFFECT OF YOUR OWN  (and see it here, before the game)");
            vfx.transform.SetParent(parent, false);
            Child(vfx, "1. Put a script-free prefab in " + CcEffects.EffectsRoot +
                       "   (particles, an animator, a trail, a sprite)");
            Child(vfx, "2. Select the motion you want under 'Sound and effects' in this Hierarchy");
            Child(vfx, "3. Window > Sequencing > Timeline, then drag the prefab onto the timeline where it " +
                       "should play. Choose 'Control Track' if Unity asks which kind of track.");
            Child(vfx, "4. Scrub. The effect is created, switched on as the playhead enters the clip and off " +
                       "as it leaves -- which is exactly what happens in game.");
            Child(vfx, "5. Build again: the time, the length and the prefab's OWN ROOT POSITION are written " +
                       "into mod.json for you.");
            Child(vfx, "WHERE IT SITS COMES FROM THE PREFAB, not from the clip. The game writes that offset " +
                       "straight into the effect's position every time it plays, so open the prefab and move " +
                       "its root to move it in game.");
            Child(vfx, "SAME EFFECT IN TWO PLACES? Make a Prefab Variant, move the variant's root, and drop " +
                       "that on instead. One prefab is always in one place.");
            Child(vfx, "SIZE IS THE ONE THING THAT DOES NOT MATCH: " + CcVfx.PreviewScaleNote);
            Child(vfx, "The control track is never put in the bundle -- Limbonia builds its own effect track " +
                       "on the coin, and a second one would fight it. It is a build-time instruction.");
            Child(vfx, "A build only ever rewrites the placements IT made (they are marked \"from\": \"unity\" " +
                       "in mod.json). Anything you added by hand, or in the companion, is left alone.");
            Child(vfx, "MUTE the effect track to hand its placements back: a muted track is never read.");

            var coins = new GameObject("HOW TO GIVE EACH CLASH ITS OWN ANIMATION  (coins)");
            coins.transform.SetParent(parent, false);
            Child(coins, "A skill is played one CLASH at a time -- the game calls them coins -- and by default " +
                         "your one animation plays on all of them. A three-coin S1 plays your S1 three times.");
            Child(coins, "TO DRAW THEM SEPARATELY: put the coin number in front of the file name, with an " +
                         "underscore. Sprites/S1/0_1.png, 0_2.png, 0_3.png is the FIRST clash. 1_1.png, 1_2.png " +
                         "is the second. 2_1.png is the third.");
            Child(coins, "COUNTING STARTS AT 0, because that is the number the game itself uses: coin 0 is the " +
                         "first clash.");
            Child(coins, "Each one becomes its own animation, its own station under 'Sound and effects' above, " +
                         "and its own line in mod.json -- so each clash can have its own sound, its own effects " +
                         "and its own camera work.");
            Child(coins, "YOU ONLY HAVE TO DRAW THE ONES YOU WANT. A clash you do not name keeps the ORIGINAL " +
                         "character's animation for that clash -- it does not fall back to your other drawings.");
            Child(coins, "MIX AND MATCH IS NOT ALLOWED WITHIN ONE FOLDER: either every drawing in it names a " +
                         "coin, or none does. Half and half is built as one animation and the build report says so.");
            Child(coins, "Leave the names alone (01.png, 02.png ...) and nothing changes -- one animation for the " +
                         "whole skill, which is what almost every mod wants.");

            var not = new GameObject("WHAT THIS PREVIEW CANNOT SHOW  (all of it is correct, none of it is a bug)");
            not.transform.SetParent(parent, false);
            Child(not, "MOVEMENT -- lives in mod.json 'move'; Limbonia moves the character at runtime");
            Child(not, "CAMERA SHAKE -- also mod.json, also runtime");
            Child(not, "THE DAMAGE / HIT / END BEATS -- Limbonia builds its own timing when it installs this");
            Child(not, "THE CHARACTER'S OWN VFX and trails -- a vanilla motion has ~19 tracks; a custom bundle " +
                       "has one. Effects YOU ship are the exception and do preview here.");
            Child(not, "So an animation that plays ON THE SPOT here is right");
            Child(not, "SOUND AND YOUR OWN EFFECTS ARE THE EXCEPTIONS -- the Timeline window really does play " +
                       "both");
        }

        static void Child(GameObject parent, string name)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent.transform, false);
        }
    }
}
