using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.Timeline;

namespace Limbonia.CustomCharacter
{
    public enum CcBuildMode
    {
        Regenerate = 0,

        UseExisting = 1,
    }

    public class CcBuildOptions
    {
        public string AppearanceName;
        public string ModName = "MyCharacter";
        public string ModsFolder;
        public float Fps = 12f;
        public float Ppu = 100f;
        public float PivotX = 0.5f;
        public float PivotY = 0f;
        public bool StepTowardsTarget = true;
        public bool OpenPreview = true;
        public string BindingPathOverride;

        public string Renderer = CcManifest.RendererSidecar;

        public CcBuildMode Mode = CcBuildMode.Regenerate;

        public HashSet<string> KeepMotions = new HashSet<string>(StringComparer.Ordinal);

        public bool KeepsMotion(string motion)
        {
            return Mode == CcBuildMode.UseExisting || (KeepMotions != null && KeepMotions.Contains(motion));
        }
    }

    public static class CcBuild
    {
        public const string SpritesRoot = "Assets/CustomCharacter/Sprites";

        public const string GeneratedRoot = "Assets/CustomCharacter/_Generated";

        public static readonly string[] Motions =
        {
            "Default", "Idle", "Move", "Guard", "Damaged", "Evade", "Dead", "Parrying", "S1", "S2", "S3",
        };

        public const double MinDuration = 0.06;

        public static List<string> MotionsToBuild()
        {
            var all = new List<string>(Motions);
            var known = new HashSet<string>(Motions, StringComparer.Ordinal);
            var extra = new List<string>();
            foreach (string m in SpriteFolderNames())
                if (!known.Contains(m) && CcTargets.IsKnownMotion(m)) extra.Add(m);
            extra.Sort(StringComparer.Ordinal);
            all.AddRange(extra);
            return all;
        }

        public static List<string> UnknownSpriteFolders()
        {
            var known = new HashSet<string>(Motions, StringComparer.Ordinal);
            var bad = new List<string>();
            foreach (string m in SpriteFolderNames())
                if (!known.Contains(m) && !CcTargets.IsKnownMotion(m)) bad.Add(m);
            bad.Sort(StringComparer.Ordinal);
            return bad;
        }

        static List<string> SpriteFolderNames()
        {
            var names = new List<string>();
            try
            {
                string abs = Path.GetFullPath(SpritesRoot);
                if (!Directory.Exists(abs)) return names;
                foreach (string d in Directory.GetDirectories(abs)) names.Add(Path.GetFileName(d));
            }
            catch { }
            return names;
        }

        public const string PlaceholderMarker = "_placeholder.txt";

        public class ScaffoldResult
        {
            public List<string> Seeded = new List<string>();
            public List<string> Empty = new List<string>();
            public List<string> LeftAlone = new List<string>();
            public string Problem;
            public string SeededFrom;
        }

        public static ScaffoldResult Scaffold(string appearanceName, Action<string> log)
        {
            var r = new ScaffoldResult();
            if (log == null) log = s => { };

            Target t = CcTargets.ByName(appearanceName);
            if (t == null)
            {
                r.Problem = string.IsNullOrEmpty(appearanceName)
                    ? "No character is chosen, so there is no motion list to read. Pick one in \"Replaces\" first."
                    : appearanceName + " is not in " + CcTargets.CatalogPath + ", so its motion list is not known " +
                      "here. Pick a character from the list, or rebuild the catalog with: python " +
                      "tools/build_target_catalog.py";
                return r;
            }

            string source = FirstFrameIn("Default") ?? FirstFrameIn("Idle");
            r.SeededFrom = source;

            EnsureFolder(SpritesRoot);
            foreach (TargetMotion m in t.Motions)
            {
                string motion = m.Motion;
                if (string.IsNullOrEmpty(motion) || Sanitize(motion) != motion) continue;

                string folder = SpritesRoot + "/" + motion;
                string abs = Path.GetFullPath(folder);

                if (Directory.Exists(abs) && FramesIn(motion).Count > 0) { r.LeftAlone.Add(motion); continue; }

                EnsureFolder(folder);
                if (source == null || !File.Exists(Path.GetFullPath(source)))
                {
                    WriteMarker(motion, null, 0, null);
                    r.Empty.Add(motion);
                    continue;
                }

                string dst = folder + "/01" + Path.GetExtension(source);
                try
                {
                    File.Copy(Path.GetFullPath(source), Path.GetFullPath(dst), false);
                    AssetDatabase.ImportAsset(dst);
                    WriteMarker(motion, Path.GetFileName(dst), new FileInfo(Path.GetFullPath(dst)).Length, source);
                    r.Seeded.Add(motion);
                }
                catch (Exception e)
                {
                    log("WARNING: could not put a starting frame in " + folder + " (" + e.Message +
                        "). The folder is there and empty; draw into it.");
                    r.Empty.Add(motion);
                }
            }

            AssetDatabase.Refresh();
            return r;
        }

        public static bool IsPlaceholder(string motion)
        {
            try
            {
                string marker = Path.GetFullPath(SpritesRoot + "/" + motion + "/" + PlaceholderMarker);
                if (!File.Exists(marker)) return false;

                string seededName = null;
                long seededSize = -1;
                foreach (string line in File.ReadAllLines(marker))
                {
                    if (!line.StartsWith("seeded: ", StringComparison.Ordinal)) continue;
                    string[] parts = line.Substring(8).Split('\t');
                    if (parts.Length != 2) continue;
                    seededName = parts[0];
                    long.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out seededSize);
                }

                List<string> frames = FramesIn(motion);
                if (seededName == null) return frames.Count == 0;
                if (frames.Count != 1) return false;
                if (!string.Equals(Path.GetFileName(frames[0]), seededName, StringComparison.Ordinal)) return false;
                return new FileInfo(Path.GetFullPath(frames[0])).Length == seededSize;
            }
            catch { return false; }
        }

        public static void ClearPlaceholder(string motion)
        {
            try
            {
                string rel = SpritesRoot + "/" + motion + "/" + PlaceholderMarker;
                if (!File.Exists(Path.GetFullPath(rel))) return;
                if (!AssetDatabase.DeleteAsset(rel)) File.Delete(Path.GetFullPath(rel));
            }
            catch { }
        }

        static void WriteMarker(string motion, string seededFile, long seededSize, string from)
        {
            try
            {
                string rel = SpritesRoot + "/" + motion + "/" + PlaceholderMarker;
                var sb = new StringBuilder();
                sb.AppendLine("This folder was set up for you. Nothing in it is drawn yet.");
                sb.AppendLine();
                if (seededFile != null)
                {
                    sb.AppendLine("The one frame in here is a copy of your standing pose (" + from + "), so this");
                    sb.AppendLine("motion is covered rather than falling back to the original character. Redraw it.");
                    sb.AppendLine();
                    sb.AppendLine("seeded: " + seededFile + "\t" +
                                  seededSize.ToString(CultureInfo.InvariantCulture));
                }
                else
                {
                    sb.AppendLine("It is empty: there was no Default or Idle frame to copy when it was made.");
                }
                sb.AppendLine();
                sb.AppendLine("Draw into this folder and this file disappears on the next build. Delete it by hand");
                sb.AppendLine("at any time -- it changes nothing about the mod, it only stops the build reporting");
                sb.AppendLine("this motion as \"still a placeholder\".");
                File.WriteAllText(Path.GetFullPath(rel), sb.ToString());
                AssetDatabase.ImportAsset(rel);
            }
            catch { }
        }

        static bool IsDrawing(string path)
        {
            string ext = Path.GetExtension(path).ToLowerInvariant();
            return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga" || ext == ".psd";
        }

        public static List<string> FramesIn(string motion)
        {
            return DrawingsIn(motion).Frames;
        }

        static string FirstFrameIn(string motion)
        {
            List<string> f = FramesIn(motion);
            return f.Count > 0 ? f[0] : null;
        }

        static readonly List<string> Log = new List<string>();
        static void L(string s) { Log.Add(s); }
        static void LWarn(string s) { Log.Add("WARNING: " + s); }
        static void LErr(string s) { Log.Add("ERROR:   " + s); }

        public static string LastReportPath { get; private set; }

        public static bool HadErrors { get; private set; }

        public static void Run(CcBuildOptions o)
        {
            Log.Clear();
            LastReportPath = null;
            HadErrors = false;
            string bundleName = null;
            try
            {
                string how;
                string bundleId = CcManifest.ResolveBundleId(DeployDirOf(o), o.ModName, o.AppearanceName, out how);
                bundleName = CcManifest.MakeBundleName(o.ModName, bundleId);
                RunInner(o, bundleName, bundleId, how);
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                LErr(e.Message);
                LErr("BUILD STOPPED. Nothing was written to your Mods folder, so the game still sees whatever " +
                     "was there before.");
                CcBundle.WarnAboutStaleDeploy(bundleName, DeployDirOf(o), L);
                Debug.LogException(e);
            }
            finally
            {
                try { CcAudio.RestorePending(L); }
                catch (Exception e) { LWarn("could not put the sound back on the timelines: " + e.Message); }
                try { CcVfx.RestorePending(L); }
                catch (Exception e) { LWarn("could not put the effects back on the timelines: " + e.Message); }
                EditorUtility.ClearProgressBar();
                Flush(o);
            }
        }

        static void Flush(CcBuildOptions o)
        {
            var sb = new StringBuilder();
            foreach (string line in Log) sb.AppendLine(line);
            string text = sb.ToString();

            int errors = Log.Count(l => l.StartsWith("ERROR"));
            int warnings = Log.Count(l => l.StartsWith("WARNING"));
            HadErrors = errors > 0;

            try
            {
                EnsureFolder(GeneratedRoot);
                string path = GeneratedRoot + "/BUILD-REPORT.txt";
                File.WriteAllText(Path.GetFullPath(path), text);
                AssetDatabase.ImportAsset(path);
                LastReportPath = path;
            }
            catch (Exception e) { Debug.LogWarning("[CustomCharacter] could not write the build report: " + e.Message); }

            if (errors > 0) Debug.LogError("[CustomCharacter] " + errors + " error(s):\n" + text);
            else if (warnings > 0) Debug.LogWarning("[CustomCharacter] " + warnings + " warning(s):\n" + text);
            else Debug.Log("[CustomCharacter]\n" + text);
        }

        static void RunInner(CcBuildOptions o, string bundleName, string bundleId, string bundleIdHow)
        {
            L("=== Limbonia CustomCharacter ===");

            if (o.KeepMotions == null) o.KeepMotions = CcEdits.LoadKeep();
            if (o.Mode == CcBuildMode.UseExisting)
            {
                L("MODE: BUILD WITHOUT REGENERATING.");
                L("  Nothing is generated from " + SpritesRoot + ". The animations and timelines already in");
                L("  " + GeneratedRoot + " are packed, declared and deployed exactly as they are -- including");
                L("  anything you authored by hand. Your drawings are NOT re-read, so new frames will not appear.");
            }
            else
            {
                L("MODE: REGENERATE FROM DRAWINGS.");
                L("  Every animation is rebuilt from " + SpritesRoot + ", REPLACING what was in " + GeneratedRoot + ".");
                L("  Three things survive that: sound placed on a timeline, effects placed on a timeline, and");
                L("  hand-authored curves on a clip (position, rotation, scale) -- all three are lifted off and");
                L("  put back. Anything else you changed by hand -- retimed sprite keys, other extra tracks, a");
                L("  restructured timeline -- is overwritten.");
                if (o.KeepMotions.Count > 0)
                {
                    var kept = new List<string>(o.KeepMotions);
                    kept.Sort();
                    L("  KEPT, NOT REGENERATED: " + string.Join(", ", kept.ToArray()) +
                      "  (from " + CcEdits.KeepFile + ")");
                }
                else
                {
                    L("  No motion is on the keep list. Tick \"keep my edits\" beside a motion in the window if");
                    L("  you have restructured its timeline or retimed its keys and want it left alone.");
                }
            }
            L("");
            L("Unity " + Application.unityVersion + "   (the game loads bundles built by 6000.3.12f1)");
            if (Application.unityVersion != "6000.3.12f1")
                LWarn("this editor is " + Application.unityVersion + ", not 6000.3.12f1. Shipped game bundles are " +
                      "UnityFS format 8 and older editors emit format 7, which the game refuses. The header check " +
                      "later in this build will catch it, but you should be on 6000.3.12f1.");

            if (string.IsNullOrEmpty(o.AppearanceName))
                throw new Exception("no character chosen. Pick one in the \"Replaces\" dropdown -- a mod always " +
                                    "replaces a character the game already has; Limbonia cannot add a new one.");
            if (string.IsNullOrEmpty(o.ModsFolder))
                throw new Exception("no Mods folder set. It is the \"Mods\" folder next to LimbusCompany.exe.");

            Target target = CcTargets.ByName(o.AppearanceName);
            L("");
            L("replacing: " + o.AppearanceName);
            if (target == null)
                LWarn("that character is not in " + CcTargets.CatalogPath + ", so its coin counts and its curve " +
                      "binding path are not known. The build continues with the standard path, which is right for " +
                      "178 of the 179 characters measured -- but if nothing shows up in game, that is the first " +
                      "thing to suspect. Rebuild the catalog with: python tools/build_target_catalog.py");

            string bindingPath = ResolveBindingPath(o, target);
            ExplainRenderer(o);

            List<string> motionsToBuild = MotionsToBuild();

            foreach (string motion in motionsToBuild)
                if (!IsPlaceholder(motion)) ClearPlaceholder(motion);

            var found = CollectFrames(motionsToBuild, o.Mode == CcBuildMode.UseExisting);
            int totalFrames = found.Sum(kv => kv.Value.Frames.Count);
            if (totalFrames == 0 && o.Mode == CcBuildMode.Regenerate)
                throw new Exception("no images found under " + SpritesRoot + ". Put your PNGs in the motion " +
                                    "folders (" + string.Join(", ", Motions) + ") -- one folder per animation, " +
                                    "named so they sort in order: 01.png, 02.png, 03.png ...  For a different " +
                                    "animation on each clash of a skill, put each clash in its own numbered " +
                                    "folder instead: S1/0/1.png, S1/0/2.png for the first clash, S1/1/1.png for " +
                                    "the second.  (Or use \"build without regenerating\" if you meant to ship " +
                                    "what is already built.)");

            EnsureFolder(GeneratedRoot);
            CcAudio.EnsureSoundsFolder(L);
            CcEffects.EnsureFolder(L);

            var units = new List<Unit>();
            var unitsByMotion = new Dictionary<string, List<Unit>>(StringComparer.Ordinal);
            var coinNotes = new Dictionary<string, List<string>>(StringComparer.Ordinal);
            var fromFolders = new HashSet<string>(StringComparer.Ordinal);
            foreach (string motion in motionsToBuild)
            {
                var mine = new List<Unit>();
                unitsByMotion[motion] = mine;

                if (o.KeepsMotion(motion))
                {
                    foreach (int coin in ExistingCoins(o, motion)) mine.Add(MakeUnit(o, motion, coin, null));
                }
                else
                {
                    MotionDrawings d;
                    if (found.TryGetValue(motion, out d) && d != null)
                    {
                        foreach (CoinGroup g in d.Groups)
                            mine.Add(MakeUnit(o, motion, g.Coin, g.Frames));
                        if (d.Notes.Count > 0) coinNotes[motion] = d.Notes;
                        if (d.FromFolders) fromFolders.Add(motion);
                    }
                }
                units.AddRange(mine);
            }

            var audioByUnit = new Dictionary<string, CcMotionAudio>(StringComparer.Ordinal);
            var vfxByUnit = new Dictionary<string, CcMotionVfx>(StringComparer.Ordinal);
            var curvesByUnit = new Dictionary<string, CcExtraCurves>(StringComparer.Ordinal);
            foreach (Unit u in units)
            {
                audioByUnit[u.AssetName] = CcAudio.Capture(u.Label, u.TimelinePath);
                vfxByUnit[u.AssetName] = CcVfx.Capture(u.Label, u.TimelinePath);
                curvesByUnit[u.AssetName] = o.KeepsMotion(u.Motion)
                    ? new CcExtraCurves { Motion = u.Label }
                    : CcEdits.Capture(u.Label, u.ClipPath, bindingPath);
            }

            foreach (Unit u in units)
                if (o.KeepsMotion(u.Motion))
                {
                    CcAudio.StripTracks(u.TimelinePath);
                    CcVfx.StripTracks(u.TimelinePath);
                }

            List<string> stale = StaleTimelines(bundleName, units);
            foreach (string path in stale)
            {
                CcAudio.Capture(Path.GetFileNameWithoutExtension(path), path);
                CcVfx.Capture(Path.GetFileNameWithoutExtension(path), path);
                CcAudio.StripTracks(path);
                CcVfx.StripTracks(path);
            }

            var built = new List<MotionBuild>();
            var declared = new List<string>();
            var noArt = new List<string>();
            var notOnCharacter = new List<string>();
            var keptMotions = new List<string>();
            int step = 0;
            foreach (string motion in motionsToBuild)
            {
                List<Unit> mine = unitsByMotion[motion];

                if (o.KeepsMotion(motion))
                {
                    Progress("Reading " + motion, ++step, motionsToBuild.Count);
                    if (mine.Count == 0)
                    {
                        L("");
                        L(motion + ": nothing built for it in " + GeneratedRoot + " -- skipped. The character " +
                          "keeps its original " + motion + ".");
                        if (o.Mode == CcBuildMode.Regenerate)
                            LWarn("  " + motion + " is on the keep list but has never been generated, so there is " +
                                  "nothing to keep. Untick \"keep my edits\" for it and build once to create it.");
                        continue;
                    }
                    bool anyKept = false;
                    foreach (Unit u in mine)
                    {
                        MotionBuild kept = BuildMotionFromExisting(u, o, bundleName, bindingPath, target,
                                                                   audioByUnit[u.AssetName], vfxByUnit[u.AssetName]);
                        if (kept == null) continue;
                        built.Add(kept);
                        declared.Add(kept.AssetName);
                        anyKept = true;
                    }
                    if (anyKept && o.Mode == CcBuildMode.Regenerate) keptMotions.Add(motion);
                    continue;
                }

                if (mine.Count == 0)
                {
                    L("");
                    L(motion + ": no drawings -- skipped. The character keeps its original " + motion + ".");
                    noArt.Add(motion);
                    continue;
                }

                if (target != null && target.Find(motion) == null)
                {
                    int drawn = 0;
                    foreach (Unit u in mine) drawn += u.Frames != null ? u.Frames.Count : 0;
                    L("");
                    L(motion + ": you drew " + drawn + " frame(s), but " + o.AppearanceName +
                      " has no " + motion + " motion at all, so there is nothing to put them in. Skipped.");
                    L("  Limbonia can fill a motion whose animation list is empty, but it cannot add a motion the " +
                      "character does not have. Pick a different character if you need " + motion + ".");
                    notOnCharacter.Add(motion);
                    continue;
                }

                List<string> motionNotes;
                if (coinNotes.TryGetValue(motion, out motionNotes) && motionNotes.Count > 0)
                {
                    L("");
                    foreach (string n in motionNotes) LWarn(motion + ": " + n);
                }
                else if (mine.Count > 1)
                {
                    L("");
                    L(motion + ": " + (fromFolders.Contains(motion)
                        ? "one folder per clash, so this is " + mine.Count + " separate animations."
                        : "the drawings name their clash in the file name, so this is " + mine.Count +
                          " separate animations -- one per clash."));
                }

                Progress("Building " + motion, ++step, motionsToBuild.Count);
                foreach (Unit u in mine)
                {
                    CcExtraCurves extra;
                    if (!curvesByUnit.TryGetValue(u.AssetName, out extra))
                        extra = new CcExtraCurves { Motion = u.Label };
                    MotionBuild mb = BuildMotion(u, o, bundleName, bindingPath, target, audioByUnit[u.AssetName],
                                                 vfxByUnit[u.AssetName], extra);
                    if (mb != null) { built.Add(mb); declared.Add(mb.AssetName); }
                }
            }
            EditorUtility.ClearProgressBar();

            if (built.Count == 0)
                throw new Exception(o.Mode == CcBuildMode.UseExisting
                    ? "there is nothing in " + GeneratedRoot + " to build from. Run a normal build (BUILD THE " +
                      "MOD) at least once first -- \"build without regenerating\" ships what that produced, so " +
                      "there has to be something there."
                    : "nothing could be built from the images that are there -- see the errors above.");

            string prefabPath = GeneratedRoot + "/" + Sanitize(o.ModName) + "_Standin.prefab";
            string controllerPath = GeneratedRoot + "/" + Sanitize(o.ModName) + "_Animations.controller";
            bool haveRig = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath) != null;

            if (o.Mode == CcBuildMode.UseExisting && haveRig)
            {
                L("");
                L("stand-in character and clip list: left as they are (" + prefabPath + ")");
            }
            else
            {
                BuildStandinPrefab(o.ModName, bindingPath, prefabPath, PickRestingFrame(built));
                AnimatorController controller = BuildController(controllerPath, built);
                if (controller != null) AssignControllerToPrefab(prefabPath, controller);
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            VerifyAllClips(built, bindingPath);
            VerifyOnlyTheAnimationTrack(built);

            L("");
            L("bundle internal name: " + bundleName);
            L("  Unity lowercases these, and the game refuses a second archive whose internal name is already " +
              "open -- which is the usual cause of a bundle that \"does not load\". It is namespaced with your " +
              "mod name and this mod's own bundle id so two mods cannot collide.");
            L("  bundle id: " + bundleId + "  (" + bundleIdHow + ")");
            L("  THIS ARCHIVE DOES NOT NAME A CHARACTER, and nothing inside it does either. Which character the");
            L("  mod is for is the \"appearance\" line in mod.json and nothing else -- so to put these same");
            L("  animations on somebody else, copy this whole mod folder and change that one word. See the end");
            L("  of this report.");

            List<EffectBuild> effects = CcEffects.CollectAndPack(bundleName, L);
            foreach (EffectBuild eb in effects)
                if (!declared.Contains(eb.AssetName)) declared.Add(eb.AssetName);

            string deployDir = DeployDirOf(o);
            string bundleFile;
            try
            {
                var clipKeys = new Dictionary<string, int>(StringComparer.Ordinal);
                foreach (MotionBuild mb in built) clipKeys[mb.AssetName] = mb.KeyCount;
                bundleFile = CcBundle.BuildVerifyDeploy(bundleName, deployDir + "/" + CcManifest.BundleSubFolder,
                                                        declared, clipKeys, bindingPath, L);
            }
            finally
            {
                CcAudio.RestorePending(L);
                CcVfx.RestorePending(L);
            }

            var sounds = new List<CcMotionAudio>();
            foreach (MotionBuild mb in built) if (mb.Audio != null && mb.Audio.Any) sounds.Add(mb.Audio);
            Dictionary<string, CcSoundFile> soundFiles = null;
            if (sounds.Count > 0)
            {
                L("");
                L("sound files -> " + deployDir + "/" + CcManifest.AudioSubFolder + "/");
                soundFiles = CcAudio.Deploy(Path.Combine(deployDir, CcManifest.AudioSubFolder), sounds, L);
            }

            CcManifest.Write(deployDir, o, bundleName, bundleId, built, effects, soundFiles, bindingPath, L);

            if (o.OpenPreview)
            {
                try { CcPreview.Build(prefabPath, o.ModName, built, L); }
                catch (ExitGUIException) { throw; }
                catch (Exception e)
                {
                    LWarn("the preview scene could not be created (" + e.GetType().Name + ": " + e.Message +
                          "). Everything else was built and deployed -- the mod is fine. Drag " + prefabPath +
                          " into any scene to preview by hand.");
                }
            }

            var placeholders = new List<string>();
            foreach (MotionBuild mb in built)
                if (IsPlaceholder(mb.Motion) && !placeholders.Contains(mb.Motion)) placeholders.Add(mb.Motion);

            Summary(o, target, built, effects, noArt, notOnCharacter, keptMotions, stale, placeholders, bundleFile,
                    deployDir, totalFrames);
        }

        static void ExplainRenderer(CcBuildOptions o)
        {
            string route = CcManifest.NormaliseRenderer(o.Renderer);
            L("");
            L("renderer: " + route.ToUpperInvariant());
            L("  " + CcManifest.RendererExplanation(route));
            if (route == CcManifest.RendererSidecar)
            {
                L("  This is the only way Limbonia draws a custom animation, so it is what every build should");
                L("  ask for. The bundle itself is unaffected by the choice -- the same animations, built the");
                L("  same way -- so a mod from an older build needs its mod.json rebuilt, not its artwork.");
            }
            else
            {
                L("  THIS ROUTE HAS BEEN REMOVED FROM LIMBONIA AND DRAWS NOTHING. A mod built asking for it");
                L("  loads without complaint and then plays the ORIGINAL character, exactly as if it were not");
                L("  installed. Tick \"Let Limbonia draw the character\" under Advanced and build again.");
            }
            L("  Written into mod.json only if you have not already answered there -- a \"renderer\" you set by");
            L("  hand is never overwritten.");
        }

        static string ResolveBindingPath(CcBuildOptions o, Target target)
        {
            string path;
            string why;
            if (!string.IsNullOrEmpty(o.BindingPathOverride))
            {
                path = o.BindingPathOverride.Trim();
                why = "from the override box in the window";
            }
            else if (target != null && !string.IsNullOrEmpty(target.BindingPath))
            {
                path = target.BindingPath;
                why = "read from " + CcTargets.CatalogPath + " for this character";
            }
            else
            {
                path = CcTargets.StandardBindingPath;
                why = "the standard path (178 of 179 characters use it)";
            }

            L("");
            L("curve binding path: " + path);
            L("  (" + why + ")");
            L("  This is THE thing that decides whether your art appears at all. An AnimationClip does not store");
            L("  the name of what it animates -- it stores a CRC32 of the transform path, relative to the");
            L("  Animator the game binds the track to. Aim at the wrong path and the clip binds to nothing and");
            L("  plays perfectly, invisibly, with no error anywhere. If the mod loads (check Limbonia's log) but");
            L("  the character does not change, this line is the first suspect.");
            if (target != null && !string.IsNullOrEmpty(target.BindingPathAlt) && string.IsNullOrEmpty(o.BindingPathOverride))
                L("  This character also has sprite curves on '" + target.BindingPathAlt + "' -- that is normally " +
                  "an effect layer, not the character. Try it in the override box only if nothing shows up.");
            return path;
        }

        static Dictionary<string, MotionDrawings> CollectFrames(List<string> motions, bool informationalOnly)
        {
            var result = new Dictionary<string, MotionDrawings>(StringComparer.Ordinal);
            L("");
            L(informationalOnly
                ? "drawings under " + SpritesRoot + "/  (LISTED ONLY -- this build is not reading them)"
                : "looking for drawings under " + SpritesRoot + "/");

            foreach (string motion in motions)
            {
                MotionDrawings d = DrawingsIn(motion);
                result[motion] = d;
                List<string> files = d.Frames;

                string placeholder = IsPlaceholder(motion) ? "   [PLACEHOLDER -- not drawn yet]" : "";
                string shape = "";
                if (d.FromFolders)
                {
                    var words = new List<string>();
                    foreach (CoinGroup g in d.Groups)
                        words.Add((g.Coin < 0 ? "whole skill" : "clash " + g.Coin.ToString(CultureInfo.InvariantCulture))
                                  + " x" + g.Frames.Count);
                    shape = "   [" + string.Join(", ", words.ToArray()) + "]";
                }
                else if (d.Groups.Count > 1)
                {
                    shape = "   [" + d.Groups.Count + " clashes, named in the files]";
                }

                if (files.Count == 0) L("  " + motion.PadRight(12) + " (empty)" + placeholder);
                else L("  " + motion.PadRight(12) + files.Count + " frame(s): " +
                       string.Join(", ", files.Take(6).Select(Path.GetFileName).ToArray()) +
                       (files.Count > 6 ? ", ..." : "") + shape + placeholder);

                if (!informationalOnly)
                    foreach (string n in d.Notes) LWarn("  " + motion + ": " + n);
            }

            List<string> unknown = UnknownSpriteFolders();
            if (unknown.Count > 0)
            {
                LWarn("these folders under " + SpritesRoot + "/ are not motions any character in the game has, so " +
                      "NOTHING IN THEM IS BEING BUILT: " + string.Join(", ", unknown.ToArray()));
                L("  Motion names are matched exactly, capitals and all. Press \"Set up the folders for this " +
                  "character\" in the window to get the right ones for whoever you are replacing.");
            }
            return result;
        }

        public static int CoinFolderNumber(string folderName)
        {
            if (string.IsNullOrEmpty(folderName) || folderName.Length > 3) return -1;
            foreach (char c in folderName) if (!char.IsDigit(c)) return -1;
            int coin;
            if (!int.TryParse(folderName, NumberStyles.Integer, CultureInfo.InvariantCulture, out coin))
                return -1;
            return coin;
        }

        public static int CoinPrefixOf(string assetPath)
        {
            string stem = Path.GetFileNameWithoutExtension(assetPath) ?? "";
            int i = 0;
            while (i < stem.Length && i < 3 && char.IsDigit(stem[i])) i++;
            if (i == 0) return -1;
            if (i >= stem.Length || stem[i] != '_') return -1;
            if (i + 1 >= stem.Length) return -1;
            int coin;
            if (!int.TryParse(stem.Substring(0, i), NumberStyles.Integer, CultureInfo.InvariantCulture, out coin))
                return -1;
            return coin;
        }

        public class CoinGroup
        {
            public int Coin = -1;
            public List<string> Frames = new List<string>();
        }

        public class MotionDrawings
        {
            public List<CoinGroup> Groups = new List<CoinGroup>();

            public List<string> Frames = new List<string>();

            public bool FromFolders;

            public List<string> Notes = new List<string>();
        }

        public static MotionDrawings DrawingsIn(string motion)
        {
            var d = new MotionDrawings();
            string folder = SpritesRoot + "/" + motion;
            string abs;
            try
            {
                abs = Path.GetFullPath(folder);
                if (!Directory.Exists(abs)) return d;
            }
            catch { return d; }

            var loose = new List<string>();
            try
            {
                foreach (string f in Directory.GetFiles(abs))
                    if (IsDrawing(f)) loose.Add(folder + "/" + Path.GetFileName(f));
            }
            catch { return d; }
            loose.Sort(NaturalCompare);

            var byCoin = new SortedDictionary<int, List<string>>();
            var folderForCoin = new SortedDictionary<int, string>();
            var notNumbers = new List<string>();
            var emptyCoins = new List<string>();
            var doubled = new List<string>();
            var deeper = new List<string>();
            try
            {
                var subs = new List<string>(Directory.GetDirectories(abs));
                subs.Sort(StringComparer.Ordinal);
                foreach (string sub in subs)
                {
                    string name = Path.GetFileName(sub);
                    var got = new List<string>();
                    bool hasDeeper = false;
                    try
                    {
                        foreach (string f in Directory.GetFiles(sub))
                            if (IsDrawing(f)) got.Add(folder + "/" + name + "/" + Path.GetFileName(f));
                        foreach (string dd in Directory.GetDirectories(sub))
                        {
                            foreach (string f in Directory.GetFiles(dd))
                                if (IsDrawing(f)) { hasDeeper = true; break; }
                            if (hasDeeper) break;
                        }
                    }
                    catch { }

                    int coin = CoinFolderNumber(name);
                    if (coin < 0)
                    {
                        if (got.Count > 0 || hasDeeper) notNumbers.Add(name);
                        continue;
                    }
                    if (hasDeeper) deeper.Add(name);
                    if (got.Count == 0) { emptyCoins.Add(name); continue; }

                    got.Sort(NaturalCompare);
                    List<string> have;
                    if (byCoin.TryGetValue(coin, out have))
                    {
                        doubled.Add(motion + "/" + folderForCoin[coin] + "/ and " + motion + "/" + name + "/");
                        have.AddRange(got);
                    }
                    else
                    {
                        byCoin[coin] = got;
                        folderForCoin[coin] = name;
                    }
                }
            }
            catch { }

            if (byCoin.Count == 0)
            {
                string note;
                d.Groups = SplitByFileName(loose, out note);
                d.Frames.AddRange(loose);
                if (note != null) d.Notes.Add(note);
                if (note == null && d.Groups.Count > 1)
                    d.Notes.Add("These drawings name their clash in the file name, which still works and was " +
                                "read exactly as before. The tidier way now is a folder per clash: " +
                                FolderSuggestion(motion, d.Groups) + " -- move them when it suits you, or leave " +
                                "them; both build the same thing.");
                AddFolderComplaints(d, motion, notNumbers, emptyCoins, doubled, deeper, false);
                return d;
            }

            d.FromFolders = true;

            if (loose.Count > 0)
            {
                d.Groups.Add(new CoinGroup { Coin = -1, Frames = loose });
                d.Frames.AddRange(loose);
            }
            foreach (var kv in byCoin)
            {
                d.Groups.Add(new CoinGroup { Coin = kv.Key, Frames = kv.Value });
                d.Frames.AddRange(kv.Value);
            }

            if (loose.Count > 0)
                d.Notes.Add("There are " + loose.Count + " drawing(s) loose in this folder as well as the " +
                            "numbered clash folder(s). Both were built: the loose ones cover the whole skill, " +
                            "and each numbered folder replaces that clash. If the loose ones are leftovers, " +
                            "delete them; if they were meant to be a clash, move them into a numbered folder.");

            AddFolderComplaints(d, motion, notNumbers, emptyCoins, doubled, deeper, true);

            var missing = new List<int>();
            int highest = 0;
            foreach (int c in byCoin.Keys) if (c > highest) highest = c;
            for (int c = 0; c <= highest; c++) if (!byCoin.ContainsKey(c)) missing.Add(c);
            if (missing.Count > 0)
            {
                var words = new List<string>();
                foreach (int c in missing) words.Add(c.ToString(CultureInfo.InvariantCulture));
                string list = string.Join(", ", words.ToArray());
                d.Notes.Add((missing.Count == 1
                                ? "There is no folder " + list + " here, but there are higher numbers, so clash " +
                                  list + " plays"
                                : "There are no folders " + list + " here, but there are higher numbers, so those " +
                                  "clashes play") +
                            " the ORIGINAL character" +
                            (loose.Count > 0 ? " unless the loose drawings cover them" : "") +
                            ". Add " + (missing.Count == 1 ? "that folder" : "those folders") +
                            " if that is not what you want.");
            }

            return d;
        }

        static string FolderSuggestion(string motion, List<CoinGroup> groups)
        {
            var parts = new List<string>();
            foreach (CoinGroup g in groups)
            {
                if (g.Coin < 0) continue;
                if (parts.Count >= 3) { parts.Add("..."); break; }
                parts.Add(motion + "/" + g.Coin.ToString(CultureInfo.InvariantCulture) + "/1.png, 2.png ...");
            }
            return string.Join("   ", parts.ToArray());
        }

        static string Named(List<string> folders, string motion)
        {
            var parts = new List<string>();
            foreach (string f in folders)
            {
                if (parts.Count >= 6) { parts.Add("..."); break; }
                parts.Add(motion + "/" + f + "/");
            }
            if (parts.Count == 1) return parts[0];
            string last = parts[parts.Count - 1];
            parts.RemoveAt(parts.Count - 1);
            return string.Join(", ", parts.ToArray()) + " and " + last;
        }

        static void AddFolderComplaints(MotionDrawings d, string motion, List<string> notNumbers,
                                        List<string> emptyCoins, List<string> doubled, List<string> deeper,
                                        bool foldersWon)
        {
            if (notNumbers.Count > 0)
                d.Notes.Add("NOTHING WAS BUILT from " + Named(notNumbers, motion) + " -- there are drawings in " +
                            (notNumbers.Count == 1 ? "it" : "them") + " but the name is not a number. A clash " +
                            "folder is named for its number and nothing else, counting from 0: " + motion + "/0/, " +
                            motion + "/1/. Rename " + (notNumbers.Count == 1 ? "it" : "them") + ", or move the " +
                            "drawings up into " + motion + "/ to make one animation for the whole skill.");

            if (emptyCoins.Count > 0)
                d.Notes.Add(foldersWon
                    ? "Nothing is drawn in " + Named(emptyCoins, motion) + ", so " +
                      (emptyCoins.Count == 1 ? "that clash plays" : "those clashes play") + " the ORIGINAL " +
                      "character. Draw into " + (emptyCoins.Count == 1 ? "it" : "them") + ", or delete " +
                      (emptyCoins.Count == 1 ? "it" : "them") + "."
                    : "Nothing is drawn in " + Named(emptyCoins, motion) + ", so " +
                      (emptyCoins.Count == 1 ? "it changed" : "they changed") + " nothing and this motion was " +
                      "built from the drawings lying in " + motion + "/ as one animation for the whole skill. " +
                      "Draw into " + (emptyCoins.Count == 1 ? "it" : "them") + " to get an animation per clash, " +
                      "or delete " + (emptyCoins.Count == 1 ? "it" : "them") + ".");

            if (doubled.Count > 0)
                d.Notes.Add("These folders mean the same clash and were built as ONE animation between them: " +
                            string.Join("; ", doubled.ToArray()) + ". Leading zeroes do not make a different " +
                            "number. Give each clash one folder.");

            if (deeper.Count > 0)
                d.Notes.Add("There are drawings more than one folder deep inside " + Named(deeper, motion) +
                            " and they were NOT built. A clash folder holds its frames directly: " + motion +
                            "/0/1.png, not " + motion + "/0/anything/1.png.");

        }

        public static List<CoinGroup> SplitByFileName(List<string> frames, out string note)
        {
            note = null;
            var all = new List<CoinGroup>();
            if (frames == null || frames.Count == 0) return all;

            var named = new List<string>();
            var unnamed = new List<string>();
            foreach (string f in frames)
            {
                if (CoinPrefixOf(f) >= 0) named.Add(f); else unnamed.Add(f);
            }

            if (named.Count == 0)
            {
                all.Add(new CoinGroup { Coin = -1, Frames = frames });
                return all;
            }

            if (unnamed.Count > 0)
            {
                var shown = new List<string>();
                foreach (string f in named)
                {
                    if (shown.Count >= 4) { shown.Add("..."); break; }
                    shown.Add(Path.GetFileName(f));
                }
                note = "MIXED FILE NAMES -- built as ONE animation for the whole skill (the usual way). " +
                       named.Count + " of these drawings name a clash in the file name (" +
                       string.Join(", ", shown.ToArray()) + ") and " + unnamed.Count + " do not, so it is not " +
                       "clear which you meant and nothing was split. To get one animation per clash, put each " +
                       "clash in its own numbered folder: the first clash's drawings in a folder called 0, the " +
                       "second's in a folder called 1, and so on. To keep one animation for the whole skill, " +
                       "take the numbers and underscores off the ones that have them.";
                all.Add(new CoinGroup { Coin = -1, Frames = frames });
                return all;
            }

            var order = new List<int>();
            var byCoin = new Dictionary<int, CoinGroup>();
            foreach (string f in frames)
            {
                int coin = CoinPrefixOf(f);
                CoinGroup g;
                if (!byCoin.TryGetValue(coin, out g))
                {
                    g = new CoinGroup { Coin = coin };
                    byCoin[coin] = g;
                    order.Add(coin);
                }
                g.Frames.Add(f);
            }
            order.Sort();
            foreach (int coin in order) all.Add(byCoin[coin]);
            return all;
        }

        public static int NaturalCompare(string a, string b)
        {
            a = Path.GetFileNameWithoutExtension(a) ?? "";
            b = Path.GetFileNameWithoutExtension(b) ?? "";
            int i = 0, j = 0;
            while (i < a.Length && j < b.Length)
            {
                if (char.IsDigit(a[i]) && char.IsDigit(b[j]))
                {
                    int si = i, sj = j;
                    while (i < a.Length && char.IsDigit(a[i])) i++;
                    while (j < b.Length && char.IsDigit(b[j])) j++;
                    string na = a.Substring(si, i - si).TrimStart('0');
                    string nb = b.Substring(sj, j - sj).TrimStart('0');
                    if (na.Length != nb.Length) return na.Length - nb.Length;
                    int c = string.CompareOrdinal(na, nb);
                    if (c != 0) return c;
                }
                else
                {
                    int c = char.ToLowerInvariant(a[i]).CompareTo(char.ToLowerInvariant(b[j]));
                    if (c != 0) return c;
                    i++; j++;
                }
            }
            return (a.Length - i) - (b.Length - j);
        }

        class Unit
        {
            public string Motion;
            public int Coin = -1;
            public string AssetName;
            public string Label;

            public List<string> Frames;

            public string ClipPath { get { return GeneratedRoot + "/" + AssetName + ".anim"; } }
            public string TimelinePath { get { return GeneratedRoot + "/" + AssetName + ".playable"; } }
        }

        static Unit MakeUnit(CcBuildOptions o, string motion, int coin, List<string> frames)
        {
            return new Unit
            {
                Motion = motion,
                Coin = coin,
                AssetName = CcManifest.AssetNameFor(o.ModName, motion, coin),
                Label = CcManifest.LabelFor(motion, coin),
                Frames = frames,
            };
        }

        static List<int> ExistingCoins(CcBuildOptions o, string motion)
        {
            var coins = new List<int>();
            try
            {
                string bare = CcManifest.AssetNameFor(o.ModName, motion, -1);
                string prefix = bare + CcManifest.CoinSuffix;
                string abs = Path.GetFullPath(GeneratedRoot);
                if (!Directory.Exists(abs)) return coins;

                foreach (string f in Directory.GetFiles(abs, "*.playable"))
                {
                    string stem = Path.GetFileNameWithoutExtension(f) ?? "";
                    if (string.Equals(stem, bare, StringComparison.Ordinal))
                    {
                        if (!coins.Contains(-1)) coins.Add(-1);
                        continue;
                    }
                    if (!stem.StartsWith(prefix, StringComparison.Ordinal)) continue;
                    int coin;
                    if (int.TryParse(stem.Substring(prefix.Length), NumberStyles.Integer,
                                     CultureInfo.InvariantCulture, out coin) && coin >= 0 && !coins.Contains(coin))
                        coins.Add(coin);
                }
            }
            catch {  }
            coins.Sort();
            return coins;
        }

        static List<string> StaleTimelines(string bundleName, List<Unit> units)
        {
            var stale = new List<string>();
            try
            {
                var mine = new HashSet<string>(StringComparer.Ordinal);
                foreach (Unit u in units) mine.Add(u.AssetName);

                string abs = Path.GetFullPath(GeneratedRoot);
                if (!Directory.Exists(abs)) return stale;

                foreach (string f in Directory.GetFiles(abs, "*.playable"))
                {
                    string stem = Path.GetFileNameWithoutExtension(f) ?? "";
                    if (stem.Length == 0 || mine.Contains(stem)) continue;
                    string assetPath = GeneratedRoot + "/" + Path.GetFileName(f);
                    var importer = AssetImporter.GetAtPath(assetPath);
                    if (importer == null) continue;
                    if (!string.Equals(importer.assetBundleName, bundleName, StringComparison.Ordinal)) continue;
                    stale.Add(assetPath);
                }
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                LWarn("could not check " + GeneratedRoot + " for animations left over from an earlier build (" +
                      e.Message + "). If this mod behaves as though it did not load at all, delete the .playable " +
                      "files in there that you no longer want and build again.");
            }
            stale.Sort(StringComparer.Ordinal);
            return stale;
        }

        public class MotionBuild
        {
            public string Motion;

            public int Coin = -1;

            public string Label;

            public string AssetName;
            public string ClipPath;
            public string TimelinePath;
            public double Duration;
            public int FrameCount;
            public float Fps;

            public int KeyCount;

            public string FirstFramePath;

            public CcMotionAudio Audio;

            public CcMotionVfx Vfx;

            public bool FromExisting;

            public string ExtraCurves;
        }

        static MotionBuild BuildMotion(Unit unit, CcBuildOptions o, string bundleName, string bindingPath,
                                       Target target, CcMotionAudio audio, CcMotionVfx vfx, CcExtraCurves extra)
        {
            string motion = unit.Motion;
            List<string> frames = unit.Frames;
            float fps = FpsFor(motion, o.Fps);
            double duration = frames.Count / (double)fps;

            L("");
            L(unit.Label + ": " + frames.Count + " frame(s) at " + fps.ToString("0.##") + " fps = " +
              duration.ToString("0.###") + "s");

            if (duration < MinDuration)
            {
                double wanted = MinDuration;
                LWarn("  that is shorter than Limbonia's minimum of 0.05s, so the animation would be refused " +
                      "outright and the motion left untouched. Stretched to " + wanted.ToString("0.###") +
                      "s instead. Draw more frames, or drop the frame rate, if the timing matters.");
                duration = wanted;
            }

            var sprites = new List<Sprite>();
            string firstFramePath = null;
            foreach (string assetPath in frames)
            {
                Sprite s = ImportSprite(assetPath, o);
                if (s == null) continue;
                if (firstFramePath == null) firstFramePath = assetPath;
                sprites.Add(s);
            }
            if (sprites.Count == 0)
            {
                LErr("  none of " + unit.Label + "'s images imported as a Sprite -- skipped.");
                return null;
            }

            string assetName = unit.AssetName;
            string clipPath = unit.ClipPath;
            string timelinePath = unit.TimelinePath;

            var clip = new AnimationClip { name = assetName, frameRate = fps };

            var keys = new List<ObjectReferenceKeyframe>();
            for (int i = 0; i < sprites.Count; i++)
                keys.Add(new ObjectReferenceKeyframe { time = (float)(i / (double)fps), value = sprites[i] });
            keys.Add(new ObjectReferenceKeyframe { time = (float)duration, value = sprites[sprites.Count - 1] });

            var binding = EditorCurveBinding.PPtrCurve(bindingPath, typeof(SpriteRenderer), "m_Sprite");
            AnimationUtility.SetObjectReferenceCurve(clip, binding, keys.ToArray());

            CcEdits.Reapply(clip, extra, duration, L, LWarn);

            if (AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath) != null) AssetDatabase.DeleteAsset(clipPath);
            AssetDatabase.CreateAsset(clip, clipPath);
            EditorUtility.SetDirty(clip);
            AssetDatabase.SaveAssets();

            int shipped = VerifyClip(clipPath, bindingPath, keys.Count, unit.Label);
            L("  clip: " + clipPath + "  (" + keys.Count + " keys on '" + bindingPath + "', read back and verified)");

            if (AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath) != null) AssetDatabase.DeleteAsset(timelinePath);
            var timeline = ScriptableObject.CreateInstance<TimelineAsset>();
            timeline.name = assetName;
            AssetDatabase.CreateAsset(timeline, timelinePath);

            var track = timeline.CreateTrack<AnimationTrack>(null, "Animation Track");
            var tlClip = track.CreateClip<AnimationPlayableAsset>();
            var playable = tlClip.asset as AnimationPlayableAsset;
            if (playable != null)
            {
                playable.clip = clip;
                playable.name = assetName + "_Anim";
                if (!AssetDatabase.Contains(playable)) AssetDatabase.AddObjectToAsset(playable, timeline);
            }
            else LErr("  " + assetName + ": the timeline clip's asset is not an AnimationPlayableAsset");

            tlClip.start = 0.0;
            tlClip.duration = duration;
            tlClip.clipIn = 0.0;
            tlClip.displayName = assetName;

            timeline.durationMode = TimelineAsset.DurationMode.FixedLength;
            timeline.fixedDuration = duration;
            if (!AssetDatabase.Contains(track)) AssetDatabase.AddObjectToAsset(track, timeline);
            EditorUtility.SetDirty(timeline);

            L("  timeline: " + timelinePath + "  (" + duration.ToString("0.###") + "s, one animation track, " +
              "no timing markers -- Limbonia adds those)");

            AssignBundle(clipPath, bundleName);
            AssignBundle(timelinePath, bundleName);

            if (audio.Any)
            {
                TargetMotion tmAudio = target != null ? target.Find(motion) : null;
                int audioCoins = tmAudio != null ? tmAudio.Coins : 0;
                L("  sound: " + audio.Sounds.Count() + " clip(s) on " + audio.Tracks.Count + " audio track(s) " +
                  "you placed in the Timeline window -- read at build time, written into mod.json, NOT shipped " +
                  "in the bundle.");
                CcAudio.Validate(audio, duration, audioCoins, unit.Coin, L, LWarn);
            }

            if (vfx.Any)
            {
                L("  effects: " + vfx.Placements.Count() + " placement(s) on " + vfx.Tracks.Count +
                  " control track(s) you made in the Timeline window -- read at build time, written into " +
                  "mod.json, NOT shipped in the bundle.");
                CcVfx.Validate(vfx, duration, L, LWarn);
            }

            CcManifest.ExplainMotion(motion, unit.Coin, target, o.Renderer, L);

            return new MotionBuild
            {
                Motion = motion,
                Coin = unit.Coin,
                Label = unit.Label,
                AssetName = assetName,
                ClipPath = clipPath,
                TimelinePath = timelinePath,
                Duration = duration,
                FrameCount = sprites.Count,
                Fps = fps,
                KeyCount = shipped,
                FirstFramePath = firstFramePath,
                Audio = audio,
                Vfx = vfx,
            };
        }

        static int VerifyClip(string clipPath, string bindingPath, int expectedKeys, string motion)
        {
            var saved = AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);
            if (saved == null)
                throw new Exception(motion + ": there is no animation at " + clipPath + ". Nothing was deployed.");

            EditorCurveBinding[] bindings = AnimationUtility.GetObjectReferenceCurveBindings(saved);
            if (bindings == null || bindings.Length == 0)
                throw new Exception(motion + ": the animation at " + clipPath + " came out EMPTY -- it has no " +
                                    "sprite curve at all, so in game the character would load, report no error, " +
                                    "and not move. Nothing was deployed.");

            int total = 0, onPath = 0;
            foreach (EditorCurveBinding b in bindings)
            {
                ObjectReferenceKeyframe[] k = AnimationUtility.GetObjectReferenceCurve(saved, b);
                int n = k == null ? 0 : k.Length;
                total += n;
                if (b.path == bindingPath) onPath += n;
            }
            if (onPath == 0)
                throw new Exception(motion + ": the animation's drawings are on '" + bindings[0].path + "' but " +
                                    "this character binds at '" + bindingPath + "'. It would bind to nothing and " +
                                    "play invisibly. Nothing was deployed." +
                                    (expectedKeys < 0
                                        ? " If you re-pointed this curve on purpose, put the path in \"Binding " +
                                          "path override\" so the whole build agrees with it."
                                        : ""));
            if (expectedKeys >= 0 && total != expectedKeys)
                throw new Exception(motion + ": the animation should hold " + expectedKeys + " drawing keys but " +
                                    "holds " + total + ". Nothing was deployed.");

            try
            {
                string abs = Path.GetFullPath(clipPath);
                if (!File.Exists(abs)) return total;
                string text = File.ReadAllText(abs);
                if (!text.StartsWith("%YAML")) return total;
                if (text.Contains("genericBindings: []") || text.Contains("m_PPtrCurves: []"))
                    throw new Exception(motion + ": " + clipPath + " reads as an animation in the editor but the " +
                                        "FILE ON DISK is empty (`genericBindings: []`), so the bundle would ship " +
                                        "an animation that does nothing. Nothing was deployed.");
            }
            catch (IOException) {  }
            return total;
        }

        static void VerifyAllClips(List<MotionBuild> built, string bindingPath)
        {
            foreach (MotionBuild mb in built)
                VerifyClip(mb.ClipPath, bindingPath, mb.KeyCount, mb.Label);
            L("");
            L("every animation re-checked just before the bundle: " + built.Count + " clip(s), all carrying their");
            L("  sprite curve on '" + bindingPath + "'. An animation that reported frames and shipped empty is a");
            L("  failure nothing downstream can detect, so it is asserted here rather than assumed.");
        }

        static void VerifyOnlyTheAnimationTrack(List<MotionBuild> built)
        {
            foreach (MotionBuild mb in built)
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(mb.TimelinePath);
                if (timeline == null)
                    throw new Exception(mb.Label + ": there is no timeline at " + mb.TimelinePath +
                                        ". Nothing was deployed.");

                var found = new List<TrackAsset>();
                foreach (TrackAsset t in timeline.GetOutputTracks()) if (t != null) found.Add(t);

                if (found.Count == 1 && found[0] is AnimationTrack) continue;

                var described = new List<string>();
                foreach (TrackAsset t in found)
                    described.Add("'" + (string.IsNullOrEmpty(t.name) ? "(unnamed)" : t.name) + "' (" +
                                  t.GetType().Name + ")");

                if (found.Count == 0)
                    throw new Exception(mb.Label + ": the timeline at " + mb.TimelinePath + " has NO TRACKS on " +
                                        "it at all, so it would play nothing in game. Nothing was deployed.");

                throw new Exception(mb.Label + ": the timeline at " + mb.TimelinePath + " carries " + found.Count +
                                    " track(s) -- " + JMerge.Sentence(described) + " -- and a bundle must contain " +
                                    "exactly one animation track and nothing else.\n" +
                                    "    Sound and effect tracks are taken off automatically for the bundle and " +
                                    "put straight back, so seeing one here means that did not happen -- report it.\n" +
                                    "    Anything else on the timeline is yours: delete the extra track in the " +
                                    "Timeline window and build again. Limbonia adds its own timing and effect " +
                                    "tracks when it installs the animation, so one shipped in the archive fights " +
                                    "it rather than helping.\n" +
                                    "    Nothing was deployed.");
            }
            L("  ...and each of those timelines carries exactly one animation track and nothing else, which is");
            L("  what the game's runtime can read. Sound and effect tracks were taken off for the archive.");
        }

        static MotionBuild BuildMotionFromExisting(Unit unit, CcBuildOptions o, string bundleName,
                                                   string bindingPath, Target target, CcMotionAudio audio,
                                                   CcMotionVfx vfx)
        {
            string motion = unit.Motion;
            string label = unit.Label;
            string assetName = unit.AssetName;
            string clipPath = unit.ClipPath;
            string timelinePath = unit.TimelinePath;

            var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath);
            var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);

            L("");
            if (timeline == null || clip == null)
            {
                L(label + ": its timeline in " + GeneratedRoot + " could not be read -- skipped. The character " +
                  "keeps its original " + motion + ".");
                return null;
            }

            if (target != null && target.Find(motion) == null)
            {
                L(label + ": " + o.AppearanceName + " has no " + motion + " motion at all, so there is nothing " +
                  "to put this animation into. Skipped.");
                return null;
            }

            double duration = timeline.duration;
            L(label + ": USING WHAT IS ALREADY BUILT -- not regenerated. " +
              duration.ToString("0.###") + "s, " + clip.frameRate.ToString("0.##") + " fps.");

            if (duration < MinDuration)
                throw new Exception(label + ": the timeline already in " + GeneratedRoot + " is only " +
                                    duration.ToString("0.###") + "s, and Limbonia refuses anything under 0.05s. " +
                                    "Lengthen it in the Timeline window. Nothing was deployed.");

            int keys = VerifyClip(clipPath, bindingPath, -1, label);

            var extra = CcEdits.Capture(label, clipPath, bindingPath);
            L("  " + keys + " drawing key(s) on '" + bindingPath + "'" +
              (extra.Any ? ", plus hand-authored " + extra.Describe() : "") + " -- read back and verified.");

            if (extra.AuthoredAgainst > duration + 0.0011)
                LWarn("  " + label + ": the animation is " +
                      extra.AuthoredAgainst.ToString("0.###") + "s long but its timeline is only " +
                      duration.ToString("0.###") + "s, so the last " +
                      (extra.AuthoredAgainst - duration).ToString("0.###") + "s of it will NEVER PLAY. " +
                      "Drag the clip's right edge out in the Timeline window (or set the timeline's duration) " +
                      "to match.");
            if (audio != null && audio.Any)
                L("  sound: " + audio.Sounds.Count() + " clip(s) on its timeline, taken off for the bundle and " +
                  "written into mod.json.");
            if (vfx != null && vfx.Any)
            {
                L("  effects: " + vfx.Placements.Count() + " placement(s) on its timeline, taken off for the " +
                  "bundle and written into mod.json.");
                CcVfx.Validate(vfx, duration, L, LWarn);
            }

            AssignBundle(clipPath, bundleName);
            AssignBundle(timelinePath, bundleName);

            CcManifest.ExplainMotion(motion, unit.Coin, target, o.Renderer, L);

            return new MotionBuild
            {
                Motion = motion,
                Coin = unit.Coin,
                Label = label,
                AssetName = assetName,
                ClipPath = clipPath,
                TimelinePath = timelinePath,
                Duration = duration,
                FrameCount = keys,
                Fps = clip.frameRate,
                KeyCount = keys,
                FirstFramePath = null,
                Audio = audio,
                Vfx = vfx,
                FromExisting = true,
                ExtraCurves = extra.Any ? extra.Describe() : null,
            };
        }

        static float FpsFor(string motion, float fallback)
        {
            try
            {
                string p = Path.GetFullPath(SpritesRoot + "/" + motion + "/fps.txt");
                if (!File.Exists(p)) return fallback;
                float v;
                if (float.TryParse(File.ReadAllText(p).Trim(), NumberStyles.Float,
                                   CultureInfo.InvariantCulture, out v) && v > 0.01f && v <= 240f)
                {
                    L("  " + motion + "/fps.txt says " + v.ToString("0.##") + " fps (overriding the window's " +
                      fallback.ToString("0.##") + ")");
                    return v;
                }
                LWarn("  " + motion + "/fps.txt does not contain a usable frame rate -- using " +
                      fallback.ToString("0.##"));
            }
            catch { }
            return fallback;
        }

        static Sprite ImportSprite(string assetPath, CcBuildOptions o)
        {
            var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (importer == null)
            {
                LErr("  " + assetPath + " has no texture importer -- is it a real image file? " +
                     "(A .png that is actually something else renamed will do this.)");
                return null;
            }

            bool needs = importer.textureType != TextureImporterType.Sprite;
            var settings = new TextureImporterSettings();
            importer.ReadTextureSettings(settings);
            if (settings.spriteAlignment != (int)SpriteAlignment.Custom) needs = true;
            if (Math.Abs(settings.spritePixelsPerUnit - o.Ppu) > 1e-3f) needs = true;
            if (Math.Abs(settings.spritePivot.x - o.PivotX) > 1e-5f) needs = true;
            if (Math.Abs(settings.spritePivot.y - o.PivotY) > 1e-5f) needs = true;

            if (needs)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.alphaIsTransparency = true;
                importer.mipmapEnabled = false;
                importer.textureCompression = TextureImporterCompression.Uncompressed;
                importer.ReadTextureSettings(settings);
                settings.spriteAlignment = (int)SpriteAlignment.Custom;
                settings.spritePivot = new Vector2(o.PivotX, o.PivotY);
                settings.spritePixelsPerUnit = o.Ppu;
                settings.spriteMeshType = SpriteMeshType.FullRect;
                importer.SetTextureSettings(settings);
                importer.SaveAndReimport();
            }

            var sprite = AssetDatabase.LoadAssetAtPath<Sprite>(assetPath);
            if (sprite == null)
                LErr("  " + assetPath + " did not import as a Sprite. Re-save it as a normal PNG.");
            return sprite;
        }

        static string PickRestingFrame(List<MotionBuild> built)
        {
            foreach (string preferred in new[] { "Default", "Idle" })
                foreach (MotionBuild mb in built)
                    if (mb.Motion == preferred && !string.IsNullOrEmpty(mb.FirstFramePath))
                        return mb.FirstFramePath;
            foreach (MotionBuild mb in built)
                if (!string.IsNullOrEmpty(mb.FirstFramePath)) return mb.FirstFramePath;
            return null;
        }

        static void BuildStandinPrefab(string modName, string bindingPath, string prefabPath, string restingFramePath)
        {
            L("");
            L("stand-in character: " + prefabPath);
            var root = new GameObject(Sanitize(modName));
            try
            {
                root.AddComponent<Animator>();

                Transform cur = root.transform;
                foreach (string seg in bindingPath.Split('/'))
                {
                    if (seg.Length == 0) continue;
                    Transform next = cur.Find(seg);
                    if (next == null)
                    {
                        var go = new GameObject(seg);
                        go.transform.SetParent(cur, false);
                        next = go.transform;
                    }
                    cur = next;
                }
                var renderer = cur.GetComponent<SpriteRenderer>();
                if (renderer == null) renderer = cur.gameObject.AddComponent<SpriteRenderer>();

                AssignRestingSprite(renderer, restingFramePath);

                PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
                L("  " + bindingPath + "   (SpriteRenderer)");
                L("  This is a STAND-IN, not the game's character. It is not in the bundle. Its only job is to");
                L("  give the curves the same transform path the game will bind them to.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        static void AssignRestingSprite(SpriteRenderer renderer, string restingFramePath)
        {
            if (string.IsNullOrEmpty(restingFramePath))
            {
                LWarn("no resting drawing could be chosen, so the character will be INVISIBLE in the preview " +
                      "scene until you scrub an animation. Nothing is broken -- there was simply no frame to " +
                      "stand on. Draw at least one frame in " + SpritesRoot + "/Default/.");
                return;
            }

            var resting = AssetDatabase.LoadAssetAtPath<Sprite>(restingFramePath);
            if (resting == null)
            {
                LWarn(restingFramePath + " would have been the character's resting drawing but did not load as a " +
                      "Sprite, so the preview scene will look EMPTY until you scrub an animation. That is a " +
                      "preview problem only -- the mod itself is unaffected.");
                return;
            }

            renderer.sprite = resting;
            L("  resting drawing: " + restingFramePath);
            L("  This is what the character stands as when nothing is playing, so the scene is not empty when");
            L("  you open it. It is saved ON the prefab, not set by a script -- and it means an empty scene now");
            L("  really does mean something is wrong (art that did not import, or a wrong binding path).");
        }

        static AnimatorController BuildController(string controllerPath, List<MotionBuild> built)
        {
            try
            {
                if (AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath) != null)
                    AssetDatabase.DeleteAsset(controllerPath);

                AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
                if (controller == null)
                {
                    LWarn("Unity would not create an AnimatorController at " + controllerPath + ". The clips are " +
                          "fine and the mod is unaffected -- you just have to drag a clip onto the character by " +
                          "hand to preview it.");
                    return null;
                }

                AnimatorStateMachine machine = controller.layers[0].stateMachine;
                AnimatorState first = null;
                int row = 0;
                foreach (MotionBuild mb in built)
                {
                    var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(mb.ClipPath);
                    if (clip == null) continue;
                    AnimatorState state = machine.AddState(mb.Label, new Vector3(0f, row * 62f, 0f));
                    row++;
                    state.motion = clip;
                    state.speed = 1f;
                    state.writeDefaultValues = true;
                    if (first == null) first = state;
                }
                if (first != null) machine.defaultState = first;

                EditorUtility.SetDirty(controller);
                AssetDatabase.SaveAssets();
                L("  animation list: " + controllerPath + "  (" + row + " state(s))");
                return controller;
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                LWarn("the animation list could not be built (" + e.GetType().Name + ": " + e.Message +
                      "). The mod is unaffected.");
                return null;
            }
        }

        static void AssignControllerToPrefab(string prefabPath, AnimatorController controller)
        {
            GameObject contents = null;
            try
            {
                contents = PrefabUtility.LoadPrefabContents(prefabPath);
                if (contents == null) { LWarn("the stand-in prefab could not be opened at " + prefabPath); return; }
                var animator = contents.GetComponent<Animator>();
                if (animator == null) animator = contents.AddComponent<Animator>();
                animator.runtimeAnimatorController = controller;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                animator.applyRootMotion = false;
                PrefabUtility.SaveAsPrefabAsset(contents, prefabPath);
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                LWarn("could not put the animation list on the stand-in (" + e.GetType().Name + ": " + e.Message +
                      "). Assign " + controller.name + " to its Animator by hand.");
            }
            finally
            {
                if (contents != null) PrefabUtility.UnloadPrefabContents(contents);
            }
        }

        static void CoinCoverage(Target target, List<MotionBuild> built)
        {
            var motions = new List<string>();
            var byMotion = new Dictionary<string, List<int>>(StringComparer.Ordinal);
            foreach (MotionBuild mb in built)
            {
                if (mb.Coin < 0) continue;
                List<int> coins;
                if (!byMotion.TryGetValue(mb.Motion, out coins))
                {
                    coins = new List<int>();
                    byMotion[mb.Motion] = coins;
                    motions.Add(mb.Motion);
                }
                if (!coins.Contains(mb.Coin)) coins.Add(mb.Coin);
            }
            if (motions.Count == 0) return;

            L("");
            L("CLASH BY CLASH (these motions have one animation per coin):");
            foreach (string motion in motions)
            {
                List<int> supplied = byMotion[motion];
                supplied.Sort();
                var words = new List<string>();
                foreach (int c in supplied) words.Add("coin " + c);

                TargetMotion tm = target != null ? target.Find(motion) : null;
                int total = tm != null ? tm.Coins : 0;

                L("  " + motion.PadRight(9) + "you supplied " + string.Join(", ", words.ToArray()) +
                  (total > 0 ? "   (this character's " + motion + " has " + total + ")" : ""));

                if (total <= 0)
                {
                    L("            How many coins this character's " + motion + " has is not known here -- it is " +
                      "not in " + CcTargets.CatalogPath + ". Any clash you did not supply plays the ORIGINAL");
                    L("            character's animation for that clash.");
                    continue;
                }

                var missing = new List<string>();
                for (int c = 0; c < total; c++) if (!supplied.Contains(c)) missing.Add("coin " + c);
                if (missing.Count == 0)
                {
                    L("            Every clash is yours.");
                    continue;
                }
                L("            NOT SUPPLIED: " + string.Join(", ", missing.ToArray()) +
                  " -- THE ORIGINAL CHARACTER PLAYS ON " +
                  (missing.Count == 1 ? "THAT CLASH" : "THOSE CLASHES") + ". Limbonia does not fall back to");
                L("            your other coins; a coin with no animation of yours keeps the one it had. Draw " +
                  "them as " + string.Join(", ", MissingExamples(missing)) + " to cover them.");
            }
        }

        static List<string> MissingExamples(List<string> missing)
        {
            var examples = new List<string>();
            foreach (string m in missing)
            {
                if (examples.Count >= 3) { examples.Add("..."); break; }
                string n = m.Substring("coin ".Length);
                examples.Add(n + "_1.png");
            }
            return examples;
        }

        static void Summary(CcBuildOptions o, Target target, List<MotionBuild> built, List<EffectBuild> effects,
                            List<string> noArt, List<string> notOnCharacter, List<string> keptMotions,
                            List<string> stale, List<string> placeholders, string bundleFile, string deployDir,
                            int totalFrames)
        {
            L("");
            L("=== DONE -- read this before you test in game ===");
            L("mode:        " + (o.Mode == CcBuildMode.UseExisting
                ? "BUILT WITHOUT REGENERATING -- your drawings were not read; " + GeneratedRoot +
                  " was shipped as it stood"
                : "REGENERATED from " + SpritesRoot +
                  (keptMotions.Count > 0 ? ", except " + string.Join(", ", keptMotions.ToArray()) : "")));
            L("mod folder:  " + deployDir);
            L("bundle:      " + bundleFile);
            if (o.Mode == CcBuildMode.Regenerate)
                L("frames:      " + totalFrames + " image(s) across " + built.Count + " animation(s)");
            L("");
            foreach (MotionBuild mb in built)
            {
                string coins = mb.Coin >= 0
                    ? "coin " + mb.Coin + " only (clash " + (mb.Coin + 1) + ")"
                    : target != null ? target.CoinNote(mb.Motion) : "coin count unknown";
                L("  " + mb.Label.PadRight(13) +
                  (mb.FromExisting ? "kept as built" : mb.FrameCount + " frame(s)") +
                  "  " + mb.Duration.ToString("0.###") + "s  @" + mb.Fps.ToString("0.##") + "fps   -- " + coins +
                  (mb.ExtraCurves != null ? "   [+ your " + mb.ExtraCurves + "]" : ""));
            }

            CoinCoverage(target, built);

            if (stale != null && stale.Count > 0)
            {
                L("");
                L("STILL IN THE MOD FROM AN EARLIER BUILD (" + stale.Count + "):");
                foreach (string s in stale) L("  " + s);
                L("  This build did not make these, but they are still in " + GeneratedRoot + " and still assigned");
                L("  to this mod's bundle, so they are packed into it. If mod.json still has a declaration naming");
                L("  one, IT STILL PLAYS -- which is the usual reason a motion you renamed keeps its old");
                L("  animation. Their sound and effect placements were taken off for the archive and put back, so");
                L("  nothing you authored on them is lost.");
                L("  TO BE RID OF ONE: delete the .anim and .playable in " + GeneratedRoot + ", and its entry in");
                L("  mod.json. To keep it, leave both alone -- renaming your drawings back will pick it up again.");
            }

            if (effects != null && effects.Count > 0)
            {
                L("");
                L("EFFECTS YOU ARE SHIPPING (" + effects.Count + "):");
                foreach (EffectBuild eb in effects)
                    L("  " + eb.AssetName.PadRight(20) + eb.Draws);
                L("  They are in the bundle and declared in mod.json. Nothing plays one until you place it.");
                L("  TO PLACE ONE: open the preview scene, select a motion under \"Sound and effects\" in the");
                L("  Hierarchy, open Window > Sequencing > Timeline, and drag the prefab onto the timeline where");
                L("  it should play. Build again and the time, the length and the prefab's own position are");
                L("  written into mod.json for you. (You can still place one by hand in the companion's");
                L("  animation editor instead -- the build only ever rewrites the ones it placed.)");
                L("  " + CcVfx.PreviewScaleNote);
                L("  SAME EFFECT IN TWO PLACES? Make a prefab variant of it (right-click the prefab > Create >");
                L("  Prefab Variant), move the variant's root, and drop that on. The position lives on the");
                L("  PREFAB, so two placements of one prefab are always in the same place.");
                L("");
                L("  AN AURA, A GLOW, ANYTHING THAT SHOULD ALWAYS BE THERE: do not place it on a timeline at");
                L("  all. A placement is a moment inside one attack, and there is no timeline that is always");
                L("  running -- putting one on the character's Idle does not work, because a pose cannot carry");
                L("  effects. Use an ALWAYS-ON effect instead: open the companion's animation editor, pick this");
                L("  character, and add one under \"Always-on effects\". It is put on the character when the");
                L("  battle starts and left running, with its own position, size and depth (behind the");
                L("  character or in front). Nothing here has to change -- these same prefabs are the ones it");
                L("  offers, because the build already declares every one of them in mod.json.");
            }

            if (keptMotions.Count > 0)
            {
                L("");
                L("KEPT, NOT REGENERATED: " + string.Join(", ", keptMotions.ToArray()));
                L("  These shipped exactly as they were in " + GeneratedRoot + " -- your hand-authored curves,");
                L("  your retimed keys, your timeline. The drawings in " + SpritesRoot + "/<motion>/ were NOT");
                L("  read for them, so new frames there will not appear until you untick \"keep my edits\".");
                L("  The list lives in " + CcEdits.KeepFile + ".");
            }

            bool sidecar = CcManifest.NormaliseRenderer(o.Renderer) == CcManifest.RendererSidecar;
            bool haveFallback = built.Any(b => b.Motion == "Idle" || b.Motion == "Default");
            if (noArt.Count > 0)
            {
                L("");
                L("NO DRAWINGS, SO NOT REPLACED: " + string.Join(", ", noArt.ToArray()));
                if (sidecar && haveFallback)
                {
                    L("  YOUR " + (built.Any(b => b.Motion == "Idle") ? "Idle" : "Default") +
                      " PLAYS FOR THESE. Limbonia draws the whole character, so a motion you did not");
                    L("  draw falls back to your own standing animation rather than showing the original. That");
                    L("  is a still-ish stand-in, not the right animation -- put frames in");
                    L("  " + SpritesRoot + "/<motion>/ and build again when you want them properly covered.");
                    L("  There are 49 motions in the game and nobody draws all of them; this is why.");
                }
                else
                {
                    L("  IN GAME THE ORIGINAL CHARACTER SHOWS FOR THESE. They are not blank and they are not");
                    L("  skipped -- the game falls back to whoever you are replacing. Put frames in");
                    L("  " + SpritesRoot + "/<motion>/ and build again to cover them.");
                    if (sidecar)
                        L("  (Draw Idle or Default and this stops being true: Limbonia would then cover every " +
                          "motion you did not draw with your own standing animation instead.)");
                }

                if (noArt.Contains("Default") && !(sidecar && haveFallback))
                {
                    L("");
                    L("  >>> DEFAULT HAS NO DRAWINGS, AND THIS ONE IS VISIBLE. Default is the neutral standing");
                    L("      state the character returns to after every action, and the game drops back to it");
                    L("      whenever Idle is not what is playing. Without it you get a FLASH of the original");
                    L("      character every time the unit finishes a skill, takes a hit, or settles into Idle.");
                    L("      It reads as a bug and it is not one -- it is this motion, undrawn. Even one frame");
                    L("      of a standing pose in " + SpritesRoot + "/Default/ fixes it.");
                }
            }
            if (placeholders != null && placeholders.Count > 0)
            {
                L("");
                L("STILL PLACEHOLDERS, NOT DRAWN (" + placeholders.Count + "): " +
                  string.Join(", ", placeholders.ToArray()));
                L("  Each of these is one frame: a copy of your standing pose that \"Set up the folders for this");
                L("  character\" put there. They are shipped and they do play -- the character is covered rather");
                L("  than falling back to the original -- but they are not animation. Draw over the frames in");
                L("  " + SpritesRoot + "/<motion>/ and this list shrinks by itself.");
                L("  (There is a " + PlaceholderMarker + " in each of those folders saying the same thing. It");
                L("  disappears on the first build after you change the drawings.)");
            }

            if (notOnCharacter.Count > 0)
            {
                L("");
                L("DRAWN BUT UNUSABLE ON THIS CHARACTER: " + string.Join(", ", notOnCharacter.ToArray()));
                L("  " + o.AppearanceName + " has no such motion, so there is nothing to put an animation into.");
                L("  Your drawings are untouched; pick a character that has it if you need it.");
            }

            var poses = built.Where(b => target != null && target.Find(b.Motion) != null &&
                                         target.Find(b.Motion).Coins == 0).Select(b => b.Motion).ToList();
            if (poses.Count > 0)
            {
                L("");
                if (sidecar)
                {
                    L("POSES: " + string.Join(", ", poses.ToArray()));
                    L("  These motions have no animation of their own on this character -- the game plays each as");
                    L("  a single still drawing. Limbonia draws yours beside the character instead, so nothing has");
                    L("  to be added to the character to make them play, and none of the caveats that used to");
                    L("  apply to a pose apply here.");
                    if (poses.Contains("Idle"))
                    {
                        L("  IDLE IS STILL WORTH CHECKING. It normally draws through the character's Spine skeleton,");
                        L("  which would cover your art -- so Limbonia asks the game to stop drawing the skeleton");
                        L("  while your animation is on screen. That is handled rather than hoped for, but it has");
                        L("  not been watched in a battle. Look at it rather than assuming.");
                    }
                }
                else
                {
                    L("POSES (installed by adding an animation slot): " + string.Join(", ", poses.ToArray()));
                    L("  These motions have no animation of their own on this character -- the game plays each as a");
                    L("  single still drawing -- so Limbonia adds a slot for them rather than overwriting one.");
                    L("  That has been confirmed working in a live battle.");
                    if (poses.Contains("Idle"))
                    {
                        L("  IDLE IS WORTH CHECKING SPECIFICALLY. It has been seen playing in game, so it works -- but");
                        L("  the game switches to a character's Spine skeleton for Idle before it ever reads this slot,");
                        L("  so on a character with a live Spine skin at that moment your animation can be installed,");
                        L("  running, and hidden behind the skeleton. Look at it in a battle rather than assuming.");
                    }
                }
            }

            int soundClips = 0, soundMotions = 0;
            foreach (MotionBuild mb in built)
            {
                if (mb.Audio == null) continue;
                int n = mb.Audio.Shippable.Count();
                if (n > 0) { soundClips += n; soundMotions++; }
            }
            L("");
            if (soundClips > 0)
            {
                L("SOUND: " + soundClips + " cue(s) across " + soundMotions + " motion(s), written into mod.json.");
                foreach (MotionBuild mb in built)
                {
                    if (mb.Audio == null) continue;
                    foreach (CcSound s in mb.Audio.Shippable)
                        L("  " + mb.Label.PadRight(13) + s.Time.ToString("0.###") + "s  " +
                          Path.GetFileName(s.SourceFile) +
                          (s.Volume < 0.999f ? "   at " + Mathf.RoundToInt(s.Volume * 100f) + "% volume" : ""));
                }
                L("  Only the START time carries over. In game the file is fired once and plays to its own end, so");
                L("  the clip's length on the timeline is an editor convenience -- trimming or looping it there");
                L("  changes nothing. Fades and blends do not carry over either.");
                L("  The audio tracks themselves are NOT in the bundle -- the game's runtime cannot read one.");
                L("  They were read at build time and are back on the timelines in " + GeneratedRoot + " for you");
                L("  to keep editing. The files were copied into " + deployDir + "/" + CcManifest.AudioSubFolder +
                  "/ so the mod stays one zippable folder.");
            }
            else
            {
                L("SOUND: none. Put a .wav or .ogg in " + CcAudio.SoundsRoot + ", open the preview scene, select a");
                L("  motion under \"Sound and effects\" in the Hierarchy, open Window > Sequencing > Timeline and");
                L("  drag the file onto the timeline where you want it. Scrub and you will hear it. Build again");
                L("  and it ships.");
            }

            int placed = 0, placedMotions = 0;
            foreach (MotionBuild mb in built)
            {
                if (mb.Vfx == null) continue;
                int n = mb.Vfx.Shippable.Count();
                if (n > 0) { placed += n; placedMotions++; }
            }
            L("");
            if (placed > 0)
            {
                L("EFFECTS PLACED IN UNITY: " + placed + " across " + placedMotions +
                  " motion(s), written into mod.json.");
                foreach (MotionBuild mb in built)
                {
                    if (mb.Vfx == null) continue;
                    foreach (CcPlacement p in mb.Vfx.Shippable)
                        L("  " + mb.Label.PadRight(13) + p.Time.ToString("0.###") + "s  for " +
                          p.Length.ToString("0.###") + "s  " + p.AssetName +
                          "   at (" + p.Position.x.ToString("0.##") + ", " + p.Position.y.ToString("0.##") +
                          ", " + p.Position.z.ToString("0.##") + ")");
                }
                L("  WHERE comes from the PREFAB'S OWN root position, not from the clip: the game writes that");
                L("  offset straight into the effect's position every time it is switched on, so a prefab's own");
                L("  position would otherwise be thrown away. Move the prefab's root in Unity to move it in game.");
                L("  " + CcVfx.PreviewScaleNote);
                L("  The control tracks themselves are NOT in the bundle. They were read at build time and are");
                L("  back on the timelines in " + GeneratedRoot + " for you to keep editing.");
                L("  These placements are marked \"from\": \"unity\" in mod.json, and ONLY those are rewritten by a");
                L("  build. Anything you added by hand, or in the companion, is left exactly as it is.");
            }
            else if (effects != null && effects.Count > 0)
            {
                L("EFFECTS PLACED IN UNITY: none yet. Open the preview scene, select a motion under \"Sound and");
                L("  effects\" in the Hierarchy, open Window > Sequencing > Timeline, and drag a prefab from " +
                  CcEffects.EffectsRoot);
                L("  onto it (choose \"Control Track\" if Unity asks which kind). Scrub and you will see it. Build");
                L("  again and the time, the length and its position are written into mod.json.");
            }

            var droppedVfx = new List<string>();
            foreach (MotionBuild mb in built)
            {
                if (mb.Vfx == null) continue;
                foreach (CcPlacement p in mb.Vfx.Placements)
                    if (p.Problem != null) droppedVfx.Add(mb.Label + ": " + p.Problem);
            }
            if (droppedVfx.Count > 0)
            {
                L("");
                L("EFFECTS THAT WILL NOT PLAY, AND ARE NOT IN mod.json (" + droppedVfx.Count + "):");
                foreach (string d in droppedVfx) L("  " + d);
                L("  Everything else was built and deployed -- the mod works, these placements are simply missing");
                L("  from it. IN GAME THEY WOULD BE NOTHING AT ALL, with no error, which is why they are here.");
            }

            var dropped = new List<string>();
            foreach (MotionBuild mb in built)
            {
                if (mb.Audio == null) continue;
                foreach (CcSound s in mb.Audio.Sounds)
                    if (s.Problem != null) dropped.Add(mb.Label + ": " + s.Problem);
            }
            if (dropped.Count > 0)
            {
                L("");
                L("SOUNDS THAT WILL NOT PLAY, AND ARE NOT IN mod.json (" + dropped.Count + "):");
                foreach (string d in dropped) L("  " + d);
                L("  Everything else was built and deployed -- the mod works, these sounds are simply missing from");
                L("  it. IN GAME THEY WOULD BE SILENCE WITH NO ERROR, which is why they are listed here instead.");
            }

            L("");
            L("NEXT:");
            L("  1. In game (or in the Limbonia companion), rescan mods so it re-reads mod.json.");
            L("  2. Enter a battle with " + (target != null ? "the character you replaced" : o.AppearanceName) +
              " and use the skills you replaced.");
            L("  3. To share it, zip the folder " + deployDir + " -- mod.json, motions/ and audio/ are all anyone");
            L("     needs.");

            L("");
            L("TO PUT THESE SAME ANIMATIONS ON ANOTHER CHARACTER -- no rebuild, no Unity:");
            L("  1. Copy the whole folder " + deployDir + " to a new name beside it.");
            L("  2. Open the copy's mod.json and change \"appearance\" to the other character. That one word is");
            L("     the only thing in a mod that decides who it replaces; nothing in the archive names anybody.");
            L("  3. Change \"name\" too, so the two are told apart in the mods list.");
            L("  Both mods can be on at once. What you CANNOT do is draw different animations for the two by");
            L("  editing one of them -- they share the same drawings until you build the copy from Unity, and");
            L("  building it means setting the mod name in this window to the copy's folder name first.");
            if (soundClips > 0)
            {
                L("  YOUR SOUNDS NEED ONE MORE EDIT IN THE COPY. A cue names its sound as \"<mod folder>/<file>\",");
                L("  and the copy is a different folder -- so every \"clip\" in the copy's mod.json still points at");
                L("  THIS mod's audio. Search the copy's mod.json for \"" + Sanitize(o.ModName) +
                  "/\" and change that part to");
                L("  the copy's folder name. (The .wav files themselves are already in the copy's audio folder.)");
            }
            L("  If the copy reports that the game would not open its bundle: the two folders hold the same");
            L("  archive, and the game will only open one copy of an archive at a time. Build the copy from");
            L("  Unity under its own mod name and it gets an archive of its own.");
            L("");
            L("The preview CANNOT show movement, camera shake or the damage beats: none of those are in the");
            L("bundle. Limbonia fires them at runtime from mod.json. A preview that animates on the spot is");
            L("correct. SOUND AND YOUR OWN EFFECTS ARE THE EXCEPTIONS -- the Timeline window really does play");
            L("both, off the same clock Limbonia uses, so what you hear and see while scrubbing is what the game");
            L("fires. The one thing that does not match is SIZE: " + CcVfx.PreviewScaleNote);
        }

        public static string DeployDirOf(CcBuildOptions o)
        {
            if (o == null || string.IsNullOrEmpty(o.ModsFolder)) return null;
            return Path.Combine(o.ModsFolder, Sanitize(o.ModName));
        }

        public static void AssignBundle(string assetPath, string bundleName)
        {
            var importer = AssetImporter.GetAtPath(assetPath);
            if (importer == null) { LErr("cannot assign a bundle -- no importer for " + assetPath); return; }
            if (importer.assetBundleName == bundleName) return;
            importer.SetAssetBundleNameAndVariant(bundleName, "");
            AssetDatabase.WriteImportSettingsIfDirty(assetPath);

            var check = AssetImporter.GetAtPath(assetPath);
            if (check == null || check.assetBundleName != bundleName)
                throw new Exception("could not put " + assetPath + " into the bundle '" + bundleName + "' (it " +
                                    "reads '" + (check == null ? "<no importer>" : check.assetBundleName) +
                                    "'). That animation would be missing from the mod.");
        }

        public static string Sanitize(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s ?? "")
                if (char.IsLetterOrDigit(c) || c == '_' || c == '-') sb.Append(c);
            string r = sb.ToString();
            return r.Length == 0 ? "mod" : r;
        }

        public static void EnsureFolder(string assetFolder)
        {
            if (string.IsNullOrEmpty(assetFolder) || AssetDatabase.IsValidFolder(assetFolder)) return;
            string parent = Path.GetDirectoryName(assetFolder).Replace('\\', '/');
            string leaf = Path.GetFileName(assetFolder);
            if (!string.IsNullOrEmpty(parent) && parent != "Assets") EnsureFolder(parent);
            if (!AssetDatabase.IsValidFolder(assetFolder)) AssetDatabase.CreateFolder(parent, leaf);
        }

        static void Progress(string what, int done, int total)
        {
            if (total <= 0) return;
            EditorUtility.DisplayProgressBar("CustomCharacter", what, Mathf.Clamp01(done / (float)total));
        }
    }
}
