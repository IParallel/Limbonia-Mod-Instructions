using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public class EffectBuild
    {
        public string AssetName;

        public string Path;

        public string Draws;

        public bool NothingDraws;
    }

    public static class CcEffects
    {
        public const string EffectsRoot = "Assets/CustomCharacter/Effects";

        public static void EnsureFolder(Action<string> log)
        {
            if (AssetDatabase.IsValidFolder(EffectsRoot)) return;
            CcBuild.EnsureFolder(EffectsRoot);
            if (log != null && AssetDatabase.IsValidFolder(EffectsRoot))
                log("effects folder created: " + EffectsRoot + "  (drop script-free effect prefabs in here)");
        }

        public static List<EffectBuild> CollectAndPack(string bundleName, Action<string> log)
        {
            if (log == null) log = s => { };
            var found = new List<EffectBuild>();
            if (!AssetDatabase.IsValidFolder(EffectsRoot)) return found;

            string[] guids = AssetDatabase.FindAssets("t:Prefab", new[] { EffectsRoot });
            if (guids == null || guids.Length == 0) return found;

            var namesSeen = new Dictionary<string, string>(StringComparer.Ordinal);
            var materialsSeen = new List<Material>();
            var grabReaders = new List<Material>();
            bool repairedAny = false;
            var paths = new List<string>();
            foreach (string guid in guids)
            {
                string p = AssetDatabase.GUIDToAssetPath(guid);
                if (!string.IsNullOrEmpty(p) && !paths.Contains(p)) paths.Add(p);
            }
            paths.Sort(CcBuild.NaturalCompare);

            log("");
            log("effects you are shipping (" + EffectsRoot + "):");

            foreach (string path in paths)
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null)
                {
                    log("WARNING: " + path + " could not be opened as a prefab and was skipped.");
                    continue;
                }

                string name = prefab.name;
                string clash;
                if (namesSeen.TryGetValue(name, out clash))
                    throw new Exception("two effect prefabs are both called '" + name + "' (" + clash + " and " +
                                        path + "). Limbonia loads an effect by NAME, so one of them could never " +
                                        "be reached. Rename one.");
                namesSeen[name] = path;

                CheckScriptFree(prefab, path);

                var eb = new EffectBuild { AssetName = name, Path = path };
                eb.Draws = DescribeRenderers(prefab, out eb.NothingDraws);

                CcBuild.AssignBundle(path, bundleName);
                found.Add(eb);

                log("  " + name.PadRight(20) + eb.Draws);
                if (eb.NothingDraws)
                    log("           WARNING: nothing on this prefab draws anything (no particle system, no " +
                        "renderer, no animator). It will be created and switched on in game and you will see " +
                        "nothing. Add a Particle System, a Trail/Sprite/Line Renderer, or an Animator.");
                if (AnyParticleSystemNotPlayOnAwake(prefab))
                    log("           NOTE: a particle system here has Play On Awake OFF. Limbonia switches the " +
                        "object on and off and never calls Play(), so it would never emit. Turn Play On Awake ON.");
                string gravityNote = DescribeGravityTrap(prefab);
                if (gravityNote != null) log("           " + gravityNote);
                bool wantsDistortionLayer;
                if (CheckAndRepairMaterials(prefab, materialsSeen, grabReaders, out wantsDistortionLayer, log))
                    repairedAny = true;
                if (wantsDistortionLayer && EnsureDistortionLayer(prefab, path, log))
                    repairedAny = true;
            }

            if (repairedAny)
            {
                AssetDatabase.SaveAssets();
                log("  Everything marked FIXED above was changed in your project and saved, so the next time you " +
                    "open Unity it is already right. Each one names what it changed and how to change it back, " +
                    "and none of them is hidden from you: they are your own files, in the Inspector, where you " +
                    "left them.");
            }

            log("  These are declared in mod.json as \"type\": \"GameObject\" and played from a coin's \"vfx\" " +
                "list by name. TO PLACE ONE: drag it onto a motion's timeline in the preview scene and build " +
                "again (see CcVfx) -- or pick it in the companion's animation editor, or write " +
                "\"asset\": \"<name>\" by hand. A build only ever rewrites the placements it made itself.");
            return found;
        }

        static void CheckScriptFree(GameObject prefab, string path)
        {
            MonoBehaviour[] scripts = prefab.GetComponentsInChildren<MonoBehaviour>(true);
            var named = new List<string>();
            int missing = 0;
            foreach (MonoBehaviour mb in scripts)
            {
                if (mb == null) { missing++; continue; }
                string n = mb.GetType().FullName;
                if (!named.Contains(n)) named.Add(n);
            }

            if (named.Count == 0 && missing == 0) return;

            var sb = new System.Text.StringBuilder();
            sb.Append("the effect prefab ").Append(path).Append(" carries a script, which cannot work in game.\n");
            if (named.Count > 0)
                sb.Append("    scripts on it: ").Append(string.Join(", ", named.ToArray())).Append('\n');
            if (missing > 0)
                sb.Append("    ").Append(missing).Append(" MISSING script reference(s) -- a component whose script ")
                  .Append("was deleted or renamed.\n");
            sb.Append("    A script compiled in this project has no counterpart inside the game, so the prefab\n")
              .Append("    would be created with a dead reference: no error, no warning, and an effect that does\n")
              .Append("    nothing forever. Remove the script component(s).\n")
              .Append("    You do NOT need one: Limbonia adds the game's own effect component at load, and\n")
              .Append("    everything Unity itself provides (particles, animators, trails, sprites, materials,\n")
              .Append("    shaders) works exactly as it does in the editor.");
            throw new Exception(sb.ToString());
        }

        static string DescribeRenderers(GameObject prefab, out bool nothingDraws)
        {
            var bits = new List<string>();
            int particles = prefab.GetComponentsInChildren<ParticleSystem>(true).Length;
            if (particles > 0) bits.Add(particles + " particle system" + (particles == 1 ? "" : "s"));
            int animators = prefab.GetComponentsInChildren<Animator>(true).Length;
            if (animators > 0) bits.Add(animators + " animator" + (animators == 1 ? "" : "s"));
            int trails = prefab.GetComponentsInChildren<TrailRenderer>(true).Length;
            if (trails > 0) bits.Add(trails + " trail" + (trails == 1 ? "" : "s"));
            int sprites = prefab.GetComponentsInChildren<SpriteRenderer>(true).Length;
            if (sprites > 0) bits.Add(sprites + " sprite renderer" + (sprites == 1 ? "" : "s"));

            int renderers = prefab.GetComponentsInChildren<Renderer>(true).Length;
            nothingDraws = particles == 0 && animators == 0 && renderers == 0;
            if (bits.Count == 0 && renderers > 0) bits.Add(renderers + " renderer" + (renderers == 1 ? "" : "s"));

            return bits.Count == 0 ? "(nothing that draws)" : string.Join(", ", bits.ToArray());
        }

        const float ModeFade = 2f;
        const float BlendSrcAlpha = 5f;
        const float BlendOneMinusSrcAlpha = 10f;

        const float SurfaceTransparent = 1f;
        const float BlendModeAlpha = 0f;
        const float QueueControlUserOverride = 1f;

        const int TransparentQueue = 3000;

        const int TransparentQueueFloor = 2501;

        static bool CheckAndRepairMaterials(GameObject prefab, List<Material> seen, List<Material> grabReaders,
                                            out bool wantsDistortionLayer, Action<string> log)
        {
            bool repaired = false;
            wantsDistortionLayer = false;
            foreach (Renderer r in prefab.GetComponentsInChildren<Renderer>(true))
            {
                if (r == null) continue;
                Material[] mats = r.sharedMaterials;
                bool anyMaterial = false;
                if (mats != null)
                {
                    foreach (Material m in mats)
                    {
                        if (m == null) continue;
                        anyMaterial = true;
                        if (seen.Contains(m))
                        {
                            if (grabReaders.Contains(m)) wantsDistortionLayer = true;
                            continue;
                        }
                        seen.Add(m);
                        bool readsGrab;
                        if (CheckOneMaterial(m, log, out readsGrab)) repaired = true;
                        if (readsGrab)
                        {
                            grabReaders.Add(m);
                            wantsDistortionLayer = true;
                        }
                    }
                }
                if (!anyMaterial)
                    log("           WARNING: '" + r.gameObject.name + "' (" + r.GetType().Name + ") has no " +
                        "material on it, so there is nothing for the game to draw it with and it will never " +
                        "appear. Give it a material in the Inspector.");
            }
            return repaired;
        }

        public const string DistortionLayerName = "Distortion";
        const int DistortionLayerIndex = 19;

        static bool EnsureDistortionLayer(GameObject prefab, string path, Action<string> log)
        {
            int layer = LayerMask.NameToLayer(DistortionLayerName);
            if (layer < 0)
            {
                log("           WARNING: this effect's shader bends the screen, which only works on the Unity " +
                    "layer named '" + DistortionLayerName + "' -- and this project has no layer by that name. " +
                    "Add one at index " + DistortionLayerIndex + " (Edit > Project Settings > Tags and Layers), " +
                    "which is the index the game uses, then set this prefab's Layer to it.");
                return false;
            }

            if (prefab.layer == layer) return false;

            if (prefab.layer != 0)
            {
                log("           NOTE: this effect's shader bends the screen, which works properly only on the " +
                    "'" + DistortionLayerName + "' layer -- and this prefab is on '" +
                    LayerMask.LayerToName(prefab.layer) + "'. That was left alone because it looks deliberate. " +
                    "If it was not, set the prefab's Layer to '" + DistortionLayerName + "'; on any other layer " +
                    "the effect bends the PREVIOUS frame, which smears when anything moves quickly.");
                return false;
            }

            prefab.layer = layer;
            EditorUtility.SetDirty(prefab);
            log("           FIXED: this effect's shader bends the screen, so its Layer was changed from Default " +
                "to '" + DistortionLayerName + "' (" + layer + ") and saved in your project. That is the layer " +
                "the game draws immediately after it copies the screen, and it is the difference between bending " +
                "this frame and bending the last one. Change it back in the Inspector if you meant Default.");
            return true;
        }

        static bool CheckOneMaterial(Material m, Action<string> log, out bool readsGrabTexture)
        {
            readsGrabTexture = false;
            Shader sh = m.shader;
            if (sh == null || sh.name == "Hidden/InternalErrorShader")
            {
                log("           WARNING: the material '" + m.name + "' has no working shader. It will not draw " +
                    "anything in game (or will draw a flat pink block). Select the material and choose a shader " +
                    "for it -- Particles/Standard Unlit is a good default for an effect.");
                return false;
            }

            ShaderSourceFacts facts = ScanShaderSource(sh, m, log);
            readsGrabTexture = facts.ReadsGrabbedTexture;

            string tags;
            if (!ShaderHasAPassTheGameWillRun(sh, out tags))
            {
                if (facts.SurfaceShaderLine > 0)
                    log("           WARNING: the shader '" + sh.name + "' on the material '" + m.name + "' is a " +
                        "SURFACE SHADER (" + facts.Path + ", line " + facts.SurfaceShaderLine + "). Those are " +
                        "written for the lighting of Unity's older renderer, and this game uses the newer one, " +
                        "which never runs them -- so it will draw nothing at all in game, with no error anywhere " +
                        "to say so. Write it as a plain unlit shader instead, or use Particles/Standard Unlit, " +
                        "which is what the game uses on its own particles.");
                else
                    log("           WARNING: the shader '" + sh.name + "' on the material '" + m.name + "' has no " +
                        "drawing step the game will run (its steps are: " + (tags.Length == 0 ? "none" : tags) + "). " +
                        "It will draw nothing at all in game, with no error anywhere to say so. Use an unlit shader " +
                        "instead -- Particles/Standard Unlit is what the game uses on its own particles.");
            }

            string mainTexProp = m.HasProperty("_BaseMap") ? "_BaseMap" : (m.HasProperty("_MainTex") ? "_MainTex" : null);
            if (mainTexProp != null && m.GetTexture(mainTexProp) == null)
                log("           NOTE: the material '" + m.name + "' has no texture in its Base Map / Albedo slot, " +
                    "so whatever it draws will be plain white squares.");

            int queue = m.renderQueue;
            if (queue >= TransparentQueueFloor) return false;

            string assetPath = AssetDatabase.GetAssetPath(m);
            bool ours = !string.IsNullOrEmpty(assetPath) &&
                        assetPath.StartsWith("Assets/", StringComparison.Ordinal);

            bool urp = m.HasProperty("_Surface");
            bool builtIn = !urp && m.HasProperty("_Mode");
            bool hasBlendProps = m.HasProperty("_SrcBlend") && m.HasProperty("_DstBlend") && m.HasProperty("_ZWrite");
            bool fixable = ours && hasBlendProps && (urp || builtIn);

            if (!fixable)
            {
                log("           WARNING: the material '" + m.name + "' (shader " + sh.name + ") is set to draw as " +
                    "SOLID rather than see-through, so it will not be visible in game. Everything in a battle is " +
                    "drawn see-through, and only see-through things obey the layer an effect is placed on -- a " +
                    "solid one is drawn first, underneath the whole scene, however far in front it was put. " +
                    "Select the material and set it to draw see-through: on a URP shader that is Surface Type > " +
                    "Transparent, on one of Unity's older ones it is Rendering Mode > Fade (or Additive, for a " +
                    "glow). " +
                    (ours
                        ? "This build could not do it for you: this shader has no blending settings to change."
                        : "This build could not do it for you: the material is not one of your project's own " +
                          "files (" + assetPath + "), so make a copy of it under Assets/ and use that."));
                return false;
            }

            m.SetFloat("_SrcBlend", BlendSrcAlpha);
            m.SetFloat("_DstBlend", BlendOneMinusSrcAlpha);
            if (m.HasProperty("_SrcBlendAlpha")) m.SetFloat("_SrcBlendAlpha", BlendSrcAlpha);
            if (m.HasProperty("_DstBlendAlpha")) m.SetFloat("_DstBlendAlpha", BlendOneMinusSrcAlpha);
            m.SetFloat("_ZWrite", 0f);
            m.DisableKeyword("_ALPHATEST_ON");
            m.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            m.DisableKeyword("_ALPHAMODULATE_ON");

            if (urp)
            {
                m.SetFloat("_Surface", SurfaceTransparent);
                if (m.HasProperty("_Blend")) m.SetFloat("_Blend", BlendModeAlpha);
                if (m.HasProperty("_AlphaClip")) m.SetFloat("_AlphaClip", 0f);
                if (m.HasProperty("_QueueControl")) m.SetFloat("_QueueControl", QueueControlUserOverride);
                if (m.HasProperty("_QueueOffset")) m.SetFloat("_QueueOffset", 0f);
                m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                m.SetOverrideTag("RenderType", "Transparent");
            }
            else
            {
                m.SetFloat("_Mode", ModeFade);
                m.EnableKeyword("_ALPHABLEND_ON");
            }

            m.renderQueue = TransparentQueue;
            EditorUtility.SetDirty(m);

            log("           FIXED: the material '" + m.name + "' was set to draw as SOLID (drawing order " + queue +
                "), which is invisible in game -- it is drawn underneath the whole scene and ignores the layer " +
                "the effect is placed on. It has been changed to see-through, the same setting the game uses on " +
                "its own effects. If you wanted a glow instead of a fade, select the material and choose " +
                (urp ? "Blending Mode > Additive." : "Rendering Mode > Additive."));
            return true;
        }

        static bool ShaderHasAPassTheGameWillRun(Shader sh, out string tagsFound)
        {
            var seen = new List<string>();
            bool ok = false;
            var lightMode = new UnityEngine.Rendering.ShaderTagId("LightMode");
            for (int s = 0; s < sh.subshaderCount; s++)
            {
                int passes = sh.GetPassCountInSubshader(s);
                for (int p = 0; p < passes; p++)
                {
                    UnityEngine.Rendering.ShaderTagId id = sh.FindPassTagValue(s, p, lightMode);
                    string tag = (id == UnityEngine.Rendering.ShaderTagId.none) ? string.Empty : (id.name ?? string.Empty);
                    if (tag.Length == 0)
                    {
                        ok = true;
                        if (!seen.Contains("(untagged)")) seen.Add("(untagged)");
                        continue;
                    }
                    if (!seen.Contains(tag)) seen.Add(tag);
                    if (tag == "SRPDefaultUnlit" || tag == "UniversalForward" || tag == "UniversalForwardOnly" ||
                        tag == "UniversalGBuffer" || tag == "Universal2D" || tag == "LightweightForward")
                        ok = true;
                }
            }
            tagsFound = string.Join(", ", seen.ToArray());
            return ok;
        }

        class ShaderSourceFacts
        {
            public string Path = string.Empty;
            public int SurfaceShaderLine;
            public int OpaqueTextureLine;

            public bool ReadsGrabbedTexture;
        }

        static ShaderSourceFacts ScanShaderSource(Shader sh, Material m, Action<string> log)
        {
            var facts = new ShaderSourceFacts();

            string path = AssetDatabase.GetAssetPath(sh);
            if (string.IsNullOrEmpty(path)) return facts;
            if (!path.StartsWith("Assets/", StringComparison.Ordinal)) return facts;
            if (path.EndsWith(".shadergraph", StringComparison.OrdinalIgnoreCase))
                return ScanShaderGraph(sh, m, path, log);
            if (!path.EndsWith(".shader", StringComparison.OrdinalIgnoreCase)) return facts;
            if (!File.Exists(path)) return facts;

            string src;
            try { src = File.ReadAllText(path); }
            catch (Exception) { return facts; }

            string code = StripCommentsKeepingLines(src);
            facts.Path = path;

            int grabLine = LineOfMatch(code, @"\bGrabPass\b");
            facts.SurfaceShaderLine = LineOfMatch(code, @"#\s*pragma\s+surface\b");
            facts.OpaqueTextureLine = LineOfMatch(code, @"\b_CameraOpaqueTexture\b");

            if (grabLine > 0)
            {
                string where = "the shader '" + sh.name + "' on the material '" + m.name + "' uses a GRAB PASS (" +
                               path + ", line " + grabLine + "), which this game cannot run.\n" +
                               "    A grab pass is the step that copies the screen so a shader can bend it. It is\n" +
                               "    part of Unity's older renderer. Limbus uses the newer one, which has no such\n" +
                               "    step -- so the copy is never made, your shader reads an empty screen, and the\n" +
                               "    effect disappears the moment your material is put on it. That is exactly what\n" +
                               "    'it works without my shader and vanishes with it' looks like, and nothing\n" +
                               "    anywhere reports it.\n" +
                               "    THE FIX: this project ships a working replacement. Select your material and\n" +
                               "    change its shader to 'Limbus/Screen Distortion Particle'\n" +
                               "    (Assets/CustomCharacter/Shaders/LimbusScreenDistortionParticle.shader). It has\n" +
                               "    the same Distortion Strength, Aura Tint, Scroll and Edge Softness settings, and\n" +
                               "    it reads the screen copy the game itself makes for its own distortion effects.\n" +
                               "    Read the notes at the top of that file -- there is one thing to set on the\n" +
                               "    prefab as well (its Layer).\n" +
                               "    IF YOU DO NOT NEED TO BEND THE SCREEN, any see-through or additive particle\n" +
                               "    shader works and none of this applies -- Particles/Standard Unlit is what the\n" +
                               "    game uses on its own particles.";

                if (HasAUniversalSubshader(sh))
                {
                    log("           WARNING: " + where);
                    return facts;
                }
                throw new Exception(where);
            }

            bool alsoReadsTheGamesOwnCopy = LineOfMatch(code, @"\b_GrabbedTexture\b") > 0;
            facts.ReadsGrabbedTexture = alsoReadsTheGamesOwnCopy;
            if (facts.OpaqueTextureLine > 0 && !alsoReadsTheGamesOwnCopy)
                log("           NOTE: the shader '" + sh.name + "' reads the scene through _CameraOpaqueTexture (" +
                    path + ", line " + facts.OpaqueTextureLine + "). That works, but in a battle it will show " +
                    "almost nothing: the game draws its whole battle scene -- background, board, character and " +
                    "effects -- as see-through, and this copy of the screen is taken before any of it is drawn. " +
                    "Read _GrabbedTexture instead; that is the copy the game makes for its own distortion " +
                    "effects, and 'Limbus/Screen Distortion Particle' in this project already does.");

            return facts;
        }

        static ShaderSourceFacts ScanShaderGraph(Shader sh, Material m, string path, Action<string> log)
        {
            var facts = new ShaderSourceFacts { Path = path };
            if (!File.Exists(path)) return facts;

            string json;
            try { json = File.ReadAllText(path); }
            catch (Exception) { return facts; }

            if (json.IndexOf("UniversalLitSubTarget", StringComparison.Ordinal) >= 0)
                log("           NOTE: the Shader Graph '" + sh.name + "' on the material '" + m.name + "' (" +
                    path + ") is built on the LIT target, which is lit by the scene's lights. The game's own " +
                    "attack effects are all UNLIT, and this project's preview scene has no light in it at all, " +
                    "so a lit effect is likely to come out black -- which looks exactly like an effect that " +
                    "did not draw. In the graph, open Graph Settings and set Material to Unlit.");

            if (json.IndexOf("SceneColorNode", StringComparison.Ordinal) >= 0)
                log("           NOTE: the Shader Graph '" + sh.name + "' (" + path + ") uses a Scene Color node. " +
                    "That reads the copy of the screen Unity itself makes, which is taken BEFORE anything " +
                    "see-through is drawn -- and the game draws its whole battle scene, background and all, as " +
                    "see-through. In a battle that copy is very nearly blank, so bending it will look like " +
                    "bending nothing. To bend the real screen, use the shader this project ships instead " +
                    "('Limbus/Screen Distortion Particle'), which reads the copy the game makes for its own " +
                    "distortion effects.");

            return facts;
        }

        static bool HasAUniversalSubshader(Shader sh)
        {
            var tag = new UnityEngine.Rendering.ShaderTagId("RenderPipeline");
            for (int s = 0; s < sh.subshaderCount; s++)
            {
                UnityEngine.Rendering.ShaderTagId id = sh.FindSubshaderTagValue(s, tag);
                string v = (id == UnityEngine.Rendering.ShaderTagId.none) ? string.Empty : (id.name ?? string.Empty);
                if (v.IndexOf("Universal", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            return false;
        }

        static string StripCommentsKeepingLines(string src)
        {
            var sb = new System.Text.StringBuilder(src.Length);
            int i = 0, n = src.Length;
            bool inString = false;
            while (i < n)
            {
                char c = src[i];
                if (inString)
                {
                    sb.Append(c);
                    if (c == '\\' && i + 1 < n) { sb.Append(src[i + 1]); i += 2; continue; }
                    if (c == '"') inString = false;
                    i++;
                    continue;
                }
                if (c == '"') { inString = true; sb.Append(c); i++; continue; }
                if (c == '/' && i + 1 < n && src[i + 1] == '/')
                {
                    while (i < n && src[i] != '\n') i++;
                    continue;
                }
                if (c == '/' && i + 1 < n && src[i + 1] == '*')
                {
                    i += 2;
                    while (i + 1 < n && !(src[i] == '*' && src[i + 1] == '/'))
                    {
                        if (src[i] == '\n') sb.Append('\n');
                        i++;
                    }
                    i = Math.Min(i + 2, n);
                    continue;
                }
                sb.Append(c);
                i++;
            }
            return sb.ToString();
        }

        static int LineOfMatch(string text, string pattern)
        {
            Match match = Regex.Match(text, pattern);
            if (!match.Success) return 0;
            int line = 1;
            for (int k = 0; k < match.Index && k < text.Length; k++)
                if (text[k] == '\n') line++;
            return line;
        }

        static bool AnyParticleSystemNotPlayOnAwake(GameObject prefab)
        {
            foreach (ParticleSystem ps in prefab.GetComponentsInChildren<ParticleSystem>(true))
            {
                if (ps == null) continue;
                if (!ps.main.playOnAwake) return true;
            }
            return false;
        }

        static string DescribeGravityTrap(GameObject prefab)
        {
            float worst = 0f;
            bool looping = false;
            foreach (ParticleSystem ps in prefab.GetComponentsInChildren<ParticleSystem>(true))
            {
                if (ps == null) continue;
                ParticleSystem.MainModule main = ps.main;
                float g = main.gravityModifierMultiplier;
                if (Mathf.Abs(g) <= Mathf.Abs(worst)) continue;
                worst = g;
                looping = main.loop;
            }
            if (Mathf.Approximately(worst, 0f)) return null;

            string note = "NOTE: a particle system here has Gravity set to " +
                          worst.ToString("0.###", CultureInfo.InvariantCulture) +
                          ". Gravity is an ACCELERATION, so it keeps adding speed for as long as a particle lives -- " +
                          "the particles end up far faster than the Start Speed you set. It is also multiplied by the " +
                          "GAME's own gravity setting rather than this project's, so this is the one number that does " +
                          "NOT preview faithfully here: expect it to look different in a battle and tune it there.";
            if (looping)
                note += " This system also loops, so what you see depends on how long it has been running -- restart " +
                        "the preview and it will look slower for the first moment than it does in game.";
            return note;
        }
    }
}
