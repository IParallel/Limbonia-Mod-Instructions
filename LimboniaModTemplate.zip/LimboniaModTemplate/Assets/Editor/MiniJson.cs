using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Limbonia.CustomCharacter
{
    public enum JKind { Null, Bool, Number, String, Array, Object }

    public class JVal : IEnumerable<JVal>
    {
        public JKind Kind = JKind.Null;
        public bool Bool;
        public double Number;
        public string Str;
        public List<JVal> Array;
        public List<KeyValuePair<string, JVal>> Members;

        public static JVal NewObject() { return new JVal { Kind = JKind.Object, Members = new List<KeyValuePair<string, JVal>>() }; }
        public static JVal NewArray() { return new JVal { Kind = JKind.Array, Array = new List<JVal>() }; }
        public static JVal Of(string s) { return new JVal { Kind = JKind.String, Str = s }; }
        public static JVal Of(double d) { return new JVal { Kind = JKind.Number, Number = d }; }
        public static JVal Of(bool b) { return new JVal { Kind = JKind.Bool, Bool = b }; }

        public bool IsObject { get { return Kind == JKind.Object; } }
        public bool IsArray { get { return Kind == JKind.Array; } }
        public bool IsNull { get { return Kind == JKind.Null; } }

        public static readonly JVal Missing = new JVal { Kind = JKind.Null };

        public JVal this[string key]
        {
            get
            {
                if (Kind != JKind.Object || Members == null) return Missing;
                for (int i = 0; i < Members.Count; i++) if (Members[i].Key == key) return Members[i].Value ?? Missing;
                return Missing;
            }
        }

        public JVal this[int i]
        {
            get { return (Kind == JKind.Array && Array != null && i >= 0 && i < Array.Count) ? (Array[i] ?? Missing) : Missing; }
        }

        public int Count { get { return Kind == JKind.Array ? (Array == null ? 0 : Array.Count) : (Members == null ? 0 : Members.Count); } }

        public void Set(string key, JVal value)
        {
            if (Kind != JKind.Object) throw new InvalidOperationException("Set on a non-object");
            for (int i = 0; i < Members.Count; i++)
                if (Members[i].Key == key) { Members[i] = new KeyValuePair<string, JVal>(key, value); return; }
            Members.Add(new KeyValuePair<string, JVal>(key, value));
        }

        public void Add(JVal value)
        {
            if (Kind != JKind.Array) throw new InvalidOperationException("Add on a non-array");
            Array.Add(value);
        }

        public string AsString(string fallback = null) { return Kind == JKind.String ? Str : fallback; }
        public double AsDouble(double fallback = 0) { return Kind == JKind.Number ? Number : fallback; }
        public float AsFloat(float fallback = 0) { return Kind == JKind.Number ? (float)Number : fallback; }
        public int AsInt(int fallback = 0) { return Kind == JKind.Number ? (int)Math.Round(Number) : fallback; }
        public bool AsBool(bool fallback = false) { return Kind == JKind.Bool ? Bool : fallback; }

        public string AsRawNumber() { return Kind == JKind.Number ? Str : null; }

        public IEnumerator<JVal> GetEnumerator()
        {
            if (Kind == JKind.Array && Array != null) return Array.GetEnumerator();
            return new List<JVal>().GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator() { return GetEnumerator(); }

        public override string ToString() { return MiniJson.Write(this, false); }
    }

    public static class MiniJson
    {
        public static JVal Parse(string text)
        {
            int i = 0;
            JVal v = ParseValue(text, ref i);
            SkipWs(text, ref i);
            if (i < text.Length) throw new FormatException(Where(text, i) + ": unexpected trailing character '" + text[i] + "'");
            return v;
        }

        static string Where(string s, int i)
        {
            int line = 1, col = 1;
            for (int k = 0; k < i && k < s.Length; k++) { if (s[k] == '\n') { line++; col = 1; } else col++; }
            return "line " + line + " col " + col;
        }

        static void SkipWs(string s, ref int i)
        {
            while (i < s.Length)
            {
                char c = s[i];
                if (c == ' ' || c == '\t' || c == '\r' || c == '\n') i++;
                else break;
            }
        }

        static JVal ParseValue(string s, ref int i)
        {
            SkipWs(s, ref i);
            if (i >= s.Length) throw new FormatException("unexpected end of JSON");
            char c = s[i];
            switch (c)
            {
                case '{': return ParseObject(s, ref i);
                case '[': return ParseArray(s, ref i);
                case '"': return JVal.Of(ParseString(s, ref i));
                case 't': Expect(s, ref i, "true"); return JVal.Of(true);
                case 'f': Expect(s, ref i, "false"); return JVal.Of(false);
                case 'n': Expect(s, ref i, "null"); return new JVal();
                default: return ParseNumber(s, ref i);
            }
        }

        static void Expect(string s, ref int i, string word)
        {
            if (i + word.Length > s.Length || string.CompareOrdinal(s, i, word, 0, word.Length) != 0)
                throw new FormatException(Where(s, i) + ": expected '" + word + "'");
            i += word.Length;
        }

        static JVal ParseObject(string s, ref int i)
        {
            JVal o = JVal.NewObject();
            i++;
            SkipWs(s, ref i);
            if (i < s.Length && s[i] == '}') { i++; return o; }
            while (true)
            {
                SkipWs(s, ref i);
                if (i >= s.Length || s[i] != '"') throw new FormatException(Where(s, i) + ": expected a key string");
                string key = ParseString(s, ref i);
                SkipWs(s, ref i);
                if (i >= s.Length || s[i] != ':') throw new FormatException(Where(s, i) + ": expected ':'");
                i++;
                JVal val = ParseValue(s, ref i);
                o.Members.Add(new KeyValuePair<string, JVal>(key, val));
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == '}') { i++; return o; }
                throw new FormatException(Where(s, i) + ": expected ',' or '}'");
            }
        }

        static JVal ParseArray(string s, ref int i)
        {
            JVal a = JVal.NewArray();
            i++;
            SkipWs(s, ref i);
            if (i < s.Length && s[i] == ']') { i++; return a; }
            while (true)
            {
                a.Array.Add(ParseValue(s, ref i));
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == ']') { i++; return a; }
                throw new FormatException(Where(s, i) + ": expected ',' or ']'");
            }
        }

        static string ParseString(string s, ref int i)
        {
            i++;
            var sb = new StringBuilder();
            while (true)
            {
                if (i >= s.Length) throw new FormatException("unterminated string");
                char c = s[i++];
                if (c == '"') return sb.ToString();
                if (c != '\\') { sb.Append(c); continue; }
                if (i >= s.Length) throw new FormatException("unterminated escape");
                char e = s[i++];
                switch (e)
                {
                    case '"': sb.Append('"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'u':
                        if (i + 4 > s.Length) throw new FormatException("bad \\u escape");
                        sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16));
                        i += 4;
                        break;
                    default: throw new FormatException(Where(s, i) + ": unknown escape '\\" + e + "'");
                }
            }
        }

        static JVal ParseNumber(string s, ref int i)
        {
            int start = i;
            if (i < s.Length && (s[i] == '-' || s[i] == '+')) i++;
            while (i < s.Length)
            {
                char c = s[i];
                if ((c >= '0' && c <= '9') || c == '.' || c == 'e' || c == 'E' || c == '-' || c == '+') i++;
                else break;
            }
            string raw = s.Substring(start, i - start);
            double d;
            if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out d))
                throw new FormatException(Where(s, start) + ": '" + raw + "' is not a number");
            var v = JVal.Of(d);
            v.Str = raw;
            return v;
        }

        public static string Write(JVal v, bool pretty = true)
        {
            var sb = new StringBuilder();
            WriteValue(sb, v, pretty, 0);
            if (pretty) sb.Append('\n');
            return sb.ToString();
        }

        static void Indent(StringBuilder sb, int depth) { sb.Append(' ', depth * 2); }

        static void WriteValue(StringBuilder sb, JVal v, bool pretty, int depth)
        {
            if (v == null) { sb.Append("null"); return; }
            switch (v.Kind)
            {
                case JKind.Null: sb.Append("null"); break;
                case JKind.Bool: sb.Append(v.Bool ? "true" : "false"); break;
                case JKind.Number: sb.Append(NumberText(v.Number)); break;
                case JKind.String: WriteString(sb, v.Str); break;
                case JKind.Array:
                    if (v.Array == null || v.Array.Count == 0) { sb.Append("[]"); break; }
                    sb.Append('[');
                    for (int i = 0; i < v.Array.Count; i++)
                    {
                        if (i > 0) sb.Append(',');
                        if (pretty) { sb.Append('\n'); Indent(sb, depth + 1); }
                        WriteValue(sb, v.Array[i], pretty, depth + 1);
                    }
                    if (pretty) { sb.Append('\n'); Indent(sb, depth); }
                    sb.Append(']');
                    break;
                case JKind.Object:
                    if (v.Members == null || v.Members.Count == 0) { sb.Append("{}"); break; }
                    sb.Append('{');
                    for (int i = 0; i < v.Members.Count; i++)
                    {
                        if (i > 0) sb.Append(',');
                        if (pretty) { sb.Append('\n'); Indent(sb, depth + 1); }
                        WriteString(sb, v.Members[i].Key);
                        sb.Append(':');
                        if (pretty) sb.Append(' ');
                        WriteValue(sb, v.Members[i].Value, pretty, depth + 1);
                    }
                    if (pretty) { sb.Append('\n'); Indent(sb, depth); }
                    sb.Append('}');
                    break;
            }
        }

        static string NumberText(double d)
        {
            if (double.IsNaN(d) || double.IsInfinity(d)) return "0";
            if (d == Math.Floor(d) && Math.Abs(d) < 1e15)
                return ((long)d).ToString(CultureInfo.InvariantCulture);
            string s = d.ToString("0.##########", CultureInfo.InvariantCulture);
            return s.Length == 0 ? "0" : s;
        }

        static void WriteString(StringBuilder sb, string s)
        {
            sb.Append('"');
            if (s != null)
            {
                foreach (char c in s)
                {
                    switch (c)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\b': sb.Append("\\b"); break;
                        case '\f': sb.Append("\\f"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        default:
                            if (c < 0x20 || c > 0x7E) sb.Append("\\u").Append(((int)c).ToString("x4"));
                            else sb.Append(c);
                            break;
                    }
                }
            }
            sb.Append('"');
        }
    }

    public static class JMerge
    {
        public static bool Has(JVal obj, string key)
        {
            if (obj == null || !obj.IsObject || obj.Members == null) return false;
            for (int i = 0; i < obj.Members.Count; i++) if (obj.Members[i].Key == key) return true;
            return false;
        }

        public static bool SetIfAbsent(JVal obj, string key, JVal value)
        {
            if (obj == null || !obj.IsObject) return false;
            if (Has(obj, key)) return false;
            obj.Set(key, value);
            return true;
        }

        public static List<string> KeysOtherThan(JVal obj, params string[] owned)
        {
            var rest = new List<string>();
            if (obj == null || !obj.IsObject || obj.Members == null) return rest;
            foreach (var m in obj.Members)
            {
                bool ours = false;
                for (int i = 0; i < owned.Length && !ours; i++) ours = owned[i] == m.Key;
                if (!ours) rest.Add(m.Key);
            }
            return rest;
        }

        public static JVal Clone(JVal v)
        {
            if (v == null) return null;
            switch (v.Kind)
            {
                case JKind.Object:
                    var o = JVal.NewObject();
                    foreach (var m in v.Members) o.Set(m.Key, Clone(m.Value));
                    return o;
                case JKind.Array:
                    var a = JVal.NewArray();
                    foreach (JVal item in v) a.Add(Clone(item));
                    return a;
                case JKind.String: return JVal.Of(v.Str);
                case JKind.Number: { var n = JVal.Of(v.Number); n.Str = v.Str; return n; }
                case JKind.Bool: return JVal.Of(v.Bool);
                default: return new JVal();
            }
        }

        public static string Sentence(IList<string> items)
        {
            if (items == null || items.Count == 0) return "";
            var sb = new StringBuilder();
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) sb.Append(i + 1 == items.Count ? " and " : ", ");
                sb.Append(items[i]);
            }
            return sb.ToString();
        }
    }

    public static class JBackup
    {
        public const int Keep = 20;

        public static string Take(string path, Action<string> log)
        {
            try
            {
                string full = Path.GetFullPath(path);
                if (!File.Exists(full)) return null;

                string dir = Path.GetDirectoryName(full);
                string name = Path.GetFileName(full);
                string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
                string backup = Path.Combine(dir, name + "." + stamp + ".bak");
                for (int n = 1; File.Exists(backup) && n < 100; n++)
                    backup = Path.Combine(dir, name + "." + stamp + "-" + n + ".bak");

                File.Copy(full, backup, false);
                Prune(dir, name, log);
                return backup;
            }
            catch (Exception e)
            {
                if (log != null)
                    log("WARNING: could not back up " + path + " before rewriting it (" + e.Message +
                        "). The build carried on, but there is no dated copy of the version you had.");
                return null;
            }
        }

        static void Prune(string dir, string name, Action<string> log)
        {
            try
            {
                string[] found = Directory.GetFiles(dir, name + ".*.bak");
                if (found.Length <= Keep) return;
                Array.Sort(found, StringComparer.Ordinal);
                for (int i = 0; i < found.Length - Keep; i++) File.Delete(found[i]);
                if (log != null)
                    log("  (older backups beyond the most recent " + Keep + " were tidied up)");
            }
            catch {  }
        }
    }
}
