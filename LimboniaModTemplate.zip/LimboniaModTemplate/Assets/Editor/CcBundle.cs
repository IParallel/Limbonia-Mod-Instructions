using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace Limbonia.CustomCharacter
{
    public static class CcBundle
    {
        public const string RequiredModule = "com.unity.modules.assetbundle";

        public const string PythonEnvVar = "LIMBONIA_PYTHON";

        public const string RequireVerifyEnvVar = "LIMBONIA_REQUIRE_BUNDLE_VERIFY";

        public static string ProjectRoot
        {
            get { return Path.GetDirectoryName(Application.dataPath).Replace('\\', '/'); }
        }

        public static string StagingDir
        {
            get { return ProjectRoot + "/Library/CustomCharacterBundle"; }
        }

        public static string BuildVerifyDeploy(string bundleName, string deployDir,
                                               IEnumerable<string> declaredAssetNames,
                                               Dictionary<string, int> clipKeyCounts, string bindingPath,
                                               Action<string> log)
        {
            if (log == null) log = s => { };
            if (string.IsNullOrEmpty(bundleName)) throw new Exception("no bundle name given");
            if (string.IsNullOrEmpty(deployDir)) throw new Exception("no output folder given (set the Mods folder)");

            var declared = new List<string>();
            if (declaredAssetNames != null)
                foreach (string n in declaredAssetNames)
                    if (!string.IsNullOrEmpty(n) && !declared.Contains(n)) declared.Add(n);

            string staging = StagingDir;
            if (string.Equals(bundleName, Path.GetFileName(staging), StringComparison.OrdinalIgnoreCase))
                throw new Exception("bundle name '" + bundleName + "' collides with the staging folder name");

            PreflightModuleWarning(log);

            Directory.CreateDirectory(staging);
            string staged = Path.Combine(staging, bundleName);

            log("building the bundle -> " + staging);
            AssetBundleManifest manifest = BuildCapturingLog(staging, log);

            if (manifest == null)
                throw new Exception("BuildPipeline.BuildAssetBundles returned null -- the build failed " +
                                    "(StrictMode is on, so any error during the build fails it). See the Console.");

            bool listed = false;
            var built = new List<string>(manifest.GetAllAssetBundles());
            foreach (string b in built) if (b == bundleName) { listed = true; break; }
            if (!listed)
                throw new Exception("the build did not produce '" + bundleName + "'. Bundles built: " +
                                    (built.Count == 0 ? "(none)" : string.Join(", ", built.ToArray())) +
                                    ". The assets' assetBundleName was probably never applied.");

            if (!File.Exists(staged))
                throw new Exception("the build reported '" + bundleName + "' but no file is at " + staged);

            log("  staged: " + staged + "  (" + new FileInfo(staged).Length + " bytes)");
            CheckHeader(staged, log);
            RunUnityPyVerify(staged, bundleName, declared, clipKeyCounts, bindingPath, log);

            Directory.CreateDirectory(deployDir);
            string dst = Path.Combine(deployDir, bundleName + ".bundle");
            File.Copy(staged, dst, true);
            log("  bundle deployed: " + dst + "  (" + new FileInfo(dst).Length + " bytes)");
            return dst;
        }

        public static void WarnAboutStaleDeploy(string bundleName, string deployDir, Action<string> log)
        {
            try
            {
                if (log == null || string.IsNullOrEmpty(deployDir) || string.IsNullOrEmpty(bundleName)) return;
                string dst = Path.Combine(deployDir, bundleName + ".bundle");
                if (!File.Exists(dst)) return;
                log("WARNING: nothing was deployed, but " + dst + " still exists from an earlier build (" +
                    File.GetLastWriteTime(dst).ToString("yyyy-MM-dd HH:mm:ss") + "). It does NOT contain this " +
                    "run's animations -- delete it rather than test it.");
            }
            catch { }
        }

        static void PreflightModuleWarning(Action<string> log)
        {
            try
            {
                string manifestPath = ProjectRoot + "/Packages/manifest.json";
                if (!File.Exists(manifestPath))
                {
                    log("WARNING: Packages/manifest.json is MISSING. Unity will fall back to defaults and the " +
                        "AssetBundle module may be disabled, which produces an archive the game rejects while " +
                        "blaming the Unity version. Restore it from the project you downloaded.");
                    return;
                }
                if (File.ReadAllText(manifestPath).IndexOf(RequiredModule, StringComparison.OrdinalIgnoreCase) >= 0) return;

                log("WARNING: " + RequiredModule + " is not listed in Packages/manifest.json. If the AssetBundle " +
                    "module is disabled, Unity writes an archive with NO AssetBundle object in it and the game " +
                    "rejects the file while blaming the Unity version. Add \"" + RequiredModule +
                    "\": \"1.0.0\" to Packages/manifest.json.");
            }
            catch {  }
        }

        static AssetBundleManifest BuildCapturingLog(string staging, Action<string> log)
        {
            var disabledModules = new List<string>();
            Application.LogCallback capture = (condition, stack, type) =>
            {
                if (string.IsNullOrEmpty(condition)) return;
                if (condition.IndexOf("is disabled in the build", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    condition.IndexOf("is not supported because the module", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    string line = condition.Trim();
                    if (!disabledModules.Contains(line)) disabledModules.Add(line);
                }
            };

            AssetBundleManifest manifest;
            Application.logMessageReceived += capture;
            try
            {
                manifest = BuildPipeline.BuildAssetBundles(
                    staging,
                    BuildAssetBundleOptions.StrictMode | BuildAssetBundleOptions.ChunkBasedCompression,
                    BuildTarget.StandaloneWindows64);
            }
            finally
            {
                Application.logMessageReceived -= capture;
            }

            if (disabledModules.Count > 0)
            {
                var sb = new StringBuilder();
                sb.Append("Unity built the archive with required engine modules DISABLED, so objects it could not ")
                  .Append("serialize were silently left out. The build still 'succeeds' and still writes a file; ")
                  .Append("the game then refuses it with a misleading \"not compatible with this newer version of ")
                  .Append("the Unity runtime\". Unity said:\n");
                foreach (string m in disabledModules) sb.Append("    ").Append(m).Append('\n');
                sb.Append("FIX: add the matching module package to Packages/manifest.json. For AssetBundle that is\n")
                  .Append("    \"").Append(RequiredModule).Append("\": \"1.0.0\"\n")
                  .Append("then let the editor reimport and build again.");
                throw new Exception(sb.ToString());
            }

            return manifest;
        }

        static void CheckHeader(string bundlePath, Action<string> log)
        {
            byte[] head;
            using (var fs = File.OpenRead(bundlePath))
            {
                head = new byte[96];
                int read = fs.Read(head, 0, head.Length);
                if (read < 32) throw new Exception("the bundle is only " + read + " bytes -- that is not an archive");
            }

            string magic = Encoding.ASCII.GetString(head, 0, 7);
            if (magic != "UnityFS") throw new Exception("bundle magic is '" + magic + "', expected 'UnityFS'");

            int format = (head[8] << 24) | (head[9] << 16) | (head[10] << 8) | head[11];
            if (format != 8)
                throw new Exception("UnityFS format is " + format + ", expected 8. The game only loads format 8 " +
                                    "(every shipped bundle is format 8). A different format means the wrong " +
                                    "editor built this -- use Unity 6000.3.12f1.");

            int p = 12;
            string playerVersion = ReadCString(head, ref p);
            string unityVersion = ReadCString(head, ref p);
            if (!string.IsNullOrEmpty(unityVersion) && unityVersion != "0.0.0" &&
                unityVersion != Application.unityVersion)
                log("WARNING: the bundle header says Unity " + unityVersion + " but this editor is " +
                    Application.unityVersion);

            log("  header: UnityFS format " + format + ", player '" + playerVersion + "', unity '" + unityVersion + "'");
        }

        static string ReadCString(byte[] buf, ref int p)
        {
            int start = p;
            while (p < buf.Length && buf[p] != 0) p++;
            string s = Encoding.ASCII.GetString(buf, start, p - start);
            if (p < buf.Length) p++;
            return s;
        }

        static void RunUnityPyVerify(string bundlePath, string bundleName, List<string> declaredAssetNames,
                                     Dictionary<string, int> clipKeyCounts, string bindingPath, Action<string> log)
        {
            bool required = Environment.GetEnvironmentVariable(RequireVerifyEnvVar) == "1";

            string script = ProjectRoot + "/verify_bundle.py";
            if (!File.Exists(script))
            {
                Soft(required, log, "verify_bundle.py is missing from " + ProjectRoot +
                     ". That script opens the built archive and proves it contains an AssetBundle object and " +
                     "every declared asset name. Without it, a broken archive is only detectable by launching " +
                     "the game.");
                return;
            }

            string python = FindPython();
            if (python == null)
            {
                Soft(required, log, "no Python was found, so the built bundle could not be double-checked. " +
                     "This is optional -- install Python 3 plus `pip install UnityPy==1.10.18` (or set " +
                     PythonEnvVar + " to a python.exe) if you want the extra check.");
                return;
            }

            var args = new StringBuilder();
            args.Append('"').Append(script.Replace('/', Path.DirectorySeparatorChar)).Append('"');
            args.Append(" \"").Append(bundlePath).Append('"');
            args.Append(" --bundle-name \"").Append(bundleName).Append('"');
            foreach (string n in declaredAssetNames) args.Append(" --asset \"").Append(n).Append('"');
            if (clipKeyCounts != null)
                foreach (KeyValuePair<string, int> kv in clipKeyCounts)
                    args.Append(" --clip \"").Append(kv.Key).Append(':').Append(kv.Value).Append('"');
            if (!string.IsNullOrEmpty(bindingPath))
                args.Append(" --clip-path \"").Append(bindingPath).Append('"');

            var psi = new ProcessStartInfo(python, args.ToString())
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                WorkingDirectory = ProjectRoot,
            };

            string stdout, stderr;
            int exit;
            try
            {
                using (var proc = Process.Start(psi))
                {
                    if (proc == null) throw new Exception("could not start " + python);
                    stdout = proc.StandardOutput.ReadToEnd();
                    stderr = proc.StandardError.ReadToEnd();
                    if (!proc.WaitForExit(120000))
                    {
                        try { proc.Kill(); } catch { }
                        throw new Exception("verify_bundle.py did not finish within 2 minutes");
                    }
                    exit = proc.ExitCode;
                }
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                Soft(required, log, "the bundle check could not be run (" + e.GetType().Name + ": " + e.Message + ")");
                return;
            }

            foreach (string line in (stdout ?? "").Replace("\r\n", "\n").Split('\n'))
                if (line.Trim().Length > 0) log("  check: " + line);

            if (exit == 0) return;

            if (exit == 2)
            {
                Soft(required, log, "the bundle check could not run: " + FirstLine(stdout, stderr) +
                     "  (install UnityPy with: pip install UnityPy==1.10.18)");
                return;
            }

            var sb = new StringBuilder();
            sb.Append("the built bundle FAILED verification and was NOT deployed").Append('\n');
            sb.Append(stdout);
            if (!string.IsNullOrEmpty(stderr)) sb.Append('\n').Append(stderr);
            throw new Exception(sb.ToString());
        }

        static void Soft(bool required, Action<string> log, string message)
        {
            if (required)
                throw new Exception(message + "\n(" + RequireVerifyEnvVar + "=1 is set, which makes this fatal.)");
            log("NOTE:    " + message);
        }

        static string FirstLine(string a, string b)
        {
            foreach (string s in new[] { a, b })
                if (!string.IsNullOrEmpty(s))
                    foreach (string line in s.Replace("\r\n", "\n").Split('\n'))
                        if (line.Trim().Length > 0) return line.Trim();
            return "(no output)";
        }

        static string FindPython()
        {
            string fromEnv = Environment.GetEnvironmentVariable(PythonEnvVar);
            if (!string.IsNullOrEmpty(fromEnv) && File.Exists(fromEnv)) return fromEnv;

            foreach (string candidate in new[] { "python.exe", "python3.exe", "py.exe", "python", "python3" })
                if (OnPath(candidate)) return candidate;
            return null;
        }

        static bool OnPath(string exe)
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("PATH") ?? "";
                foreach (string dir in path.Split(Path.PathSeparator))
                {
                    if (string.IsNullOrEmpty(dir)) continue;
                    try { if (File.Exists(Path.Combine(dir.Trim('"'), exe))) return true; }
                    catch { }
                }
            }
            catch { }
            return false;
        }
    }
}
