using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Timeline;

namespace Limbonia.CustomCharacter
{
    public class CcSound
    {
        public string Motion;
        public string TrackName;
        public bool TrackMuted;
        public int TrackIndex;

        public double Time;

        public double Length = 1.0;
        public double ClipIn;
        public double TimeScale = 1.0;
        public bool Loop;
        public string DisplayName;

        public float ClipVolume = 1f;
        public float TrackVolume = 1f;

        public AudioClip Clip;
        public string ClipAssetPath;
        public string SourceFile;

        public string Problem;

        public float Volume { get { return Mathf.Clamp01(TrackVolume * ClipVolume); } }

        public bool Shippable { get { return Problem == null && !TrackMuted && Clip != null; } }
    }

    public class CcAudioTrack
    {
        public string Name = "Sound";
        public bool Muted;
        public bool InsideGroup;
        public int TrackIndex;
        public float Volume = 1f;
        public float StereoPan;
        public float SpatialBlend;
        public readonly List<CcSound> Sounds = new List<CcSound>();
    }

    public class CcMotionAudio
    {
        public string Motion;
        public string TimelinePath;
        public readonly List<CcAudioTrack> Tracks = new List<CcAudioTrack>();

        public IEnumerable<CcSound> Sounds { get { return Tracks.SelectMany(t => t.Sounds); } }
        public IEnumerable<CcSound> Shippable { get { return Sounds.Where(s => s.Shippable); } }
        public bool Any { get { return Tracks.Count > 0; } }
    }

    public class CcSoundFile
    {
        public string Id;
        public string FileName;
        public string SourceFile;
        public long Bytes;
    }

    public static class CcAudio
    {
        public const string SoundsRoot = "Assets/CustomCharacter/Sounds";

        public static readonly string[] PlayableExtensions = { ".wav", ".ogg" };

        static readonly List<CcMotionAudio> s_pending = new List<CcMotionAudio>();

        public static void EnsureSoundsFolder(Action<string> log)
        {
            try
            {
                if (AssetDatabase.IsValidFolder(SoundsRoot)) return;
                CcBuild.EnsureFolder(SoundsRoot);
                string readme = Path.GetFullPath(SoundsRoot + "/_READ-ME-FIRST.txt");
                if (!File.Exists(readme))
                {
                    File.WriteAllText(readme,
                        "Put your sound files here: .wav or .ogg ONLY.\r\n" +
                        "\r\n" +
                        "Then build once, open the preview scene, select the motion you want under\r\n" +
                        "\"Sound and effects\" in the Hierarchy, open Window > Sequencing > Timeline, and\r\n" +
                        "drag the sound onto the timeline where you want it to play. Scrub -- you will\r\n" +
                        "hear it.\r\n" +
                        "\r\n" +
                        "Build again and the sound is written into mod.json and copied into the mod\r\n" +
                        "folder for you. The audio track itself is NOT shipped: the game's runtime\r\n" +
                        "cannot read one. Limbonia plays the file off the animation's own clock.\r\n" +
                        "\r\n" +
                        "mp3, aiff, m4a and everything else will NOT play in game. The build says so\r\n" +
                        "by name rather than letting you find out as silence.\r\n");
                    AssetDatabase.ImportAsset(SoundsRoot + "/_READ-ME-FIRST.txt");
                }
                if (log != null) log("created " + SoundsRoot + " -- put .wav or .ogg files there");
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                if (log != null) log("NOTE:    could not create " + SoundsRoot + " (" + e.Message + ")");
            }
        }

        public static CcMotionAudio Capture(string motion, string timelinePath)
        {
            var result = new CcMotionAudio { Motion = motion, TimelinePath = timelinePath };
            try
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath);
                if (timeline == null) return result;

                int index = 0;
                foreach (TrackAsset track in timeline.GetOutputTracks())
                {
                    var audio = track as AudioTrack;
                    if (audio == null) continue;

                    var cap = new CcAudioTrack
                    {
                        Name = string.IsNullOrEmpty(audio.name) ? "Sound" : audio.name,
                        Muted = audio.muted,
                        InsideGroup = audio.parent is GroupTrack,
                        TrackIndex = index,
                    };
                    ReadTrackProperties(audio, cap);

                    foreach (TimelineClip clip in audio.GetClips())
                    {
                        var asset = clip.asset as AudioPlayableAsset;
                        var s = new CcSound
                        {
                            Motion = motion,
                            TrackName = cap.Name,
                            TrackMuted = cap.Muted,
                            TrackIndex = index,
                            Time = clip.start,
                            Length = clip.duration,
                            ClipIn = clip.clipIn,
                            TimeScale = clip.timeScale,
                            DisplayName = clip.displayName,
                            TrackVolume = cap.Volume,
                        };
                        if (asset != null)
                        {
                            s.Clip = asset.clip;
                            s.Loop = asset.loop;
                            s.ClipVolume = ReadClipVolume(asset);
                        }
                        if (s.Clip != null)
                        {
                            s.ClipAssetPath = AssetDatabase.GetAssetPath(s.Clip);
                            if (!string.IsNullOrEmpty(s.ClipAssetPath))
                            {
                                try { s.SourceFile = Path.GetFullPath(s.ClipAssetPath); }
                                catch { s.SourceFile = null; }
                            }
                        }
                        cap.Sounds.Add(s);
                    }

                    result.Tracks.Add(cap);
                    index++;
                }
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] could not read the sound on " + timelinePath + ": " + e.Message);
            }

            if (result.Any) s_pending.Add(result);
            return result;
        }

        static void ReadTrackProperties(AudioTrack track, CcAudioTrack into)
        {
            try
            {
                var so = new SerializedObject(track);
                SerializedProperty v = so.FindProperty("m_TrackProperties.volume");
                SerializedProperty p = so.FindProperty("m_TrackProperties.stereoPan");
                SerializedProperty b = so.FindProperty("m_TrackProperties.spatialBlend");
                if (v != null) into.Volume = v.floatValue;
                if (p != null) into.StereoPan = p.floatValue;
                if (b != null) into.SpatialBlend = b.floatValue;
            }
            catch {  }
        }

        static float ReadClipVolume(AudioPlayableAsset asset)
        {
            try
            {
                var so = new SerializedObject(asset);
                SerializedProperty v = so.FindProperty("m_ClipProperties.volume");
                if (v != null) return v.floatValue;
            }
            catch { }
            return 1f;
        }

        public static void StripTracks(string timelinePath)
        {
            try
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath);
                if (timeline == null) return;
                var doomed = new List<AudioTrack>();
                foreach (TrackAsset t in timeline.GetOutputTracks())
                {
                    var audio = t as AudioTrack;
                    if (audio != null) doomed.Add(audio);
                }
                if (doomed.Count == 0) return;
                foreach (AudioTrack t in doomed) timeline.DeleteTrack(t);
                EditorUtility.SetDirty(timeline);
                AssetDatabase.SaveAssets();
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] could not take the audio track off " + timelinePath +
                                 " before building: " + e.Message);
            }
        }

        public static void RestorePending(Action<string> log)
        {
            if (s_pending.Count == 0) return;
            var pending = new List<CcMotionAudio>(s_pending);
            s_pending.Clear();

            int tracks = 0, sounds = 0, failed = 0;
            foreach (CcMotionAudio ma in pending)
            {
                try { if (RestoreOne(ma)) { tracks += ma.Tracks.Count; sounds += ma.Sounds.Count(); } else failed++; }
                catch (ExitGUIException) { throw; }
                catch (Exception e)
                {
                    failed++;
                    Debug.LogWarning("[CustomCharacter] could not put the sound back on " + ma.TimelinePath +
                                     ": " + e.Message);
                }
            }

            if (tracks > 0 || failed > 0)
            {
                try { AssetDatabase.SaveAssets(); } catch { }
                if (log != null)
                {
                    log("");
                    log("sound: " + tracks + " audio track(s) holding " + sounds + " clip(s) put back on the " +
                        "timelines in " + CcBuild.GeneratedRoot + " so you can keep editing them.");
                    log("  They were taken off only for the moment the bundle was built. THE BUNDLE CONTAINS NO");
                    log("  AUDIO TRACK, on purpose: the game's runtime cannot deserialize one, so it would be dead");
                    log("  weight. Your sound was consumed at build time and written into mod.json instead.");
                    if (failed > 0)
                        log("WARNING: " + failed + " timeline(s) could not have their sound put back -- see the " +
                            "Console. Re-drag those clips before the next build, or they are lost.");
                }
            }
        }

        static bool RestoreOne(CcMotionAudio ma)
        {
            var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(ma.TimelinePath);
            if (timeline == null) return false;

            foreach (CcAudioTrack cap in ma.Tracks)
            {
                var track = timeline.CreateTrack<AudioTrack>(null, cap.Name);
                if (track == null) return false;
                if (!AssetDatabase.Contains(track)) AssetDatabase.AddObjectToAsset(track, timeline);
                track.muted = cap.Muted;
                WriteTrackProperties(track, cap);

                foreach (CcSound s in cap.Sounds)
                {
                    TimelineClip clip = s.Clip != null ? track.CreateClip(s.Clip)
                                                       : track.CreateClip<AudioPlayableAsset>();
                    if (clip == null) continue;
                    clip.start = s.Time;
                    if (s.Length > 0.0) clip.duration = s.Length;
                    clip.clipIn = s.ClipIn;
                    if (s.TimeScale > 0.0) clip.timeScale = s.TimeScale;
                    if (!string.IsNullOrEmpty(s.DisplayName)) clip.displayName = s.DisplayName;

                    var asset = clip.asset as AudioPlayableAsset;
                    if (asset != null)
                    {
                        asset.loop = s.Loop;
                        WriteClipVolume(asset, s.ClipVolume);
                        if (!AssetDatabase.Contains(asset)) AssetDatabase.AddObjectToAsset(asset, timeline);
                    }
                }
                EditorUtility.SetDirty(track);
            }
            EditorUtility.SetDirty(timeline);
            return true;
        }

        static void WriteTrackProperties(AudioTrack track, CcAudioTrack cap)
        {
            try
            {
                var so = new SerializedObject(track);
                SerializedProperty v = so.FindProperty("m_TrackProperties.volume");
                SerializedProperty p = so.FindProperty("m_TrackProperties.stereoPan");
                SerializedProperty b = so.FindProperty("m_TrackProperties.spatialBlend");
                if (v != null) v.floatValue = cap.Volume;
                if (p != null) p.floatValue = cap.StereoPan;
                if (b != null) b.floatValue = cap.SpatialBlend;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            catch { }
        }

        static void WriteClipVolume(AudioPlayableAsset asset, float volume)
        {
            try
            {
                var so = new SerializedObject(asset);
                SerializedProperty v = so.FindProperty("m_ClipProperties.volume");
                if (v != null) { v.floatValue = volume; so.ApplyModifiedPropertiesWithoutUndo(); }
            }
            catch { }
        }

        public static void Validate(CcMotionAudio ma, double motionDuration, int coins, int declaredCoin,
                                    Action<string> info, Action<string> warn)
        {
            if (ma == null || !ma.Any) return;

            int muted = 0;
            foreach (CcAudioTrack t in ma.Tracks)
            {
                if (t.Muted) muted++;
                if (t.InsideGroup)
                    warn("  " + ma.Motion + ": the audio track '" + t.Name + "' is inside a track group. The sound " +
                         "still ships, but the group is not put back after a build -- the track reappears at the " +
                         "top level of the timeline.");
            }

            foreach (CcSound s in ma.Sounds)
            {
                if (s.Clip == null)
                {
                    s.Problem = "an empty clip at " + s.Time.ToString("0.###", CultureInfo.InvariantCulture) +
                                "s with no sound file in it";
                    warn("  " + ma.Motion + ": SOUND NOT SHIPPED -- an empty audio clip sits at " +
                         s.Time.ToString("0.###", CultureInfo.InvariantCulture) + "s with no sound file in it. " +
                         "Drag a .wav or .ogg onto it, or delete the clip.");
                    continue;
                }

                if (string.IsNullOrEmpty(s.SourceFile) || !File.Exists(s.SourceFile))
                {
                    s.Problem = "'" + s.Clip.name + "' has no file of its own on disk";
                    warn("  " + ma.Motion + ": SOUND NOT SHIPPED -- '" + s.Clip.name + "' has no file behind it (" +
                         (s.ClipAssetPath ?? "unknown path") + "). A clip that lives inside another asset cannot " +
                         "be copied into the mod -- import the sound as its own .wav or .ogg file.");
                    continue;
                }

                string ext = (Path.GetExtension(s.SourceFile) ?? "").ToLowerInvariant();
                if (Array.IndexOf(PlayableExtensions, ext) < 0)
                {
                    string kind = ext.Length > 1 ? ext.Substring(1).ToUpperInvariant() : "unknown";
                    s.Problem = Path.GetFileName(s.SourceFile) + " is " + Article(kind) + " " + kind +
                                " file, and only WAV and OGG play in game";
                    warn("  " + ma.Motion + ": SOUND NOT SHIPPED -- " + Path.GetFileName(s.SourceFile) + " is " +
                         Article(kind) + " " + kind + " file, and Limbonia plays only WAV and OGG. Unity imports " +
                         "it happily, which is exactly why this is worth saying now: in game it would be SILENCE " +
                         "with no error anywhere. Convert it to .wav or .ogg, put the new file in " + SoundsRoot +
                         ", and drag that onto the timeline instead.");
                    continue;
                }

                string headerComplaint = HeaderComplaint(s.SourceFile, ext);
                if (headerComplaint != null)
                {
                    s.Problem = Path.GetFileName(s.SourceFile) + " " + headerComplaint;
                    warn("  " + ma.Motion + ": SOUND NOT SHIPPED -- " + Path.GetFileName(s.SourceFile) + " " +
                         headerComplaint + ". Renaming a file does not convert it -- re-export it properly.");
                    continue;
                }

                if (s.Time < 0.0)
                {
                    warn("  " + ma.Motion + ": '" + s.Clip.name + "' starts before the animation does; moved to 0s.");
                    s.Time = 0.0;
                }

                if (motionDuration > 0.0 && s.Time > motionDuration)
                {
                    warn("  " + ma.Motion + ": '" + s.Clip.name + "' is placed at " +
                         s.Time.ToString("0.###", CultureInfo.InvariantCulture) + "s but " + ma.Motion +
                         " is only " + motionDuration.ToString("0.###", CultureInfo.InvariantCulture) +
                         "s long, so it can NEVER play. It is still written into mod.json in case you lengthen " +
                         "the animation -- move it earlier, or draw more frames.");
                }

                if (s.Loop)
                    warn("  " + ma.Motion + ": '" + s.Clip.name + "' has Loop ticked. Limbonia fires a sound ONCE " +
                         "and does not loop it, so it will play through a single time in game.");
            }

            int usable = ma.Shippable.Count();
            if (usable > 0 && coins > 1 && declaredCoin < 0)
                warn("  " + ma.Motion + ": this character's " + ma.Motion + " has " + coins + " coins and your " +
                     "animation is declared for all of them, but A SOUND PLAYS ON THE FIRST CLASH ONLY. Limbonia " +
                     "scopes a cue to one coin, and an animation declared for every coin scopes its sounds to coin " +
                     "0. Expect to hear it once per skill, not " + coins + " times.");
            if (usable > 0 && coins > 1 && declaredCoin < 0)
                info("  " + ma.Motion + ": to hear a sound on EVERY clash, name this motion's drawings by coin " +
                     "(0_1.png, 0_2.png ... for the first clash, 1_1.png ... for the second). Each clash then has " +
                     "its own animation and its own sound, placed on its own timeline in the preview scene.");
            if (usable > 0 && declaredCoin >= 0)
                info("  " + ma.Motion + ": " + usable + " sound(s) -- these are scoped to coin " + declaredCoin +
                     ", so they are heard on clash " + (declaredCoin + 1) + " of the skill and not on the others.");

            if (muted > 0 && usable == 0 && ma.Sounds.Any())
                info("  " + ma.Motion + ": every audio track on it is muted, so nothing is written. Un-mute the " +
                     "track in the Timeline window if that was not deliberate.");
        }

        static string Article(string word)
        {
            if (string.IsNullOrEmpty(word)) return "a";
            return "AEFHILMNORSX".IndexOf(char.ToUpperInvariant(word[0])) >= 0 ? "an" : "a";
        }

        static string HeaderComplaint(string file, string ext)
        {
            try
            {
                byte[] head = new byte[12];
                int read;
                using (var fs = File.OpenRead(file)) read = fs.Read(head, 0, head.Length);
                if (read <= 0) return "is empty (0 bytes)";
                if (read < 12) return "is only " + read + " bytes long, which is not a sound file";

                bool riff = head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F';
                bool wave = head[8] == 'W' && head[9] == 'A' && head[10] == 'V' && head[11] == 'E';
                bool ogg = head[0] == 'O' && head[1] == 'g' && head[2] == 'g' && head[3] == 'S';

                if (ext == ".wav" && !(riff && wave))
                    return "is named .wav but is not a WAV file inside" + (ogg ? " (it is an Ogg)" : "");
                if (ext == ".ogg" && !ogg)
                    return "is named .ogg but is not an Ogg file inside" + (riff ? " (it is a WAV)" : "");
                return null;
            }
            catch (Exception e) { return "could not be read (" + e.Message + ")"; }
        }

        public static Dictionary<string, CcSoundFile> Deploy(string audioDir, IEnumerable<CcMotionAudio> all,
                                                             Action<string> log)
        {
            var bySource = new Dictionary<string, CcSoundFile>(StringComparer.OrdinalIgnoreCase);
            if (all == null) return bySource;

            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (CcMotionAudio ma in all)
            {
                if (ma == null) continue;
                foreach (CcSound s in ma.Shippable)
                {
                    if (string.IsNullOrEmpty(s.SourceFile) || bySource.ContainsKey(s.SourceFile)) continue;

                    string ext = Path.GetExtension(s.SourceFile);
                    string stem = Path.GetFileNameWithoutExtension(s.SourceFile);
                    string id = stem;
                    for (int n = 2; used.Contains(id); n++) id = stem + "_" + n;
                    used.Add(id);

                    var sf = new CcSoundFile { Id = id, FileName = id + ext, SourceFile = s.SourceFile };
                    bySource[s.SourceFile] = sf;
                }
            }

            if (bySource.Count == 0) return bySource;

            Directory.CreateDirectory(audioDir);
            foreach (CcSoundFile sf in bySource.Values)
            {
                string dst = Path.Combine(audioDir, sf.FileName);
                File.Copy(sf.SourceFile, dst, true);
                sf.Bytes = new FileInfo(dst).Length;
                if (log != null)
                    log("  sound file: " + sf.FileName + "  (" + sf.Bytes + " bytes, from " +
                        MakeProjectRelative(sf.SourceFile) + ")");
            }
            return bySource;
        }

        static string MakeProjectRelative(string abs)
        {
            try
            {
                string root = Path.GetFullPath(CcBundle.ProjectRoot);
                string full = Path.GetFullPath(abs);
                if (full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    return full.Substring(root.Length).TrimStart('\\', '/').Replace('\\', '/');
                return full;
            }
            catch { return abs; }
        }
    }
}
