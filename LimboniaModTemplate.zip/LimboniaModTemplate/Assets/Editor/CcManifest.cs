using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public static class CcManifest
    {
        public const string FileName = "mod.json";

        public const string BundleSubFolder = "motions";

        public const string AudioSubFolder = "audio";

        static readonly HashSet<string> SkillMotions = new HashSet<string> { "S1", "S2", "S3" };

        public const string RendererSidecar = "sidecar";

        public const string RendererSlot = "slot";

        public static string NormaliseRenderer(string route)
        {
            if (route == null) return RendererSidecar;
            string r = route.Trim().ToLowerInvariant();
            return r == RendererSlot ? RendererSlot : RendererSidecar;
        }

        public static string RendererExplanation(string route)
        {
            return NormaliseRenderer(route) == RendererSidecar
                ? "Limbonia draws your animation itself, as a second character on top of the original, and " +
                  "leaves the game's own animation running invisibly underneath. Every hit, clash and camera " +
                  "beat therefore happens exactly when it does with no mod installed. A motion you did not " +
                  "draw plays YOUR Idle (or Default) rather than showing the original character."
                : "your animation would be written into the character's own animation list, which is how every " +
                  "mod used to work. THAT WAY OF DRAWING HAS BEEN REMOVED FROM LIMBONIA and nothing plays it -- " +
                  "a mod that asks for it installs and then shows the original character, exactly as if it were " +
                  "not there. Build for the second character instead.";
        }

        public const string BundlePrefix = "customchar_";

        public const string BundleIdKey = "bundleId";

        public static string MakeBundleName(string modName, string bundleId)
        {
            string id = string.IsNullOrEmpty(bundleId) ? "0" : bundleId;
            return (BundlePrefix + CcBuild.Sanitize(modName) + "_" + CcBuild.Sanitize(id)).ToLowerInvariant();
        }

        public static bool LooksLikeBundleId(string s)
        {
            if (s == null || s.Length != 8) return false;
            foreach (char c in s)
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
            return true;
        }

        public static string NewBundleId()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 8).ToLowerInvariant();
        }

        public static string ResolveBundleId(string modDir, string modName, string appearanceName, out string how)
        {
            string prefix = (BundlePrefix + CcBuild.Sanitize(modName) + "_").ToLowerInvariant();

            try
            {
                if (!string.IsNullOrEmpty(modDir))
                {
                    string path = Path.Combine(modDir, FileName);
                    if (File.Exists(path))
                    {
                        JVal doc = MiniJson.Parse(File.ReadAllText(path));
                        if (doc != null && doc.IsObject)
                        {
                            string recorded = doc[BundleIdKey].AsString(null);
                            if (LooksLikeBundleId(recorded))
                            {
                                how = "read from \"" + BundleIdKey + "\" at the top of your " + FileName +
                                      ", where the last build recorded it";
                                return recorded;
                            }

                            string legacy = LegacyIdInPacks(doc, prefix, appearanceName);
                            if (legacy != null)
                            {
                                how = "kept from the archive this mod already ships (" + prefix + legacy +
                                      ".bundle)" + (LooksLikeBundleId(legacy)
                                          ? ", because the \"" + BundleIdKey + "\" line that recorded it is no " +
                                            "longer in your " + FileName
                                          : ". This mod was built before bundle ids existed, so nothing has been " +
                                            "renamed and the file you already have is the one being replaced");
                                return legacy;
                            }
                        }
                    }
                }
            }
            catch {  }

            try
            {
                if (!string.IsNullOrEmpty(modDir))
                {
                    string dir = Path.Combine(modDir, BundleSubFolder);
                    if (Directory.Exists(dir))
                    {
                        string best = null;
                        DateTime bestAt = DateTime.MinValue;
                        foreach (string f in Directory.GetFiles(dir, "*.bundle"))
                        {
                            string stem = (Path.GetFileNameWithoutExtension(f) ?? "").ToLowerInvariant();
                            if (!stem.StartsWith(prefix, StringComparison.Ordinal)) continue;
                            string id = stem.Substring(prefix.Length);
                            if (!LooksLikeBundleId(id)) continue;
                            DateTime at = File.GetLastWriteTimeUtc(f);
                            if (best != null && at <= bestAt) continue;
                            best = id;
                            bestAt = at;
                        }
                        if (best != null)
                        {
                            how = "recovered from the archive already in " + BundleSubFolder + "/ (your " +
                                  FileName + " no longer records it)";
                            return best;
                        }
                    }
                }
            }
            catch { }

            how = "newly made for this mod, and recorded in " + FileName + " so every later build reuses it";
            return NewBundleId();
        }

        static string LegacyIdInPacks(JVal doc, string prefix, string appearanceName)
        {
            JVal motions = doc["motions"];
            if (motions == null || !motions.IsArray) return null;

            var packs = new List<JVal>();
            foreach (JVal p in motions) if (p != null && p.IsObject) packs.Add(p);

            foreach (JVal p in packs)
            {
                JVal app = p["appearance"];
                string s = app.Kind == JKind.String ? app.Str
                         : app.Kind == JKind.Number ? app.AsRawNumber() : null;
                bool mine = packs.Count == 1 || (s != null && s == appearanceName);
                if (!mine) continue;
                string id = IdInBundleRef(p["bundle"].AsString(""), prefix);
                if (id != null) return id;
            }
            return null;
        }

        static string IdInBundleRef(string bundleRel, string prefix)
        {
            if (string.IsNullOrEmpty(bundleRel)) return null;
            string stem = (Path.GetFileNameWithoutExtension(bundleRel.Replace('\\', '/')) ?? "").ToLowerInvariant();
            if (!stem.StartsWith(prefix, StringComparison.Ordinal)) return null;
            string id = stem.Substring(prefix.Length);
            return id.Length == 0 ? null : id;
        }

        public const string CoinSuffix = "_coin";

        public static string AssetNameFor(string modName, string motion, int coin)
        {
            string name = CcBuild.Sanitize(modName) + "_" + motion;
            return coin < 0 ? name : name + CoinSuffix + coin.ToString(CultureInfo.InvariantCulture);
        }

        public static string AssetNameFor(string modName, string motion)
        {
            return AssetNameFor(modName, motion, -1);
        }

        public static string LabelFor(string motion, int coin)
        {
            return coin < 0 ? motion : motion + " coin " + coin.ToString(CultureInfo.InvariantCulture);
        }

        public static void ExplainMotion(string motion, int coin, Target target, string route, Action<string> log)
        {
            if (log == null) return;
            bool sidecar = NormaliseRenderer(route) == RendererSidecar;
            TargetMotion tm = target != null ? target.Find(motion) : null;

            if (tm == null)
            {
                log(coin < 0
                    ? "  in game: coin coverage unknown (this character is not in the catalog). Declared with " +
                      "\"index\": -1, which means \"every coin\"."
                    : "  in game: declared for coin " + coin + " only. How many coins this character's " + motion +
                      " has is unknown -- it is not in the catalog -- so whether coin " + coin + " exists cannot " +
                      "be checked here.");
                return;
            }

            if (coin >= 0 && tm.Coins > 0 && coin >= tm.Coins)
            {
                log("  in game: NOTHING. This character's " + motion + " has " + tm.Coins + " coin animation(s), " +
                    "numbered 0 to " + (tm.Coins - 1) + ", so clash " + (coin + 1) + " never happens and this " +
                    "animation is never reached. Move these drawings into a folder numbered 0 to " +
                    (tm.Coins - 1) + ".");
                return;
            }

            if (tm.Coins > 0)
            {
                if (coin >= 0)
                {
                    log("  in game: this character's " + motion + " has " + tm.Coins + " coin animation(s). This " +
                        "one is declared for coin " + coin + " alone, so it plays on clash " + (coin + 1) + ".");
                    return;
                }
                log("  in game: this character's " + motion + " has " + tm.Coins + " coin animation(s). Declared " +
                    "with \"index\": -1, so yours plays on ALL of them" +
                    (tm.Coins > 1 ? " -- it will play " + tm.Coins + " times over the skill, once per clash." : "."));
                if (tm.Coins > 1)
                    log("           WANT A DIFFERENT ANIMATION PER CLASH? Give each clash its own numbered folder: " +
                        motion + "/0/1.png, 2.png ... for the first clash, " + motion + "/1/1.png, 2.png ... for " +
                        "the second, and so on from 0. " +
                        (sidecar
                            ? "Every clash you do not draw falls back to this whole-skill animation."
                            : "Every clash you do not draw keeps the ORIGINAL character's animation."));
                return;
            }

            if (sidecar)
            {
                if (coin > 0)
                {
                    log("  in game: NOTHING. " + motion + " is a still pose -- it has no clashes to number -- so " +
                        "there is no clash " + (coin + 1) + " for this to play on. Move these drawings straight " +
                        "into " + motion + "/, out of the numbered folder, and they will play.");
                    return;
                }
                log("  in game: this character's " + motion + " is a single still drawing. Limbonia draws yours " +
                    "beside the character instead, so nothing has to be added to the character to make it play.");
                if (motion == "Idle")
                    log("           Idle normally draws through the character's SPINE skeleton, which would cover " +
                        "your art. Limbonia asks the game to stop drawing the skeleton while your animation is on " +
                        "screen, so this is handled -- but it is the one to look at in a battle rather than assume.");
                else if (motion == "Default")
                    log("           DEFAULT IS THE ONE PEOPLE MISS. It is the neutral standing state the character " +
                        "returns to after everything, so draw it even if you draw nothing else.");
                return;
            }

            if (coin > 0)
            {
                log("  in game: NOTHING. " + motion + " is a still pose on this character -- it has no clashes to " +
                    "number -- and Limbonia refuses any clash above the first on one. Move these drawings straight " +
                    "into " + motion + "/, out of the numbered folder, and they will play.");
                return;
            }

            log("  in game: this character's " + motion + " has NO animation of its own -- the game plays it as a " +
                "single still drawing. Limbonia ADDS an animation slot for it (confirmed working in a battle).");

            if (motion == "Default")
                log("           DEFAULT IS THE ONE PEOPLE MISS. It is the neutral standing state, and the game " +
                    "drops back to it whenever Idle is not what is playing -- so leaving it undrawn makes the " +
                    "ORIGINAL character flash through after every skill, hit and return to standing.");

            if (motion == "Idle")
            {
                log("           Idle has been seen playing in game, so it works -- but check it on YOUR character. " +
                    "The game switches to a Spine skeleton for Idle before it ever reads this slot, so with a " +
                    "live Spine skin your animation can be installed, running and hidden behind the skeleton.");
                log("           Draw Default as well either way: the standing state falls back to it, and Default " +
                    "is not Spine-driven on any of the 179 characters measured.");
            }
            else if (tm.Spine)
                log("           " + motion + " is flagged to play through this character's SPINE skeleton, which " +
                    "hides the sprites. Limbonia switches that flag off for this slot when it fills it.");
        }

        public static void Write(string modDir, CcBuildOptions o, string bundleName, string bundleId,
                                 List<CcBuild.MotionBuild> built, List<EffectBuild> effects,
                                 Dictionary<string, CcSoundFile> soundFiles, string bindingPath, Action<string> log)
        {
            if (log == null) log = s => { };
            Directory.CreateDirectory(modDir);
            string path = Path.Combine(modDir, FileName);

            JVal doc;
            string backup = null;
            bool hadFile = File.Exists(path);
            if (hadFile)
            {
                backup = JBackup.Take(path, log);
                try { doc = MiniJson.Parse(File.ReadAllText(path)); }
                catch (Exception e)
                {
                    log("WARNING: your " + FileName + " is not valid JSON (" + e.Message + "), so nothing in it " +
                        "could be read and nothing in it could be kept. A fresh one has been written.");
                    if (backup != null)
                        log("         YOUR PREVIOUS FILE IS NOT LOST. It is at " + backup + " -- fix the bracket " +
                            "there, copy it back over " + FileName + ", and build again.");
                    doc = JVal.NewObject();
                }
                if (!doc.IsObject) doc = JVal.NewObject();
            }
            else doc = JVal.NewObject();

            JMerge.SetIfAbsent(doc, "name", JVal.Of(o.ModName));
            JMerge.SetIfAbsent(doc, "enabled", JVal.Of(true));

            if (LooksLikeBundleId(bundleId)) JMerge.SetIfAbsent(doc, BundleIdKey, JVal.Of(bundleId));

            WriteAudioSection(doc, soundFiles, log);

            JVal motions = doc["motions"];
            if (motions == null || !motions.IsArray) { motions = JVal.NewArray(); doc.Set("motions", motions); }

            string bundleRel = BundleSubFolder + "/" + bundleName + ".bundle";
            JVal pack = FindPack(motions, o.AppearanceName, bundleRel);
            bool freshPack = pack == null;
            if (freshPack) { pack = JVal.NewObject(); motions.Add(pack); }

            JMerge.SetIfAbsent(pack, "appearance", JVal.Of(o.AppearanceName));
            pack.Set("bundle", JVal.Of(bundleRel));

            string route = NormaliseRenderer(o != null ? o.Renderer : null);
            string packRoute = pack["renderer"].AsString(null);
            string docRoute = doc["renderer"].AsString(null);
            bool packRouteUsable = packRoute == RendererSidecar || packRoute == RendererSlot;
            bool docRouteUsable = docRoute == RendererSidecar || docRoute == RendererSlot;

            bool wroteRoute = false;
            string routeInFile;
            if (packRouteUsable) routeInFile = packRoute;
            else if (packRoute == null && docRouteUsable) routeInFile = docRoute;
            else if (packRoute == null) { pack.Set("renderer", JVal.Of(route)); wroteRoute = true; routeInFile = route; }
            else routeInFile = route;

            bool wroteSpritePath = false;
            string spritePathInFile = null;
            if (!string.IsNullOrEmpty(bindingPath))
            {
                wroteSpritePath = JMerge.SetIfAbsent(pack, "spritePath", JVal.Of(bindingPath));
                spritePathInFile = pack["spritePath"].AsString(bindingPath);
            }

            JVal assets = pack["assets"];
            if (assets == null || !assets.IsArray) { assets = JVal.NewArray(); pack.Set("assets", assets); }

            var existing = new List<JVal>();
            foreach (JVal a in assets) if (a != null && a.IsObject) existing.Add(a);
            var used = new HashSet<JVal>();

            var keptMove = new List<string>();
            var keptOther = new List<string>();
            var coinDisagreements = new List<string>();
            int newEntries = 0;

            foreach (CcBuild.MotionBuild mb in built)
            {
                JVal d = FindAsset(existing, used, mb.AssetName, mb.Motion, mb.Coin);
                bool fresh = d == null;
                if (fresh) { d = JVal.NewObject(); assets.Add(d); newEntries++; }
                else used.Add(d);

                d.Set("name", JVal.Of(mb.AssetName));
                d.Set("type", JVal.Of("TimelineAsset"));
                d.Set("motion", JVal.Of(mb.Motion));

                d.Set("fps", JVal.Of(System.Math.Round(mb.Fps * 1000.0) / 1000.0));

                int frames = (int)System.Math.Round(mb.Duration * mb.Fps);
                if (frames < 1) frames = 1;
                d.Set("frames", JVal.Of(frames));

                JMerge.SetIfAbsent(d, "index", JVal.Of(mb.Coin));
                if (!fresh && IndexOf(d) != mb.Coin)
                    coinDisagreements.Add(mb.Label + ": your " + FileName + " declares \"" + mb.AssetName +
                                          "\" for " + CoinWords(IndexOf(d)) + ", and the drawings it was built " +
                                          "from say " + CoinWords(mb.Coin) + ". YOURS WAS KEPT -- nothing here " +
                                          "overwrites an index you set. Change one of them if that was not " +
                                          "deliberate.");

                if (!JMerge.Has(d, "move"))
                {
                    JVal move = MoveFor(mb, o, log);
                    if (move != null) d.Set("move", move);
                }
                else keptMove.Add(mb.Label);

                MergeCues(d, mb, o, soundFiles, log);
                MergeVfx(d, mb, backup, log);

                foreach (string k in JMerge.KeysOtherThan(d, "name", "type", "motion", "fps", "frames", "index",
                                                          "move", "cues", "vfx"))
                    if (!keptOther.Contains(k)) keptOther.Add(k);
            }

            int newEffects = 0;
            foreach (EffectBuild eb in (effects ?? new List<EffectBuild>()))
            {
                JVal d = FindAssetByName(existing, used, eb.AssetName);
                if (d == null) { d = JVal.NewObject(); assets.Add(d); newEffects++; }
                else used.Add(d);
                d.Set("name", JVal.Of(eb.AssetName));
                d.Set("type", JVal.Of("GameObject"));
                foreach (string k in JMerge.KeysOtherThan(d, "name", "type"))
                    if (!keptOther.Contains(k)) keptOther.Add(k);
            }

            var orphans = new List<JVal>();
            foreach (JVal a in existing) if (!used.Contains(a)) orphans.Add(a);

            File.WriteAllText(path, MiniJson.Write(doc));

            log("");
            log(FileName + " written: " + path);
            if (backup != null)
                log("  the version you had is kept at " + Path.GetFileName(backup) + " (same folder), so nothing " +
                    "this build did is one-way.");

            log("");
            log("  REGENERATED (the build owns these): the bundle path, and the name/type/motion/frame count of " +
                built.Count + " animation(s)" + (newEntries > 0
                    ? " -- " + newEntries + " of them declared for the first time, each with the coin its " +
                      "drawings named (\"index\": -1 = every coin, which is what undivided drawings get)"
                    : ""));

            ReportArchives(modDir, bundleName, doc, log);

            log("");
            log("  RENDERER: " + routeInFile.ToUpperInvariant() + " -- " + RendererExplanation(routeInFile));
            if (routeInFile == RendererSlot)
            {
                log("    >>> THIS MOD WILL NOT BE DRAWN. That way of drawing has been removed from Limbonia. The " +
                    "mod loads,");
                log("        and then the ORIGINAL character plays its own animations -- everything else in the " +
                    "mod (art,");
                log("        names, voices, sounds, effects) still works.");
                log("        THE FIX: delete the \"renderer\" line from " + FileName + " (this build does not " +
                    "overwrite one that");
                log("        is already there) and build again with \"Let Limbonia draw the character\" ticked. Or " +
                    "set this");
                log("        mod to \"Draw a second character on top\" in the companion's Mods panel, which needs " +
                    "no rebuild.");
            }
            if (wroteRoute)
                log("    Written into " + FileName + " as \"renderer\": \"" + routeInFile + "\" on this " +
                    "character's entry, so the mod states it rather than depending on the setting of whoever " +
                    "runs it. Change it there, or in the window, and build again.");
            else if (packRouteUsable)
                log("    Already set on this character's entry in " + FileName + ", and left exactly as it was" +
                    (routeInFile != route
                        ? " -- even though the window says \"" + route + "\". YOURS WINS. Change one of them if " +
                          "that was not deliberate."
                        : "."));
            else if (docRouteUsable)
                log("    Read from the TOP of " + FileName + ", where you set it for the whole mod. Nothing was " +
                    "written on this character's entry, so that one answer still covers every section" +
                    (routeInFile != route
                        ? " -- even though the window says \"" + route + "\". YOURS WINS."
                        : "."));

            if (packRoute != null && !packRouteUsable)
                log("    >>> YOUR " + FileName + " SAYS \"renderer\": \"" + packRoute + "\" ON THIS CHARACTER'S " +
                    "ENTRY, and Limbonia does not recognise that. It accepts \"sidecar\" -- the only one that " +
                    "draws anything -- or \"slot\", the removed one, and nothing else, spelling and capitals " +
                    "exactly. So as written the key does nothing and the mod is drawn by whatever the person " +
                    "running it has set. IT WAS LEFT AS YOU WROTE IT. The line above is what this build would " +
                    "have asked for.");
            if (docRoute != null && !docRouteUsable)
                log("    >>> THE TOP OF YOUR " + FileName + " SAYS \"renderer\": \"" + docRoute + "\", which " +
                    "Limbonia does not recognise (\"sidecar\", or \"slot\" for the removed way of drawing). That " +
                    "key does nothing as written. IT WAS LEFT AS YOU WROTE IT.");

            if (wroteRoute && !freshPack)
            {
                log("");
                log("  >>> THIS MOD ALREADY EXISTED AND HAD NO RENDERER SET, so it was drawn by whatever the " +
                    "person");
                log("      running it had chosen. It now asks for " + routeInFile.ToUpperInvariant() + " by name.");
                if (routeInFile == RendererSidecar)
                {
                    log("      NOTHING IN YOUR BUNDLE CHANGED. The same animations are used, unaltered; only who " +
                        "draws them.");
                    log("      This is the only way Limbonia draws a custom animation now, so this is the answer " +
                        "you want in");
                    log("      the file. If the mod had been sitting on the older route, it was not being drawn " +
                        "at all.");
                }
            }

            if (routeInFile == RendererSidecar)
            {
                bool hasIdle = false, hasDefault = false;
                foreach (CcBuild.MotionBuild mb in built)
                {
                    if (mb.Motion == "Idle") hasIdle = true;
                    else if (mb.Motion == "Default") hasDefault = true;
                }
                if (hasIdle || hasDefault)
                    log("    Motions you did not draw play your " + (hasIdle ? "Idle" : "Default") +
                        " instead of showing the original character.");
                else
                    log("    >>> YOU HAVE DRAWN NEITHER Idle NOR Default. This renderer covers a motion you did " +
                        "not draw by playing your Idle (or your Default) instead -- with neither, it has nothing " +
                        "to show, so it hands those motions back and the ORIGINAL character appears for them. " +
                        "Even one standing frame in " + CcBuild.SpritesRoot + "/Default/ fixes it.");

                if (wroteSpritePath)
                    log("    \"spritePath\" was written alongside it (" + spritePathInFile + ") -- that is the " +
                        "transform path your drawings are keyed on, and it is what lets Limbonia hang them in the " +
                        "right place. Leave it alone unless you move the curves.");
                else if (spritePathInFile != null && spritePathInFile != bindingPath)
                    log("    NOTE: your " + FileName + " says \"spritePath\": \"" + spritePathInFile + "\" and " +
                        "this build keyed the drawings on \"" + bindingPath + "\". YOURS WAS KEPT. If the mod " +
                        "loads and the character does not change, these two disagreeing is the first suspect.");
            }

            if (coinDisagreements.Count > 0)
            {
                log("");
                log("  YOUR \"index\" DISAGREES WITH THE DRAWINGS (" + coinDisagreements.Count + "):");
                foreach (string c in coinDisagreements) log("    " + c);
            }
            WarnAboutCoinOrder(assets, log);
            if (effects != null && effects.Count > 0)
                log("  ...and the name/type of " + effects.Count + " effect prefab(s)" + (newEffects > 0
                        ? " (" + newEffects + " declared for the first time)" : "") +
                    ". WHERE each one plays is a \"vfx\" entry on the animation that plays it: the build owns " +
                    "the ones you placed on a timeline in Unity (they are marked \"from\": \"unity\") and never " +
                    "touches any other.");

            List<string> topLevel = JMerge.KeysOtherThan(doc, "name", "enabled", "audio", "motions");
            List<string> packRest = JMerge.KeysOtherThan(pack, "appearance", "bundle", "assets", "renderer",
                                                         "spritePath");

            if (keptOther.Count > 0 || keptMove.Count > 0 || topLevel.Count > 0 || packRest.Count > 0)
            {
                log("  KEPT EXACTLY AS YOU WROTE IT -- none of this was regenerated:");
                if (keptOther.Count > 0)
                    log("    on your animations:       " + JMerge.Sentence(keptOther));
                if (keptMove.Count > 0)
                    log("    your movement on:         " + string.Join(", ", keptMove.ToArray()));
                if (packRest.Count > 0)
                    log("    on this character's entry: " + JMerge.Sentence(packRest));
                if (topLevel.Count > 0)
                    log("    at the top of the file:   " + JMerge.Sentence(topLevel));
                log("    Hand edits are never regenerated. If you want the build's default movement back on a " +
                    "motion, delete that motion's \"move\" from " + FileName + " and build again.");
            }
            else if (hadFile)
                log("  KEPT EXACTLY AS YOU WROTE IT: nothing to keep -- there were no hand edits in this file yet.");

            if (JMerge.Has(doc, "enabled") && !doc["enabled"].AsBool(true))
                log("  NOTE: your " + FileName + " says \"enabled\": false, so the game will ignore this mod " +
                    "however well it built. That was left as you set it -- change it to true when you want it on.");

            if (orphans.Count > 0)
            {
                log("");
                log("  DECLARATIONS THIS BUILD DID NOT PRODUCE (" + orphans.Count + "), kept but INERT:");
                foreach (JVal a in orphans)
                {
                    List<string> content = JMerge.KeysOtherThan(a, "name", "type", "motion", "index");
                    log("    " + a["motion"].AsString("?") + " (" + CoinWords(IndexOf(a)) + ")  \"" +
                        a["name"].AsString("?") + "\"" +
                        (content.Count > 0 ? "  -- carries your " + JMerge.Sentence(content) : ""));
                }
                log("    This build did not produce the animations they name. NOTHING IN THEM WAS DELETED. Either");
                log("    put the drawings back and build again, or delete these entries from " + FileName +
                    " once you");
                log("    are sure you do not want them.");
                log("    ONE OF THESE CAN STILL PLAY, so it is worth checking rather than assuming they are inert:");
                log("    an animation an EARLIER build made is still in " + CcBuild.GeneratedRoot + " and still in");
                log("    the archive, so its declaration keeps working. That is how renaming a motion's drawings");
                log("    to per-coin ones can leave the old whole-skill animation covering the clashes you have");
                log("    not drawn yet. Delete the entry, or the file in " + CcBuild.GeneratedRoot + ", to be rid");
                log("    of it for certain.");
            }

            if (soundFiles != null && soundFiles.Count > 0)
                log("  " + soundFiles.Count + " sound file(s) in \"audio\", placed by \"cues\" -- times are seconds " +
                    "from the start of the motion, exactly as you placed them in the Timeline window.");
        }

        static void ReportArchives(string modDir, string bundleName, JVal doc, Action<string> log)
        {
            if (log == null) return;
            try
            {
                string dir = Path.Combine(modDir, BundleSubFolder);
                if (!Directory.Exists(dir)) return;

                var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                used.Add(bundleName + ".bundle");
                JVal motions = doc["motions"];
                if (motions != null && motions.IsArray)
                    foreach (JVal p in motions)
                    {
                        if (p == null || !p.IsObject) continue;
                        string rel = p["bundle"].AsString("");
                        if (rel.Length > 0) used.Add(Path.GetFileName(rel.Replace('\\', '/')));
                    }

                var spare = new List<string>();
                foreach (string f in Directory.GetFiles(dir, "*.bundle"))
                    if (!used.Contains(Path.GetFileName(f))) spare.Add(Path.GetFileName(f));

                if (spare.Count == 0) return;
                spare.Sort(StringComparer.Ordinal);

                log("");
                log("  ARCHIVES IN " + BundleSubFolder + "/ THAT NOTHING IN " + FileName + " POINTS AT (" +
                    spare.Count + "):");
                foreach (string s in spare) log("    " + s);
                log("    Left behind by an earlier build -- usually one made before this mod was pointed at a");
                log("    different character. They are never loaded and they are safe to delete. NOTHING HERE");
                log("    DELETED THEM, because an archive is the only copy of the animations inside it.");
            }
            catch { }
        }

        static JVal FindPack(JVal motions, string appearanceName, string bundleRel)
        {
            foreach (JVal p in motions)
            {
                if (p == null || !p.IsObject) continue;
                JVal app = p["appearance"];
                string s = app.Kind == JKind.String ? app.Str
                         : app.Kind == JKind.Number ? app.AsRawNumber() : null;
                if (s != null && s == appearanceName) return p;
            }
            foreach (JVal p in motions)
            {
                if (p == null || !p.IsObject) continue;
                if (JMerge.Has(p, "appearance") && !p["appearance"].IsNull) continue;
                if (p["bundle"].AsString("") == bundleRel) return p;
            }
            return null;
        }

        static JVal FindAsset(List<JVal> existing, HashSet<JVal> used, string assetName, string motion, int coin)
        {
            foreach (JVal a in existing)
                if (!used.Contains(a) && a["name"].AsString("") == assetName) return a;
            foreach (JVal a in existing)
                if (!used.Contains(a) && a["motion"].AsString("") == motion && IndexOf(a) == coin) return a;
            return null;
        }

        static int IndexOf(JVal a)
        {
            JVal i = a["index"];
            return i.Kind == JKind.Number ? i.AsInt(0) : 0;
        }

        static string CoinWords(int coin)
        {
            return coin < 0 ? "every coin" : "coin " + coin.ToString(CultureInfo.InvariantCulture);
        }

        static void WarnAboutCoinOrder(JVal assets, Action<string> log)
        {
            if (log == null || assets == null || !assets.IsArray) return;

            var specificSoFar = new Dictionary<string, List<int>>(StringComparer.Ordinal);
            foreach (JVal a in assets)
            {
                if (a == null || !a.IsObject) continue;
                if (a["type"].AsString("TimelineAsset") != "TimelineAsset") continue;
                string motion = a["motion"].AsString("");
                if (motion.Length == 0) continue;
                int coin = IndexOf(a);

                if (coin >= 0)
                {
                    List<int> seen;
                    if (!specificSoFar.TryGetValue(motion, out seen))
                    {
                        seen = new List<int>();
                        specificSoFar[motion] = seen;
                    }
                    if (!seen.Contains(coin)) seen.Add(coin);
                    continue;
                }

                List<int> shadowed;
                if (!specificSoFar.TryGetValue(motion, out shadowed) || shadowed.Count == 0) continue;

                var words = new List<string>();
                foreach (int c in shadowed) words.Add(CoinWords(c));
                log("");
                log("  WARNING: " + motion + " declares \"" + a["name"].AsString("?") + "\" for EVERY coin, and " +
                    "that entry comes AFTER your " + JMerge.Sentence(words) + " entry. In game the every-coin one " +
                    "is applied last and OVERWRITES it, so " + JMerge.Sentence(words) + " never plays.");
                log("           Open " + FileName + " and move the every-coin entry ABOVE the others for " +
                    motion + ". Then the every-coin one fills the skill and each specific coin replaces its own.");
                shadowed.Clear();
            }
        }

        static JVal FindAssetByName(List<JVal> existing, HashSet<JVal> used, string assetName)
        {
            foreach (JVal a in existing)
                if (!used.Contains(a) && a["name"].AsString("") == assetName) return a;
            return null;
        }

        static void WriteAudioSection(JVal doc, Dictionary<string, CcSoundFile> soundFiles, Action<string> log)
        {
            var ours = new Dictionary<string, CcSoundFile>(StringComparer.Ordinal);
            if (soundFiles != null)
                foreach (CcSoundFile sf in soundFiles.Values) ours[sf.Id] = sf;

            JVal existing = doc["audio"];
            var kept = new List<JVal>();
            if (existing != null && existing.IsArray)
                foreach (JVal a in existing)
                {
                    string id = a["id"].AsString("");
                    if (id.Length == 0 || !ours.ContainsKey(id)) kept.Add(a);
                }

            if (ours.Count == 0 && kept.Count == 0) return;

            var arr = JVal.NewArray();
            foreach (JVal a in kept) arr.Add(a);
            foreach (CcSoundFile sf in ours.Values)
            {
                var e = JVal.NewObject();
                e.Set("id", JVal.Of(sf.Id));
                e.Set("name", JVal.Of(sf.FileName));
                e.Set("file", JVal.Of(AudioSubFolder + "/" + sf.FileName));
                arr.Add(e);
            }
            doc.Set("audio", arr);

            if (log != null && ours.Count > 0)
            {
                log("");
                log("  \"audio\": " + ours.Count + " sound file(s) declared" +
                    (kept.Count > 0 ? ", plus " + kept.Count + " you had added by hand (kept)" : ""));
            }
        }

        static void MergeCues(JVal d, CcBuild.MotionBuild mb, CcBuildOptions o,
                              Dictionary<string, CcSoundFile> soundFiles, Action<string> log)
        {
            JVal mine = CuesFor(mb, o, soundFiles, log);
            JVal have = d["cues"];
            bool haveAny = have != null && have.IsArray && have.Count > 0;

            if (mine == null) return;
            if (!haveAny) { d.Set("cues", mine); return; }

            var ourClips = new HashSet<string>(StringComparer.Ordinal);
            foreach (JVal c in mine) ourClips.Add(c["clip"].AsString(""));

            var spare = new List<JVal>();
            var theirs = new List<JVal>();
            foreach (JVal c in have)
            {
                if (c == null || !c.IsObject) continue;
                if (ourClips.Contains(c["clip"].AsString(""))) spare.Add(c);
                else theirs.Add(c);
            }

            var merged = JVal.NewArray();
            foreach (JVal c in theirs) merged.Add(c);
            foreach (JVal c in mine)
            {
                string clip = c["clip"].AsString("");
                JVal reuse = null;
                for (int i = 0; i < spare.Count; i++)
                    if (spare[i]["clip"].AsString("") == clip) { reuse = spare[i]; spare.RemoveAt(i); break; }

                if (reuse == null) { merged.Add(c); continue; }
                reuse.Set("time", c["time"]);
                if (JMerge.Has(c, "volume")) reuse.Set("volume", c["volume"]);
                merged.Add(reuse);
            }
            d.Set("cues", merged);

            if (theirs.Count > 0 && log != null)
                log("  " + mb.Label + ": kept " + theirs.Count + " sound cue(s) you added by hand -- this build " +
                    "only rewrites the ones it placed from the Timeline window.");
            if (spare.Count > 0 && log != null)
            {
                log("  " + mb.Label + ": " + spare.Count + " old cue(s) were removed because that sound is no " +
                    "longer on the timeline. They would have played a second time on top of the new placement:");
                foreach (JVal c in spare)
                    log("      " + c["clip"].AsString("?") + " at " + c["time"].AsDouble(0).ToString("0.###") + "s");
                log("      They are in the dated backup beside " + FileName + " if you want them back.");
            }
        }

        static JVal CuesFor(CcBuild.MotionBuild mb, CcBuildOptions o, Dictionary<string, CcSoundFile> soundFiles,
                            Action<string> log)
        {
            if (mb.Audio == null || soundFiles == null) return null;

            var arr = JVal.NewArray();
            foreach (CcSound s in mb.Audio.Shippable)
            {
                CcSoundFile sf;
                if (string.IsNullOrEmpty(s.SourceFile) || !soundFiles.TryGetValue(s.SourceFile, out sf)) continue;

                var c = JVal.NewObject();
                c.Set("time", JVal.Of(Round(Math.Max(0.0, s.Time))));
                c.Set("clip", JVal.Of(CcBuild.Sanitize(o.ModName) + "/" + sf.Id));
                if (s.Volume < 0.999f) c.Set("volume", JVal.Of(Round(s.Volume)));
                arr.Add(c);

                if (log != null)
                    log("  " + mb.Label + ": sound '" + sf.FileName + "' at " +
                        Round(s.Time).ToString("0.###") + "s" +
                        (s.Volume < 0.999f ? " at " + Round(s.Volume).ToString("0.##") + " volume" : ""));
            }
            return arr.Count > 0 ? arr : null;
        }

        static void MergeVfx(JVal d, CcBuild.MotionBuild mb, string backup, Action<string> log)
        {
            CcMotionVfx mv = mb.Vfx;
            JVal have = d["vfx"];
            bool haveAny = have != null && have.IsArray && have.Count > 0;

            if (mv == null || !mv.TimelineRead)
            {
                if (log != null && haveAny && CountTagged(have) > 0)
                    log("  " + mb.Label + ": its timeline in " + CcBuild.GeneratedRoot + " could not be read, so " +
                        "the effects placed in Unity on it were left exactly as they are.");
                return;
            }

            var mine = new List<CcPlacement>();
            var sleeping = new List<string>();
            if (mv != null)
            {
                foreach (CcPlacement p in mv.Shippable) mine.Add(p);
                foreach (CcPlacement p in mv.Sleeping)
                    if (!string.IsNullOrEmpty(p.AssetName) && !sleeping.Contains(p.AssetName))
                        sleeping.Add(p.AssetName);
            }

            if (mine.Count == 0 && !haveAny) return;

            var order = new List<JVal>();
            var tagged = new List<JVal>();
            var untagged = new List<JVal>();
            if (haveAny)
                foreach (JVal v in have)
                {
                    if (v == null || !v.IsObject) continue;
                    order.Add(v);
                    if (v["from"].AsString("") == "unity") tagged.Add(v); else untagged.Add(v);
                }

            if (mine.Count == 0 && tagged.Count == 0)
            {
                if (log != null && untagged.Count > 0)
                    log("  " + mb.Label + ": kept " + untagged.Count + " effect(s) you placed yourself -- this " +
                        "build only rewrites the ones it placed from the Timeline window.");
                return;
            }

            bool fractions;
            double total;
            ReadTimeUnits(d, out fractions, out total);

            var claimed = new HashSet<JVal>();
            var added = new List<JVal>();
            var changes = new List<string>();
            int adopted = 0, ambiguous = 0;

            foreach (CcPlacement p in mine)
            {
                JVal target = FirstUnclaimed(tagged, claimed, p.AssetName);
                bool fresh = false;
                bool justAdopted = false;

                if (target == null)
                {
                    var candidates = new List<JVal>();
                    foreach (JVal v in untagged)
                        if (!claimed.Contains(v) && v["asset"].AsString("") == p.AssetName) candidates.Add(v);

                    if (candidates.Count == 1) { target = candidates[0]; adopted++; justAdopted = true; }
                    else if (candidates.Count > 1)
                    {
                        ambiguous++;
                        if (log != null)
                        {
                            log("  " + mb.Label + ": '" + p.AssetName + "' is on the timeline, but " +
                                mb.Label + " already has " + candidates.Count + " effect(s) with that name " +
                                "that this build did not place:");
                            foreach (JVal c in candidates)
                                log("      at " + c["time"].AsDouble(0).ToString("0.###") + "s for " +
                                    c["duration"].AsDouble(0).ToString("0.###") + "s");
                            log("      NOTHING WAS CHANGED and nothing was added -- adding one would play the " +
                                "effect a third time. Delete the one you do not want from " + FileName +
                                " (or in the companion) and build again, and the timeline will own the other.");
                        }
                        continue;
                    }
                }

                if (target == null) { target = JVal.NewObject(); added.Add(target); fresh = true; }

                claimed.Add(target);
                WritePlacement(target, p, fractions, total, mb.Label, fresh, justAdopted, changes);
            }

            var orphans = new List<JVal>();
            foreach (JVal v in tagged)
            {
                if (claimed.Contains(v)) continue;
                if (sleeping.Contains(v["asset"].AsString(""))) { claimed.Add(v); continue; }
                orphans.Add(v);
            }

            var merged = JVal.NewArray();
            foreach (JVal v in order) if (!orphans.Contains(v)) merged.Add(v);
            foreach (JVal v in added) merged.Add(v);
            if (merged.Count > 0) d.Set("vfx", merged);
            else if (JMerge.Has(d, "vfx")) d.Set("vfx", merged);

            if (log == null) return;

            foreach (string c in changes) log(c);
            if (adopted > 0)
                log("  " + mb.Label + ": " + adopted + " effect(s) you had already declared were matched to the " +
                    "prefab on the timeline and are now owned by it -- they are marked \"from\": \"unity\" and a " +
                    "build will move them. Nothing was duplicated.");
            int kept = untagged.Count - adopted;
            if (kept > 0)
                log("  " + mb.Label + ": kept " + kept + " effect(s) you placed yourself -- this build only " +
                    "rewrites the ones it placed from the Timeline window.");
            if (orphans.Count > 0)
            {
                log("  " + mb.Label + ": " + orphans.Count + " effect(s) were removed because that prefab is no " +
                    "longer on the timeline. They would have played on top of nothing:");
                foreach (JVal v in orphans)
                    log("      " + v["asset"].AsString("?") + " at " + v["time"].AsDouble(0).ToString("0.###") +
                        "s");
                log("      They are in " + (backup != null ? Path.GetFileName(backup) : "the dated backup beside " +
                    FileName) + " if you want them back.");
            }
            if (ambiguous > 0)
                log("  " + mb.Label + ": " + ambiguous + " placement(s) could not be written -- see above.");
        }

        static int CountTagged(JVal list)
        {
            int n = 0;
            foreach (JVal v in list) if (v != null && v.IsObject && v["from"].AsString("") == "unity") n++;
            return n;
        }

        static JVal FirstUnclaimed(List<JVal> pool, HashSet<JVal> claimed, string assetName)
        {
            foreach (JVal v in pool)
                if (!claimed.Contains(v) && v["asset"].AsString("") == assetName) return v;
            return null;
        }

        static void ReadTimeUnits(JVal d, out bool fractions, out double total)
        {
            fractions = false;
            total = 0.0;
            JVal td = d["totalDuration"];
            if (td.Kind != JKind.Number) return;
            double t = td.Number;
            if (double.IsNaN(t) || double.IsInfinity(t) || t < 0.05) return;
            string u = d["times"].AsString(null);
            if (u == "fraction" || u == "fractions") { fractions = true; total = t; }
        }

        static void WritePlacement(JVal e, CcPlacement p, bool fractions, double total, string motion,
                                   bool fresh, bool adopted, List<string> changes)
        {
            double time = fractions ? p.Time / total : p.Time;
            double length = fractions ? p.Length / total : p.Length;

            var moved = new List<string>();
            Note(moved, e, "asset", JVal.Of(p.AssetName), null);
            Note(moved, e, "time", JVal.Of(Round(time)), fractions ? "" : "s");
            Note(moved, e, "duration", JVal.Of(Round(length)), fractions ? "" : "s");
            Note(moved, e, "x", JVal.Of(Round(p.Position.x)), null);
            Note(moved, e, "y", JVal.Of(Round(p.Position.y)), null);
            Note(moved, e, "z", JVal.Of(Round(p.Position.z)), null);
            e.Set("from", JVal.Of("unity"));

            string where = p.AssetName + " at " + Round(time).ToString("0.###") + (fractions ? "" : "s") +
                           " for " + Round(length).ToString("0.###") + (fractions ? "" : "s");
            if (fresh)
                changes.Add("  " + motion + ": effect " + where + "  (placed in Unity, declared for the first time)");
            else if (adopted)
                changes.Add("  " + motion + ": effect " + where + "  (the entry you already had, now placed from " +
                            "the timeline" + (moved.Count > 0 ? " -- " + JMerge.Sentence(moved) : "") + ")");
            else if (moved.Count > 0)
                changes.Add("  " + motion + ": effect " + where + "  -- " + JMerge.Sentence(moved));
            else
                changes.Add("  " + motion + ": effect " + where + "  (unchanged)");

            if (JMerge.Has(e, "effect") || JMerge.Has(e, "index"))
                changes.Add("  " + motion + ": WARNING -- that entry also names one of the character's own " +
                            "effects (\"effect\" / \"index\"). Limbonia refuses an entry that says both and " +
                            "skips it. Delete the \"effect\" and \"index\" from it in " + FileName + ".");
        }

        static void Note(List<string> into, JVal e, string key, JVal value, string unit)
        {
            JVal old = e[key];
            bool same = old.Kind == value.Kind &&
                        (value.Kind == JKind.String ? old.Str == value.Str
                                                    : Math.Abs(old.Number - value.Number) < 0.00005);
            if (!same && JMerge.Has(e, key))
            {
                string was = old.Kind == JKind.String ? "'" + old.Str + "'"
                           : old.Kind == JKind.Number ? old.Number.ToString("0.###") + (unit ?? "")
                           : "nothing";
                into.Add(key + " was " + was);
            }
            e.Set(key, value);
        }

        static JVal MoveFor(CcBuild.MotionBuild mb, CcBuildOptions o, Action<string> log)
        {
            if (!o.StepTowardsTarget || !SkillMotions.Contains(mb.Motion)) return null;

            double approachAt = Math.Max(0.0, mb.Duration * 0.10);
            double returnAt = Math.Max(approachAt + 0.05, mb.Duration * 0.80);
            double span = Math.Min(0.15, Math.Max(0.05, mb.Duration * 0.18));

            var approach = JVal.NewObject();
            approach.Set("mode", JVal.Of("toTargetWide"));
            approach.Set("time", JVal.Of(Round(approachAt)));
            approach.Set("duration", JVal.Of(Round(span)));
            approach.Set("arriveRadius", JVal.Of(0));
            approach.Set("includeTargetRadius", JVal.Of(false));
            approach.Set("includeAttackerRadius", JVal.Of(false));
            approach.Set("chaseY", JVal.Of(false));
            approach.Set("refreshDir", JVal.Of(true));
            approach.Set("ease", JVal.Of(6));
            approach.Set("x", JVal.Of(1.25));
            approach.Set("y", JVal.Of(0));
            approach.Set("z", JVal.Of(0));
            approach.Set("overrideTarget", JVal.Of(-1));

            var back = JVal.NewObject();
            back.Set("mode", JVal.Of("relative"));
            back.Set("time", JVal.Of(Round(returnAt)));
            back.Set("duration", JVal.Of(Round(span)));
            back.Set("x", JVal.Of(-1));
            back.Set("y", JVal.Of(0));
            back.Set("z", JVal.Of(0));
            back.Set("refreshDir", JVal.Of(true));
            back.Set("ease", JVal.Of(1));
            back.Set("yWorldZero", JVal.Of(false));

            var arr = JVal.NewArray();
            arr.Add(approach);
            arr.Add(back);
            log("  " + mb.Label + ": movement -- steps towards the target at " +
                Round(approachAt).ToString("0.###") + "s, steps back at " + Round(returnAt).ToString("0.###") +
                "s. Without this the character would animate on the spot and never reach its target.");
            return arr;
        }

        static double Round(double d) { return Math.Round(d, 4); }
    }
}
