using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public class TargetMotion
    {
        public string Motion;
        public int Detail;
        public int Coins;
        public bool Spine;
    }

    public class Target
    {
        public string Name;
        public int Id;
        public string BindingPath;
        public string BindingPathAlt;
        public List<TargetMotion> Motions = new List<TargetMotion>();

        public TargetMotion Find(string motion)
        {
            foreach (TargetMotion m in Motions)
                if (string.Equals(m.Motion, motion, StringComparison.Ordinal)) return m;
            return null;
        }

        public string CoinNote(string motion)
        {
            TargetMotion m = Find(motion);
            if (m == null)
                return "this character has no " + motion + " at all, so it cannot be replaced";
            if (m.Coins <= 0)
                return "no animation of its own (a still pose) -- Limbonia has to ADD one; see the README";
            if (m.Coins == 1)
                return "1 coin";
            return m.Coins + " coins -- your animation plays on all " + m.Coins +
                   " (they are separate attacks in one skill). For a different animation per clash, put each " +
                   "clash's drawings in its own numbered folder: " + motion + "/0/, " + motion + "/1/ ...";
        }
    }

    public static class CcTargets
    {
        public const string CatalogPath = "Assets/Editor/limbus-targets.json";

        public const string StandardBindingPath =
            "[Transform,Fixed]ScaleAndPositionPivot/[Transform]PivotForAnim/[SpRenderer]";

        static List<Target> s_all;
        static string s_loadError;

        public static string LoadError { get { Load(); return s_loadError; } }

        public static List<Target> All
        {
            get { Load(); return s_all; }
        }

        public static void Reload() { s_all = null; s_loadError = null; s_motionNames = null; }

        static void Load()
        {
            if (s_all != null) return;
            s_all = new List<Target>();
            try
            {
                string abs = Path.GetFullPath(CatalogPath);
                if (!File.Exists(abs))
                {
                    s_loadError = CatalogPath + " is missing, so the character list is empty. You can still " +
                                  "type an appearance name by hand. To rebuild it: python tools/build_target_catalog.py";
                    return;
                }

                JVal doc = MiniJson.Parse(File.ReadAllText(abs));
                foreach (JVal a in doc["appearances"])
                {
                    string name = a["name"].AsString(null);
                    if (string.IsNullOrEmpty(name)) continue;
                    var t = new Target
                    {
                        Name = name,
                        Id = a["id"].AsInt(0),
                        BindingPath = a["bindingPath"].AsString(null),
                        BindingPathAlt = a["bindingPathAlt"].AsString(null),
                    };
                    foreach (JVal m in a["motions"])
                        t.Motions.Add(new TargetMotion
                        {
                            Motion = m["motion"].AsString(""),
                            Detail = m["detail"].AsInt(-1),
                            Coins = m["coins"].AsInt(0),
                            Spine = m["spine"].AsBool(false),
                        });
                    s_all.Add(t);
                }
                s_all.Sort((x, y) => x.Id.CompareTo(y.Id));
            }
            catch (Exception e)
            {
                s_loadError = CatalogPath + " could not be read (" + e.GetType().Name + ": " + e.Message +
                              "). Type an appearance name by hand, or rebuild the catalog with " +
                              "python tools/build_target_catalog.py";
                Debug.LogWarning("[CustomCharacter] " + s_loadError);
            }
        }

        public static List<string> AllMotionNames
        {
            get
            {
                if (s_motionNames != null) return s_motionNames;
                var seen = new List<string>();
                var set = new HashSet<string>(StringComparer.Ordinal);
                foreach (Target t in All)
                    foreach (TargetMotion m in t.Motions)
                        if (!string.IsNullOrEmpty(m.Motion) && set.Add(m.Motion)) seen.Add(m.Motion);
                seen.Sort(StringComparer.Ordinal);
                s_motionNames = seen;
                return s_motionNames;
            }
        }

        static List<string> s_motionNames;

        public static bool IsKnownMotion(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            foreach (string m in AllMotionNames)
                if (string.Equals(m, name, StringComparison.Ordinal)) return true;
            return false;
        }

        public static Target ByName(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            foreach (Target t in All)
                if (string.Equals(t.Name, name, StringComparison.Ordinal)) return t;
            return null;
        }

        public static string[] MenuLabels()
        {
            var labels = new List<string>();
            foreach (Target t in All)
            {
                int sinner = (t.Id / 100) % 100;
                labels.Add(SinnerName(sinner) + "/" + t.Name);
            }
            return labels.ToArray();
        }

        static readonly string[] SinnerNames =
        {
            "?", "01 Yi Sang", "02 Faust", "03 Don Quixote", "04 Ryoshu", "05 Meursault",
            "06 Hong Lu", "07 Heathcliff", "08 Ishmael", "09 Rodion", "10 Sinclair",
            "11 Outis", "12 Gregor",
        };

        static string SinnerName(int sinner)
        {
            return (sinner >= 0 && sinner < SinnerNames.Length) ? SinnerNames[sinner] : "other";
        }
    }
}
