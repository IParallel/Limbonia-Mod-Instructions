using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public class CcExtraCurves
    {
        public string Motion;
        public double AuthoredAgainst;

        public readonly List<KeyValuePair<EditorCurveBinding, AnimationCurve>> Floats =
            new List<KeyValuePair<EditorCurveBinding, AnimationCurve>>();
        public readonly List<KeyValuePair<EditorCurveBinding, ObjectReferenceKeyframe[]>> Objects =
            new List<KeyValuePair<EditorCurveBinding, ObjectReferenceKeyframe[]>>();

        public int Count { get { return Floats.Count + Objects.Count; } }
        public bool Any { get { return Count > 0; } }

        public string Describe()
        {
            var counts = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var f in Floats)
            {
                string p = f.Key.propertyName ?? "";
                string family = p.StartsWith("m_LocalPosition") ? "position"
                              : p.StartsWith("m_LocalRotation") || p.StartsWith("localEuler") ? "rotation"
                              : p.StartsWith("m_LocalScale") ? "scale"
                              : p.StartsWith("m_Color") ? "colour"
                              : p;
                counts[family] = counts.TryGetValue(family, out int n) ? n + 1 : 1;
            }
            if (Objects.Count > 0) counts["extra sprite curve"] = Objects.Count;

            var parts = new List<string>();
            foreach (var kv in counts) parts.Add(kv.Key + " (" + kv.Value + ")");
            return parts.Count == 0 ? "none" : string.Join(", ", parts.ToArray());
        }
    }

    public static class CcEdits
    {
        public const string KeepFile = "Assets/CustomCharacter/hand-edited.json";

        public static HashSet<string> LoadKeep()
        {
            var keep = new HashSet<string>(StringComparer.Ordinal);
            try
            {
                string abs = Path.GetFullPath(KeepFile);
                if (!File.Exists(abs)) return keep;
                JVal doc = MiniJson.Parse(File.ReadAllText(abs));
                JVal list = doc["keep"];
                if (list != null && list.IsArray)
                    foreach (JVal v in list)
                    {
                        string s = v.AsString("");
                        if (s.Length > 0) keep.Add(s);
                    }
            }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] " + KeepFile + " could not be read (" + e.Message +
                                 "), so no motion is treated as hand-edited. Fix or delete the file.");
            }
            return keep;
        }

        public static void SaveKeep(IEnumerable<string> motions)
        {
            try
            {
                var arr = JVal.NewArray();
                foreach (string m in motions) arr.Add(JVal.Of(m));
                var doc = JVal.NewObject();
                doc.Set("_comment", JVal.Of("Motions listed here are NEVER regenerated from the sprite " +
                                            "folders. Their .anim and .playable in _Generated/ are shipped " +
                                            "exactly as they are, so hand-authored curves and retimed keys " +
                                            "survive a build. Tick 'keep my edits' in the Custom Character " +
                                            "window to change this."));
                doc.Set("keep", arr);
                string abs = Path.GetFullPath(KeepFile);
                Directory.CreateDirectory(Path.GetDirectoryName(abs));
                File.WriteAllText(abs, MiniJson.Write(doc));
                AssetDatabase.ImportAsset(KeepFile);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] could not write " + KeepFile + " (" + e.Message +
                                 "). Your 'keep my edits' ticks will not survive a restart.");
            }
        }

        public static CcExtraCurves Capture(string motion, string clipPath, string generatedPath)
        {
            var r = new CcExtraCurves { Motion = motion };
            try
            {
                var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);
                if (clip == null) return r;

                foreach (EditorCurveBinding b in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    ObjectReferenceKeyframe[] k = AnimationUtility.GetObjectReferenceCurve(clip, b);
                    if (k != null && k.Length > 0)
                        r.AuthoredAgainst = Math.Max(r.AuthoredAgainst, k[k.Length - 1].time);
                }
                if (r.AuthoredAgainst <= 0.0) r.AuthoredAgainst = clip.length;

                foreach (EditorCurveBinding b in AnimationUtility.GetCurveBindings(clip))
                {
                    AnimationCurve c = AnimationUtility.GetEditorCurve(clip, b);
                    if (c != null) r.Floats.Add(new KeyValuePair<EditorCurveBinding, AnimationCurve>(b, c));
                }

                foreach (EditorCurveBinding b in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    if (b.path == generatedPath && b.propertyName == "m_Sprite") continue;
                    ObjectReferenceKeyframe[] k = AnimationUtility.GetObjectReferenceCurve(clip, b);
                    if (k != null && k.Length > 0)
                        r.Objects.Add(new KeyValuePair<EditorCurveBinding, ObjectReferenceKeyframe[]>(b, k));
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] could not read the hand-authored curves on " + clipPath +
                                 ": " + e.Message);
            }
            return r;
        }

        public static void Reapply(AnimationClip clip, CcExtraCurves extra, double newDuration,
                                   Action<string> log, Action<string> warn)
        {
            if (clip == null || extra == null || !extra.Any) return;

            foreach (var f in extra.Floats) AnimationUtility.SetEditorCurve(clip, f.Key, f.Value);
            foreach (var oc in extra.Objects) AnimationUtility.SetObjectReferenceCurve(clip, oc.Key, oc.Value);

            if (log != null)
                log("  kept your hand-authored curves: " + extra.Describe() +
                    " -- redrawing frames does not lose them.");

            if (warn != null && extra.AuthoredAgainst > 0.0001 &&
                Math.Abs(extra.AuthoredAgainst - newDuration) > 0.0011)
            {
                double covered = newDuration > 0 ? (extra.AuthoredAgainst / newDuration) * 100.0 : 0.0;
                warn("  " + extra.Motion + ": your hand-authored curves were made for a " +
                     extra.AuthoredAgainst.ToString("0.###", CultureInfo.InvariantCulture) +
                     "s animation and this one is now " +
                     newDuration.ToString("0.###", CultureInfo.InvariantCulture) + "s. They are kept EXACTLY " +
                     "as you made them -- nothing was stretched or thrown away -- but they now cover about " +
                     covered.ToString("0") + "% of it. Open the Animation window and check them, or tick " +
                     "\"keep my edits\" for " + extra.Motion + " so the build stops regenerating it.");
            }
        }
    }
}
