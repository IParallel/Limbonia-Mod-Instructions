using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public static class CcBatch
    {
        public static void Build()
        {
            var o = new CcBuildOptions
            {
                AppearanceName = Arg("-ccAppearance", ""),
                ModName = Arg("-ccName", "MyCharacter"),
                ModsFolder = Arg("-ccMods", ""),
                Fps = Num("-ccFps", 12f),
                Ppu = Num("-ccPpu", 100f),
                StepTowardsTarget = !Flag("-ccNoMove"),
                BindingPathOverride = Arg("-ccBinding", ""),
                Renderer = Flag("-ccSlotRenderer") ? CcManifest.RendererSlot : CcManifest.RendererSidecar,
                OpenPreview = Flag("-ccPreview"),
                Mode = Flag("-ccNoGenerate") ? CcBuildMode.UseExisting : CcBuildMode.Regenerate,
            };

            string keep = Arg("-ccKeep", null);
            if (keep != null)
            {
                o.KeepMotions = new HashSet<string>(StringComparer.Ordinal);
                foreach (string m in keep.Split(','))
                    if (m.Trim().Length > 0) o.KeepMotions.Add(m.Trim());
            }

            string pivot = Arg("-ccPivot", "0.5,0");
            string[] parts = pivot.Split(',');
            if (parts.Length == 2)
            {
                float x, y;
                if (float.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out x)) o.PivotX = x;
                if (float.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out y)) o.PivotY = y;
            }

            Debug.Log("[CustomCharacter] batch build: mode=" + o.Mode +
                      " keep=" + (o.KeepMotions == null ? "(from hand-edited.json)"
                                                        : string.Join(",", new List<string>(o.KeepMotions).ToArray())) +
                      " appearance='" + o.AppearanceName + "' mod='" + o.ModName +
                      "' mods='" + o.ModsFolder + "' fps=" + o.Fps + " ppu=" + o.Ppu +
                      " pivot=" + o.PivotX + "," + o.PivotY + " move=" + o.StepTowardsTarget +
                      " renderer=" + o.Renderer + " preview=" + o.OpenPreview);

            CcBuild.Run(o);

            if (CcBuild.HadErrors)
            {
                Debug.LogError("[CustomCharacter] batch build FAILED -- see the log above.");
                if (Application.isBatchMode) EditorApplication.Exit(1);
            }
            else if (Application.isBatchMode)
            {
                EditorApplication.Exit(0);
            }
        }

        static string Arg(string name, string fallback)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            return fallback;
        }

        static bool Flag(string name)
        {
            foreach (string a in Environment.GetCommandLineArgs())
                if (string.Equals(a, name, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        static float Num(string name, float fallback)
        {
            float v;
            if (float.TryParse(Arg(name, ""), NumberStyles.Float, CultureInfo.InvariantCulture, out v) && v > 0f)
                return v;
            return fallback;
        }
    }
}
