using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Limbonia.CustomCharacter
{
    public class CcWindow : EditorWindow
    {
        const string PrefAppearance = "Limbonia.CustomCharacter.Appearance";
        const string PrefModName = "Limbonia.CustomCharacter.ModName";
        const string PrefModsFolder = "Limbonia.CustomCharacter.ModsFolder";
        const string PrefFps = "Limbonia.CustomCharacter.Fps";
        const string PrefPpu = "Limbonia.CustomCharacter.Ppu";
        const string PrefPivotX = "Limbonia.CustomCharacter.PivotX";
        const string PrefPivotY = "Limbonia.CustomCharacter.PivotY";
        const string PrefMove = "Limbonia.CustomCharacter.Move";
        const string PrefBinding = "Limbonia.CustomCharacter.Binding";
        const string PrefSidecar = "Limbonia.CustomCharacter.Sidecar";

        string m_appearance = "";
        string m_modName = "MyCharacter";
        string m_modsFolder = "";
        float m_fps = 12f;
        float m_ppu = 100f;
        float m_pivotX = 0.5f;
        float m_pivotY = 0f;
        bool m_move = true;
        string m_binding = "";

        bool m_sidecar = true;

        bool m_advanced;
        Vector2 m_scroll;
        bool m_running;
        string[] m_labels;
        static GUIStyle s_bigButton;

        HashSet<string> m_keep = new HashSet<string>(StringComparer.Ordinal);

        [MenuItem("Window/Limbonia/Custom Character")]
        public static void ShowWindow()
        {
            var w = GetWindow<CcWindow>(false, "Custom Character", true);
            w.minSize = new Vector2(460f, 420f);
            w.Show();
        }

        void OnEnable()
        {
            m_appearance = EditorPrefs.GetString(PrefAppearance, "");
            m_modName = EditorPrefs.GetString(PrefModName, "MyCharacter");
            m_modsFolder = EditorPrefs.GetString(PrefModsFolder, GuessModsFolder());
            m_fps = EditorPrefs.GetFloat(PrefFps, 12f);
            m_ppu = EditorPrefs.GetFloat(PrefPpu, 100f);
            m_pivotX = EditorPrefs.GetFloat(PrefPivotX, 0.5f);
            m_pivotY = EditorPrefs.GetFloat(PrefPivotY, 0f);
            m_move = EditorPrefs.GetBool(PrefMove, true);
            m_binding = EditorPrefs.GetString(PrefBinding, "");
            m_sidecar = EditorPrefs.GetBool(PrefSidecar, true);
            m_keep = CcEdits.LoadKeep();
        }

        void Save()
        {
            EditorPrefs.SetString(PrefAppearance, m_appearance ?? "");
            EditorPrefs.SetString(PrefModName, m_modName ?? "");
            EditorPrefs.SetString(PrefModsFolder, m_modsFolder ?? "");
            EditorPrefs.SetFloat(PrefFps, m_fps);
            EditorPrefs.SetFloat(PrefPpu, m_ppu);
            EditorPrefs.SetFloat(PrefPivotX, m_pivotX);
            EditorPrefs.SetFloat(PrefPivotY, m_pivotY);
            EditorPrefs.SetBool(PrefMove, m_move);
            EditorPrefs.SetString(PrefBinding, m_binding ?? "");
            EditorPrefs.SetBool(PrefSidecar, m_sidecar);
        }

        void OnGUI()
        {
            using (var scroll = new EditorGUILayout.ScrollViewScope(m_scroll))
            {
                m_scroll = scroll.scrollPosition;
                using (new EditorGUI.DisabledScope(m_running))
                {
                    DrawBody();
                }
                if (m_running)
                    EditorGUILayout.HelpBox("Building...  watch the Console.", MessageType.Info);
            }
        }

        void DrawBody()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("1.  Put your drawings in the folders", EditorStyles.boldLabel);
            DrawFrameCounts();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("2.  Choose who this replaces", EditorStyles.boldLabel);
            DrawTargetPicker();
            DrawScaffoldButton();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("3.  Where it goes", EditorStyles.boldLabel);
            m_modName = EditorGUILayout.TextField("Mod name", m_modName);
            using (new EditorGUILayout.HorizontalScope())
            {
                m_modsFolder = EditorGUILayout.TextField("Mods folder", m_modsFolder);
                if (GUILayout.Button("Browse", GUILayout.Width(70f)))
                {
                    string picked = EditorUtility.OpenFolderPanel(
                        "The Mods folder next to LimbusCompany.exe", m_modsFolder ?? "", "");
                    if (!string.IsNullOrEmpty(picked)) { m_modsFolder = picked; Save(); GUIUtility.ExitGUI(); }
                }
            }
            EditorGUILayout.LabelField(" ", "the \"Mods\" folder beside LimbusCompany.exe", EditorStyles.miniLabel);

            EditorGUILayout.Space();
            DrawAdvanced();

            EditorGUILayout.Space();
            DrawBuildButton();

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Open the drawings folder"))
                    Defer(() => EditorUtility.RevealInFinder(Path.GetFullPath(CcBuild.SpritesRoot) +
                                                             Path.DirectorySeparatorChar));
                if (GUILayout.Button("Open the sounds folder"))
                    Defer(() =>
                    {
                        CcAudio.EnsureSoundsFolder(s => Debug.Log("[CustomCharacter] " + s));
                        EditorUtility.RevealInFinder(Path.GetFullPath(CcAudio.SoundsRoot) +
                                                     Path.DirectorySeparatorChar);
                    });
                if (GUILayout.Button("Open the effects folder"))
                    Defer(() =>
                    {
                        CcEffects.EnsureFolder(s => Debug.Log("[CustomCharacter] " + s));
                        EditorUtility.RevealInFinder(Path.GetFullPath(CcEffects.EffectsRoot) +
                                                     Path.DirectorySeparatorChar);
                    });
                if (GUILayout.Button("Open the preview scene"))
                    Defer(() =>
                    {
                        if (!CcPreview.Open())
                            Debug.LogWarning("[CustomCharacter] there is no preview scene yet -- build once first.");
                    });
                if (GUILayout.Button("Open the build report"))
                    Defer(() =>
                    {
                        string p = Path.GetFullPath(CcBuild.GeneratedRoot + "/BUILD-REPORT.txt");
                        if (File.Exists(p)) EditorUtility.RevealInFinder(p);
                        else Debug.LogWarning("[CustomCharacter] there is no build report yet -- build once first.");
                    });
            }
        }

        void DrawFrameCounts()
        {
            Target t = CcTargets.ByName(m_appearance);
            using (new EditorGUI.IndentLevelScope())
            {
                foreach (string motion in CcBuild.MotionsToBuild())
                {
                    int n = CountFrames(motion);
                    bool kept = m_keep.Contains(motion);
                    bool placeholder = ShowsAsPlaceholder(motion);
                    string coinsDrawn = CoinsIn(motion);
                    string right = kept
                        ? "KEPT -- not regenerated, ships as built"
                        : placeholder
                            ? (n == 0 ? "PLACEHOLDER -- folder made for you, nothing in it yet"
                                      : "PLACEHOLDER -- a copy of your standing pose, not drawn yet")
                            : n == 0
                                ? "(empty -- this motion keeps the original)"
                                : n + " frame(s)" + (coinsDrawn != null ? "  as " + coinsDrawn
                                                     : t != null ? "   ->  " + t.CoinNote(motion) : "");

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField(motion, right);
                        bool now = GUILayout.Toggle(kept, new GUIContent(" keep my edits",
                            "Never regenerate " + motion + " from its drawings. Its animation and timeline in " +
                            CcBuild.GeneratedRoot + " ship exactly as they are, so curves you keyed by hand and " +
                            "keys you retimed survive every build."), GUILayout.Width(110f));
                        if (now != kept)
                        {
                            if (now) m_keep.Add(motion); else m_keep.Remove(motion);
                            CcEdits.SaveKeep(m_keep);
                        }
                    }
                }
            }
            EditorGUILayout.LabelField(" ", CcBuild.SpritesRoot + "/<motion>/01.png, 02.png, ...",
                                       EditorStyles.miniLabel);
            EditorGUILayout.LabelField(" ", "one animation per CLASH (optional): give each clash its own numbered " +
                                       "folder inside the motion -- S1/0/1.png, 2.png ... for the first clash, " +
                                       "S1/1/1.png, 2.png ... for the second, and so on from 0.",
                                       EditorStyles.miniLabel);
            EditorGUILayout.LabelField(" ", "How many numbered folders you make is how many clashes you have " +
                                       "drawn. A clash you do not draw keeps the original character's animation. " +
                                       "Any skill the character has works the same way, including S7 and above.",
                                       EditorStyles.miniLabel);

            int soundFiles = CountSoundFiles();
            EditorGUILayout.LabelField(" ", soundFiles == 0
                ? "sound: put .wav or .ogg files in " + CcAudio.SoundsRoot + ", then drag them onto a motion's " +
                  "timeline in the preview scene"
                : "sound: " + soundFiles + " file(s) in " + CcAudio.SoundsRoot + " -- drag them onto a motion's " +
                  "timeline in the preview scene",
                EditorStyles.miniLabel);

            int effectPrefabs = CountEffectPrefabs();
            int placed = CountPlacements();
            EditorGUILayout.LabelField(" ", effectPrefabs == 0
                ? "effects: put script-free prefabs in " + CcEffects.EffectsRoot + " to ship effects of your own, " +
                  "then drag one onto a motion's timeline in the preview scene"
                : "effects: " + effectPrefabs + " prefab(s) in " + CcEffects.EffectsRoot + " -- " + (placed > 0
                    ? placed + " placed on a timeline in the preview scene"
                    : "drag one onto a motion's timeline in the preview scene to place it"),
                EditorStyles.miniLabel);

            if (CountFrames("Default") == 0 && CcBuild.MotionsToBuild().Any(m => CountFrames(m) > 0))
                EditorGUILayout.HelpBox(
                    "Default has no drawings. That is allowed, but it is the one to fix first: Default is the " +
                    "neutral standing pose the character returns to after every action, so without it the " +
                    "ORIGINAL character flashes through each time -- after a skill, after a hit, and on the way " +
                    "into Idle. Even a single standing frame in Sprites/Default/ removes it.",
                    MessageType.Warning);
        }

        static int CountSoundFiles()
        {
            try
            {
                string abs = Path.GetFullPath(CcAudio.SoundsRoot);
                if (!Directory.Exists(abs)) return 0;
                int n = 0;
                foreach (string f in Directory.GetFiles(abs))
                {
                    string ext = Path.GetExtension(f).ToLowerInvariant();
                    if (Array.IndexOf(CcAudio.PlayableExtensions, ext) >= 0) n++;
                }
                return n;
            }
            catch { return 0; }
        }

        static int CountEffectPrefabs()
        {
            try
            {
                string abs = Path.GetFullPath(CcEffects.EffectsRoot);
                if (!Directory.Exists(abs)) return 0;
                return Directory.GetFiles(abs, "*.prefab", SearchOption.AllDirectories).Length;
            }
            catch { return 0; }
        }

        static int s_placements;
        static double s_placementsAt = -100.0;

        static int CountPlacements()
        {
            double now = EditorApplication.timeSinceStartup;
            if (now - s_placementsAt < 1.5) return s_placements;
            s_placementsAt = now;
            s_placements = 0;
            try
            {
                string abs = Path.GetFullPath(CcBuild.GeneratedRoot);
                if (!Directory.Exists(abs)) return 0;
                foreach (string f in Directory.GetFiles(abs, "*.playable"))
                {
                    string text;
                    try { text = File.ReadAllText(f); }
                    catch (IOException) { continue; }
                    if (!text.StartsWith("%YAML")) continue;
                    int at = 0;
                    while ((at = text.IndexOf("UnityEngine.Timeline.ControlPlayableAsset", at,
                                              StringComparison.Ordinal)) >= 0)
                    {
                        s_placements++;
                        at += 1;
                    }
                }
            }
            catch { s_placements = 0; }
            return s_placements;
        }

        static bool AnythingGenerated()
        {
            try
            {
                string abs = Path.GetFullPath(CcBuild.GeneratedRoot);
                return Directory.Exists(abs) && Directory.GetFiles(abs, "*.playable").Length > 0;
            }
            catch { return false; }
        }

        static readonly Dictionary<string, CcBuild.MotionDrawings> s_drawings =
            new Dictionary<string, CcBuild.MotionDrawings>(StringComparer.Ordinal);
        static double s_drawingsAt = -1.0;

        static CcBuild.MotionDrawings Drawings(string motion)
        {
            double now = EditorApplication.timeSinceStartup;
            if (s_drawingsAt < 0.0 || now - s_drawingsAt > 1.0)
            {
                s_drawingsAt = now;
                s_drawings.Clear();
            }
            CcBuild.MotionDrawings d;
            if (s_drawings.TryGetValue(motion, out d)) return d;
            try { d = CcBuild.DrawingsIn(motion); }
            catch { d = new CcBuild.MotionDrawings(); }
            s_drawings[motion] = d;
            return d;
        }

        static string CoinsIn(string motion)
        {
            try
            {
                CcBuild.MotionDrawings d = Drawings(motion);
                if (d.Frames.Count == 0) return null;

                if (d.Notes.Count > 0) return "READ THIS BUILD'S REPORT -- see the note on " + motion;

                if (d.Groups.Count <= 1 && !d.FromFolders) return null;

                var words = new List<string>();
                foreach (CcBuild.CoinGroup g in d.Groups)
                    words.Add(g.Coin < 0 ? "whole skill" : "clash " + g.Coin.ToString(CultureInfo.InvariantCulture));
                return string.Join(", ", words.ToArray()) + " (" + d.Groups.Count + " animation" +
                       (d.Groups.Count == 1 ? "" : "s") + (d.Groups.Count > 1 ? ", one per clash" : "") + ")";
            }
            catch { return null; }
        }

        static int CountFrames(string motion)
        {
            try { return Drawings(motion).Frames.Count; }
            catch { return 0; }
        }

        static readonly HashSet<string> s_placeholders = new HashSet<string>(StringComparer.Ordinal);
        static double s_placeholdersAt = -1.0;

        static bool ShowsAsPlaceholder(string motion)
        {
            double now = EditorApplication.timeSinceStartup;
            if (s_placeholdersAt < 0.0 || now - s_placeholdersAt > 1.0)
            {
                s_placeholdersAt = now;
                s_placeholders.Clear();
                try
                {
                    foreach (string m in CcBuild.MotionsToBuild())
                        if (CcBuild.IsPlaceholder(m)) s_placeholders.Add(m);
                }
                catch { }
            }
            return s_placeholders.Contains(motion);
        }

        void DrawTargetPicker()
        {
            List<Target> all = CcTargets.All;
            if (all.Count == 0)
            {
                string err = CcTargets.LoadError;
                EditorGUILayout.HelpBox(string.IsNullOrEmpty(err)
                    ? "The character list is empty. Type an appearance name by hand below."
                    : err, MessageType.Warning);
                m_appearance = EditorGUILayout.TextField("Replaces", m_appearance);
                return;
            }

            if (m_labels == null || m_labels.Length != all.Count) m_labels = CcTargets.MenuLabels();

            int index = all.FindIndex(t => t.Name == m_appearance);
            int picked = EditorGUILayout.Popup("Replaces", index, m_labels);
            if (picked != index && picked >= 0 && picked < all.Count)
            {
                m_appearance = all[picked].Name;
                Save();
            }

            if (index < 0)
                EditorGUILayout.HelpBox(
                    "Pick a character. A mod always REPLACES one the game already has -- Limbonia writes your " +
                    "animation into that character's motion list and cannot add a new character. The name is " +
                    "matched exactly, which is why this is a list and not a text box.", MessageType.Info);
            else
                EditorGUILayout.LabelField(" ", m_appearance, EditorStyles.miniLabel);
        }

        string m_scaffoldNote;

        void DrawScaffoldButton()
        {
            Target t = CcTargets.ByName(m_appearance);
            using (new EditorGUI.DisabledScope(t == null))
            {
                if (GUILayout.Button(new GUIContent("Set up the folders for this character",
                        "Makes a Sprites/<motion>/ folder for every motion this character actually has, and puts " +
                        "a copy of your standing pose in each new one so the character is covered everywhere. " +
                        "A folder that already has drawings in it is never touched.")))
                    Defer(RunScaffold);
            }

            if (t == null)
            {
                EditorGUILayout.LabelField(" ", "pick a character above to see which motions it has",
                                           EditorStyles.miniLabel);
                return;
            }

            int missing = 0;
            foreach (TargetMotion m in t.Motions)
                if (!string.IsNullOrEmpty(m.Motion) && CountFrames(m.Motion) == 0 &&
                    !Directory.Exists(Path.GetFullPath(CcBuild.SpritesRoot + "/" + m.Motion))) missing++;

            EditorGUILayout.LabelField(" ", t.Motions.Count + " motion(s) on this character" +
                (missing > 0 ? ", " + missing + " with no folder yet" : " -- you have a folder for every one"),
                EditorStyles.miniLabel);
            EditorGUILayout.LabelField(" ", "new folders are seeded with a copy of your Default pose; folders with " +
                                       "drawings in them are never touched", EditorStyles.miniLabel);

            if (!string.IsNullOrEmpty(m_scaffoldNote))
                EditorGUILayout.HelpBox(m_scaffoldNote, MessageType.Info);
        }

        void RunScaffold()
        {
            CcBuild.ScaffoldResult r = CcBuild.Scaffold(m_appearance, s => Debug.Log("[CustomCharacter] " + s));
            if (r.Problem != null)
            {
                m_scaffoldNote = r.Problem;
                Debug.LogWarning("[CustomCharacter] " + r.Problem);
                return;
            }

            var sb = new StringBuilder();
            if (r.Seeded.Count > 0)
                sb.AppendLine(r.Seeded.Count + " folder(s) made and given a starting frame: " +
                              string.Join(", ", r.Seeded.ToArray()));
            if (r.Empty.Count > 0)
                sb.AppendLine(r.Empty.Count + " folder(s) made and left empty" +
                              (r.SeededFrom == null
                                  ? " -- there was no Default or Idle drawing to copy into them yet."
                                  : ".") + ": " + string.Join(", ", r.Empty.ToArray()));
            if (r.Seeded.Count == 0 && r.Empty.Count == 0)
                sb.AppendLine("Nothing to do -- you already have a folder for every motion this character has.");
            if (r.LeftAlone.Count > 0)
                sb.AppendLine("Left exactly as they were (they have drawings in them): " +
                              string.Join(", ", r.LeftAlone.ToArray()));
            if (r.Seeded.Count > 0)
                sb.AppendLine("The seeded frames are copies of your standing pose, not animation. Draw over them; " +
                              "the build reports them as placeholders until you do.");
            s_placeholdersAt = -1.0;
            m_scaffoldNote = sb.ToString().TrimEnd();
            Debug.Log("[CustomCharacter] " + m_scaffoldNote);
        }

        void DrawAdvanced()
        {
            m_advanced = EditorGUILayout.Foldout(m_advanced, "Advanced  (you rarely need this)", true);
            if (!m_advanced) return;

            using (new EditorGUI.IndentLevelScope())
            {
                m_fps = EditorGUILayout.FloatField("Frames per second", m_fps);
                EditorGUILayout.LabelField(" ", "one folder can override it with an fps.txt inside it",
                                           EditorStyles.miniLabel);

                m_ppu = EditorGUILayout.FloatField("Pixels per unit", m_ppu);
                m_pivotX = EditorGUILayout.Slider("Pivot X", m_pivotX, 0f, 1f);
                m_pivotY = EditorGUILayout.Slider("Pivot Y", m_pivotY, 0f, 1f);
                EditorGUILayout.LabelField(" ", "pivot 0.5 / 0 = bottom centre: feet on the floor line",
                                           EditorStyles.miniLabel);

                m_move = EditorGUILayout.Toggle("Step towards the target", m_move);
                EditorGUILayout.LabelField(" ", "S1/S2/S3 only. Off = the character attacks on the spot.",
                                           EditorStyles.miniLabel);

                m_sidecar = EditorGUILayout.Toggle("Let Limbonia draw the character", m_sidecar);
                if (m_sidecar)
                {
                    EditorGUILayout.LabelField(" ", "on: Limbonia draws your animation on top of the original, and",
                                               EditorStyles.miniLabel);
                    EditorGUILayout.LabelField(" ", "a motion you did not draw plays YOUR Idle, not the original.",
                                               EditorStyles.miniLabel);
                }
                else
                {
                    EditorGUILayout.LabelField(" ", "off: the animation goes into the character's own list.",
                                               EditorStyles.miniLabel);
                    EditorGUILayout.LabelField(" ", "REMOVED FROM LIMBONIA -- built this way, nothing is drawn.",
                                               EditorStyles.miniLabel);
                }

                m_binding = EditorGUILayout.TextField("Binding path override", m_binding);
                Target t = CcTargets.ByName(m_appearance);
                string effective = !string.IsNullOrEmpty(m_binding) ? m_binding
                                 : (t != null && !string.IsNullOrEmpty(t.BindingPath) ? t.BindingPath
                                 : CcTargets.StandardBindingPath);
                EditorGUILayout.LabelField(" ", "using: " + effective, EditorStyles.miniLabel);
                EditorGUILayout.LabelField(" ", "leave blank. Only touch this if the mod loads but nothing changes.",
                                           EditorStyles.miniLabel);
            }
        }

        void DrawBuildButton()
        {
            string blocker = Blocker();
            using (new EditorGUI.DisabledScope(blocker != null))
            {
                if (s_bigButton == null)
                    s_bigButton = new GUIStyle(GUI.skin.button) { fontStyle = FontStyle.Bold, fixedHeight = 40f };
                if (GUILayout.Button("BUILD THE MOD", s_bigButton))
                    Launch(CcBuildMode.Regenerate);

                if (GUILayout.Button("Build without regenerating  (ships what is in _Generated/ as it is)"))
                    Launch(CcBuildMode.UseExisting);
            }
            if (blocker != null) EditorGUILayout.HelpBox(blocker, MessageType.Warning);
            else
            {
                EditorGUILayout.LabelField(
                    " ", "BUILD THE MOD: re-reads your drawings and REPLACES the animations",
                    EditorStyles.miniLabel);
                EditorGUILayout.LabelField(
                    " ", "without regenerating: packs and deploys the animations already built, untouched",
                    EditorStyles.miniLabel);
                if (m_keep.Count > 0)
                    EditorGUILayout.LabelField(
                        " ", "kept from regeneration: " + string.Join(", ", m_keep.OrderBy(s => s).ToArray()),
                        EditorStyles.miniLabel);
            }
        }

        void Launch(CcBuildMode mode)
        {
            Save();
            var options = new CcBuildOptions
            {
                AppearanceName = m_appearance,
                ModName = m_modName,
                ModsFolder = m_modsFolder,
                Fps = m_fps,
                Ppu = m_ppu,
                PivotX = m_pivotX,
                PivotY = m_pivotY,
                StepTowardsTarget = m_move,
                BindingPathOverride = m_binding,
                Renderer = m_sidecar ? CcManifest.RendererSidecar : CcManifest.RendererSlot,
                OpenPreview = true,
                Mode = mode,
                KeepMotions = new HashSet<string>(m_keep, StringComparer.Ordinal),
            };
            m_running = true;
            Defer(() => CcBuild.Run(options));
        }

        string Blocker()
        {
            if (string.IsNullOrEmpty(m_appearance))
                return "Choose the character this replaces.";
            if (string.IsNullOrEmpty(m_modName))
                return "Give the mod a name.";
            if (CcBuild.Sanitize(m_modName) == "mod" && m_modName != "mod")
                return "The mod name needs letters, digits, - or _ in it.";
            if (string.IsNullOrEmpty(m_modsFolder))
                return "Set the Mods folder -- it is the \"Mods\" folder beside LimbusCompany.exe.";
            if (!Directory.Exists(m_modsFolder))
                return "That Mods folder does not exist: " + m_modsFolder;
            if (CcBuild.MotionsToBuild().All(m => CountFrames(m) == 0) && !AnythingGenerated())
                return "There are no drawings yet. Put PNGs in " + CcBuild.SpritesRoot +
                       "/<motion>/ -- one folder per animation.";
            return null;
        }

        void Defer(Action work)
        {
            EditorApplication.delayCall += () =>
            {
                try { work(); }
                catch (ExitGUIException) { throw; }
                catch (Exception e) { Debug.LogException(e); }
                finally
                {
                    m_running = false;
                    Repaint();
                }
            };
        }

        static string GuessModsFolder()
        {
            string[] candidates =
            {
                @"C:\Program Files (x86)\Steam\steamapps\common\Limbus Company\Mods",
                @"C:\SteamLibrary\steamapps\common\Limbus Company\Mods",
                @"D:\SteamLibrary\steamapps\common\Limbus Company\Mods",
                @"E:\SteamLibrary\steamapps\common\Limbus Company\Mods",
                @"F:\SteamLibrary\steamapps\common\Limbus Company\Mods",
            };
            foreach (string c in candidates)
            {
                try
                {
                    if (Directory.Exists(c)) return c;
                    string parent = Path.GetDirectoryName(c);
                    if (parent != null && File.Exists(Path.Combine(parent, "LimbusCompany.exe"))) return c;
                }
                catch { }
            }
            return "";
        }
    }
}
