using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Timeline;

namespace Limbonia.CustomCharacter
{
    public class CcPlacement
    {
        public string Motion;
        public string TrackName;
        public bool TrackMuted;
        public int TrackIndex;

        public double Time;

        public double Length = 1.0;

        public double ClipIn;
        public double TimeScale = 1.0;
        public string DisplayName;

        public GameObject Prefab;
        public string PrefabAssetPath;

        public string AssetName;

        public Vector3 Position;

        public bool UpdateParticle = true;
        public bool UpdateDirector = true;
        public bool UpdateITimeControl = true;
        public bool SearchHierarchy;
        public bool Active = true;
        public uint ParticleRandomSeed;
        public ActivationControlPlayable.PostPlaybackState PostPlayback =
            ActivationControlPlayable.PostPlaybackState.Revert;
        public DirectorControlPlayable.PauseAction DirectorOnClipEnd;

        public string Problem;

        public bool Shippable { get { return Problem == null && !TrackMuted && Prefab != null; } }

        public bool Sleeping { get { return Problem == null && TrackMuted && Prefab != null; } }
    }

    public class CcVfxTrack
    {
        public string Name = CcVfx.TrackName;
        public bool Muted;
        public bool InsideGroup;
        public int TrackIndex;
        public readonly List<CcPlacement> Placements = new List<CcPlacement>();
    }

    public class CcMotionVfx
    {
        public string Motion;
        public string TimelinePath;

        public bool TimelineRead;

        public readonly List<CcVfxTrack> Tracks = new List<CcVfxTrack>();

        public IEnumerable<CcPlacement> Placements { get { return Tracks.SelectMany(t => t.Placements); } }
        public IEnumerable<CcPlacement> Shippable { get { return Placements.Where(p => p.Shippable); } }
        public IEnumerable<CcPlacement> Sleeping { get { return Placements.Where(p => p.Sleeping); } }
        public bool Any { get { return Tracks.Count > 0; } }
        public bool AnyMuted { get { return Tracks.Any(t => t.Muted); } }
    }

    public static class CcVfx
    {
        public const string TrackName = "Effects";

        public const double MinSlot = 0.05;

        static readonly List<CcMotionVfx> s_pending = new List<CcMotionVfx>();

        public const double PreviewScaleFactor = 2.0;

        public const string PreviewScaleNote =
            "IN GAME AN EFFECT OF YOUR OWN IS DRAWN TWICE THE SIZE IT IS HERE, relative to the character -- a " +
            "height of 1 lands twice as far up them, AND EVERYTHING IN IT MOVES TWICE AS FAST across them, because " +
            "particle speeds are in world units and the character is half the size in game that it is here. The " +
            "character hangs under a pivot the game scales to half, and an effect of yours does not. THE FIX THAT " +
            "MOVES BOTH TOGETHER is to set the effect's Size to 0.5 where you place it (a particle system's scale " +
            "multiplies its speeds as well as its sizes). Shrinking the particles inside the prefab instead fixes " +
            "the size and leaves it running at double speed.";

        public static CcMotionVfx Capture(string motion, string timelinePath)
        {
            var result = new CcMotionVfx { Motion = motion, TimelinePath = timelinePath };
            try
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath);
                if (timeline == null) return result;
                result.TimelineRead = true;

                int index = 0;
                foreach (TrackAsset track in timeline.GetOutputTracks())
                {
                    var control = track as ControlTrack;
                    if (control == null) continue;

                    var cap = new CcVfxTrack
                    {
                        Name = string.IsNullOrEmpty(control.name) ? TrackName : control.name,
                        Muted = control.muted,
                        InsideGroup = control.parent is GroupTrack,
                        TrackIndex = index,
                    };

                    foreach (TimelineClip clip in control.GetClips())
                    {
                        var asset = clip.asset as ControlPlayableAsset;
                        var p = new CcPlacement
                        {
                            Motion = motion,
                            TrackName = cap.Name,
                            TrackMuted = cap.Muted,
                            TrackIndex = index,
                            Time = clip.start,
                            Length = clip.duration,
                            ClipIn = clip.clipIn,
                            TimeScale = clip.timeScale,
                            DisplayName = clip.displayName,
                        };
                        if (asset != null)
                        {
                            p.Prefab = asset.prefabGameObject;
                            p.UpdateParticle = asset.updateParticle;
                            p.UpdateDirector = asset.updateDirector;
                            p.UpdateITimeControl = asset.updateITimeControl;
                            p.SearchHierarchy = asset.searchHierarchy;
                            p.Active = asset.active;
                            p.ParticleRandomSeed = asset.particleRandomSeed;
                            p.PostPlayback = asset.postPlayback;
                            p.DirectorOnClipEnd = asset.directorOnClipEnd;
                        }
                        if (p.Prefab != null)
                        {
                            p.AssetName = p.Prefab.name;
                            p.PrefabAssetPath = AssetDatabase.GetAssetPath(p.Prefab);
                            p.Position = p.Prefab.transform.localPosition;
                        }
                        cap.Placements.Add(p);
                    }

                    result.Tracks.Add(cap);
                    index++;
                }
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                result.TimelineRead = false;
                Debug.LogWarning("[CustomCharacter] could not read the effects on " + timelinePath + ": " + e.Message);
            }

            if (result.Any) s_pending.Add(result);
            return result;
        }

        public static void StripTracks(string timelinePath)
        {
            try
            {
                var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(timelinePath);
                if (timeline == null) return;
                var doomed = new List<ControlTrack>();
                foreach (TrackAsset t in timeline.GetOutputTracks())
                {
                    var control = t as ControlTrack;
                    if (control != null) doomed.Add(control);
                }
                if (doomed.Count == 0) return;
                foreach (ControlTrack t in doomed) timeline.DeleteTrack(t);
                EditorUtility.SetDirty(timeline);
                AssetDatabase.SaveAssets();
            }
            catch (ExitGUIException) { throw; }
            catch (Exception e)
            {
                Debug.LogWarning("[CustomCharacter] could not take the effect track off " + timelinePath +
                                 " before building: " + e.Message);
            }
        }

        public static void RestorePending(Action<string> log)
        {
            if (s_pending.Count == 0) return;
            var pending = new List<CcMotionVfx>(s_pending);
            s_pending.Clear();

            int tracks = 0, placements = 0, failed = 0;
            foreach (CcMotionVfx mv in pending)
            {
                try
                {
                    if (RestoreOne(mv)) { tracks += mv.Tracks.Count; placements += mv.Placements.Count(); }
                    else failed++;
                }
                catch (ExitGUIException) { throw; }
                catch (Exception e)
                {
                    failed++;
                    Debug.LogWarning("[CustomCharacter] could not put the effects back on " + mv.TimelinePath +
                                     ": " + e.Message);
                }
            }

            if (tracks > 0 || failed > 0)
            {
                try { AssetDatabase.SaveAssets(); } catch { }
                if (log != null)
                {
                    log("");
                    log("effects: " + tracks + " control track(s) holding " + placements + " placement(s) put back " +
                        "on the timelines in " + CcBuild.GeneratedRoot + " so you can keep editing them.");
                    log("  They were taken off only for the moment the bundle was built. THE BUNDLE CONTAINS NO");
                    log("  CONTROL TRACK, on purpose: Limbonia builds its own effect track on the coin when it");
                    log("  applies the mod, and a second one shipped inside the archive would fight it. Your");
                    log("  placements were consumed at build time and written into mod.json instead.");
                    if (failed > 0)
                        log("WARNING: " + failed + " timeline(s) could not have their effects put back -- see the " +
                            "Console. Re-drag those prefabs before the next build, or they are lost.");
                }
            }
        }

        static bool RestoreOne(CcMotionVfx mv)
        {
            var timeline = AssetDatabase.LoadAssetAtPath<TimelineAsset>(mv.TimelinePath);
            if (timeline == null) return false;

            foreach (CcVfxTrack cap in mv.Tracks)
            {
                var track = timeline.CreateTrack<ControlTrack>(null, cap.Name);
                if (track == null) return false;
                if (!AssetDatabase.Contains(track)) AssetDatabase.AddObjectToAsset(track, timeline);
                track.muted = cap.Muted;

                foreach (CcPlacement p in cap.Placements)
                {
                    TimelineClip clip = track.CreateClip<ControlPlayableAsset>();
                    if (clip == null) continue;

                    var asset = clip.asset as ControlPlayableAsset;
                    if (asset != null)
                    {
                        asset.prefabGameObject = p.Prefab;
                        asset.updateParticle = p.UpdateParticle;
                        asset.updateDirector = p.UpdateDirector;
                        asset.updateITimeControl = p.UpdateITimeControl;
                        asset.searchHierarchy = p.SearchHierarchy;
                        asset.active = p.Active;
                        if (p.ParticleRandomSeed != 0) asset.particleRandomSeed = p.ParticleRandomSeed;
                        asset.postPlayback = p.PostPlayback;
                        asset.directorOnClipEnd = p.DirectorOnClipEnd;
                        if (!AssetDatabase.Contains(asset)) AssetDatabase.AddObjectToAsset(asset, timeline);
                        EditorUtility.SetDirty(asset);
                    }

                    clip.start = p.Time;
                    if (p.Length > 0.0) clip.duration = p.Length;
                    clip.clipIn = p.ClipIn;
                    if (p.TimeScale > 0.0) clip.timeScale = p.TimeScale;
                    if (!string.IsNullOrEmpty(p.DisplayName)) clip.displayName = p.DisplayName;
                }
                EditorUtility.SetDirty(track);
            }
            EditorUtility.SetDirty(timeline);
            return true;
        }

        public static void Validate(CcMotionVfx mv, double motionDuration, Action<string> info, Action<string> warn)
        {
            if (mv == null || !mv.Any) return;

            foreach (CcVfxTrack t in mv.Tracks)
            {
                if (t.InsideGroup)
                    warn("  " + mv.Motion + ": the effect track '" + t.Name + "' is inside a track group. The " +
                         "placements still ship, but the group is not put back after a build -- the track " +
                         "reappears at the top level of the timeline.");
            }

            foreach (CcPlacement p in mv.Placements)
            {
                if (p.Prefab == null)
                {
                    p.Problem = "an empty effect clip at " + Secs(p.Time) + "s with no prefab in it";
                    warn("  " + mv.Motion + ": EFFECT NOT PLACED -- an empty control clip sits at " + Secs(p.Time) +
                         "s with no prefab in it. Drag a prefab from " + CcEffects.EffectsRoot + " onto it, or " +
                         "delete the clip.");
                    continue;
                }

                string path = p.PrefabAssetPath ?? "";
                if (!path.StartsWith(CcEffects.EffectsRoot + "/", StringComparison.OrdinalIgnoreCase))
                {
                    p.Problem = "'" + p.AssetName + "' is not in " + CcEffects.EffectsRoot;
                    warn("  " + mv.Motion + ": EFFECT NOT PLACED -- '" + p.AssetName + "' lives at " +
                         (path.Length > 0 ? path : "an unknown path") + ", and only prefabs in " +
                         CcEffects.EffectsRoot + " are packed into the mod's bundle. Move the prefab there and " +
                         "drag it on again, or the mod would name an effect it does not ship.");
                    continue;
                }

                if (p.Time < 0.0)
                {
                    warn("  " + mv.Motion + ": '" + p.AssetName + "' starts before the animation does; moved to 0s.");
                    p.Time = 0.0;
                }

                if (motionDuration > 0.0 && p.Time > motionDuration)
                {
                    warn("  " + mv.Motion + ": '" + p.AssetName + "' is placed at " + Secs(p.Time) + "s but " +
                         mv.Motion + " is only " + Secs(motionDuration) + "s long, so it can NEVER play. It is " +
                         "still written into mod.json in case you lengthen the animation -- move it earlier, or " +
                         "draw more frames.");
                }
                else if (motionDuration > 0.0 && p.Time + p.Length > motionDuration + 0.0011)
                {
                    warn("  " + mv.Motion + ": '" + p.AssetName + "' runs past the end of " + mv.Motion + " (it " +
                         "ends at " + Secs(p.Time + p.Length) + "s, the animation is " + Secs(motionDuration) +
                         "s). It plays, but it is cut off when the action ends. Shorten the clip, or tick \"let " +
                         "it finish\" on it in the companion so it runs itself out.");
                }

                if (p.Length < MinSlot - 0.0001)
                    warn("  " + mv.Motion + ": '" + p.AssetName + "' is only " + Secs(p.Length) + "s long. " +
                         "Limbonia holds an effect for at least 0.05s whatever the file says, so it will be " +
                         "slightly longer in game than it is here. Stretch the clip if the timing matters.");

                if (p.TimeScale < 0.999 || p.TimeScale > 1.001)
                    warn("  " + mv.Motion + ": '" + p.AssetName + "' has a speed multiplier on its clip. Only the " +
                         "start time and the length carry over, so the effect plays at its own speed in game.");
            }

            if (mv.AnyMuted && info != null)
            {
                var muted = new List<string>();
                foreach (CcVfxTrack t in mv.Tracks) if (t.Muted) muted.Add("'" + t.Name + "'");
                info("  " + mv.Motion + ": the effect track " + JMerge.Sentence(muted) + " is muted, so its " +
                     "placements were left exactly as they are. Nothing about them was rewritten -- un-mute the " +
                     "track when you want the build to own them again.");
            }
        }

        static string Secs(double d) { return d.ToString("0.###", CultureInfo.InvariantCulture); }
    }
}
