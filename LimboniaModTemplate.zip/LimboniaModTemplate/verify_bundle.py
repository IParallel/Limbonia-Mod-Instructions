#!/usr/bin/env python
"""Check that a built motion bundle is one the game can actually load.

The build runs this for you after every build, if Python and UnityPy are on the
machine, and refuses to deploy a bundle that does not pass. You can also run it
by hand:

    pip install UnityPy==1.10.18
    python verify_bundle.py <bundle> --bundle-name <name> --asset <asset name>

Exit codes: 0 = the bundle is loadable in shape, 1 = it is not, 2 = the checker
itself could not run (missing UnityPy, unreadable file).
"""

import argparse
import os
import struct
import sys
import zlib

FALLBACK_UNITY_VERSION = "6000.3.12f1"

EXPECTED_FORMAT = 8

problems = []
notes = []

def fail(msg):
    problems.append(msg)

def note(msg):
    notes.append(msg)

def read_header(path):
    """Parse just enough of the UnityFS header to describe the archive."""
    with open(path, "rb") as fh:
        head = fh.read(96)
    if len(head) < 32:
        fail("file is %d bytes -- that is not an AssetBundle" % len(head))
        return None
    if not head.startswith(b"UnityFS\x00"):
        fail("magic is %r, expected 'UnityFS' -- this is not a UnityFS archive" % head[:8])
        return None

    fmt = struct.unpack(">i", head[8:12])[0]
    p = 12
    end = head.index(b"\x00", p)
    player_version = head[p:end].decode("ascii", "replace")
    p = end + 1
    end = head.index(b"\x00", p)
    unity_version = head[p:end].decode("ascii", "replace")
    p = end + 1
    size, c_blocks, u_blocks, flags = struct.unpack(">qiiI", head[p:p + 20])

    compression = {0: "none", 1: "LZMA", 2: "LZ4", 3: "LZ4HC", 4: "LZHAM"}.get(flags & 0x3F, "unknown(%d)" % (flags & 0x3F))
    info = {
        "format": fmt,
        "playerVersion": player_version,
        "unityVersion": unity_version,
        "size": size,
        "flags": flags,
        "compression": compression,
    }

    if fmt != EXPECTED_FORMAT:
        fail("UnityFS format is %d, expected %d -- the game will refuse it" % (fmt, EXPECTED_FORMAT))
    if compression == "LZMA":
        note("compression is LZMA; LoadFromFile prefers a chunk-compressed (LZ4/LZ4HC) archive. "
             "Build with BuildAssetBundleOptions.ChunkBasedCompression.")
    if size != os.path.getsize(path):
        fail("header says the archive is %d bytes but the file is %d -- it is truncated"
             % (size, os.path.getsize(path)))
    return info

def object_name(obj):
    """m_Name without depending on UnityPy's per-class wrappers."""
    try:
        tree = obj.read_typetree()
    except Exception:
        return None
    if isinstance(tree, dict):
        name = tree.get("m_Name")
        return name if isinstance(name, str) else None
    return None

def path_hash(path):
    """Unity stores a curve's target as the CRC32 of its transform path."""
    return zlib.crc32(path.encode("utf-8")) & 0xFFFFFFFF

def verify_clips(objects, expect_clips, expect_path):
    """Assert that the animations inside the archive actually animate something.

    For each clip the build says it wrote, find it by name and require a real
    sprite curve with the expected number of drawings. A bundle can be perfectly
    formed and still contain an empty clip, which loads without complaint and
    moves nothing.
    """
    if not expect_clips:
        return

    by_name = {}
    for obj in objects:
        if obj.type.name != "AnimationClip":
            continue
        try:
            tree = obj.read_typetree()
        except Exception as exc:
            fail("an AnimationClip in the bundle could not be read: %s: %s" % (type(exc).__name__, exc))
            continue
        name = tree.get("m_Name")
        if isinstance(name, str):
            by_name[name] = tree

    for name, expected_keys in sorted(expect_clips.items()):
        tree = by_name.get(name)
        if tree is None:
            fail("the bundle has no AnimationClip named %r, but the build says it wrote one" % name)
            continue

        binding_constant = tree.get("m_ClipBindingConstant") or {}
        generic = binding_constant.get("genericBindings") or []
        pptr_map = binding_constant.get("pptrCurveMapping") or []

        pptr_bindings = [b for b in generic if b.get("isPPtrCurve")]
        if not pptr_bindings:
            fail("%r IS AN EMPTY ANIMATION -- %d genericBindings, none of them a sprite curve.\n"
                 "    In game this loads with no error and the character simply does not move.\n"
                 "    The build reported writing %d drawing keys into it, so the curve was lost\n"
                 "    between being set and being serialized." % (name, len(generic), expected_keys))
            continue
        if not pptr_map:
            fail("%r has a sprite binding but an empty pptrCurveMapping -- it references no drawings"
                 % name)
            continue
        if len(pptr_map) != expected_keys:
            fail("%r holds %d drawing keys but the build wrote %d"
                 % (name, len(pptr_map), expected_keys))
            continue

        if expect_path:
            wanted = path_hash(expect_path)
            got = pptr_bindings[0].get("path")
            if got != wanted:
                fail("%r binds to transform path hash %s, but %r hashes to %s. A curve on the wrong "
                     "path binds to nothing and plays invisibly." % (name, got, expect_path, wanted))
                continue

        note("%s: %d drawing key(s), binding path hash %s -- animates"
             % (name, len(pptr_map), pptr_bindings[0].get("path")))

def verify(path, expect_bundle_name, expect_assets, expect_clips, expect_path):
    try:
        import UnityPy
    except ImportError:
        print("verify_bundle: UnityPy is not installed in this interpreter (%s)" % sys.executable)
        print("               pip install UnityPy   (the pipeline's venv is Tools/LimbusExtract/.venv)")
        return 2

    UnityPy.config.FALLBACK_UNITY_VERSION = FALLBACK_UNITY_VERSION

    info = read_header(path)
    if info:
        print("header: UnityFS format %d, unityVersion '%s', %s, %d bytes"
              % (info["format"], info["unityVersion"], info["compression"], info["size"]))

    try:
        env = UnityPy.load(path)
        objects = list(env.objects)
    except Exception as exc:
        fail("UnityPy could not open the archive: %s: %s" % (type(exc).__name__, exc))
        return report()

    kinds = {}
    for obj in objects:
        kinds[obj.type.name] = kinds.get(obj.type.name, 0) + 1
    print("objects: %d  %s" % (len(objects), ", ".join("%s x%d" % kv for kv in sorted(kinds.items()))))

    bundle_objects = [o for o in objects if o.type.name == "AssetBundle"]
    if not bundle_objects:
        fail("NO AssetBundle OBJECT (class 142) IN THE ARCHIVE.\n"
             "    This is the manifest object that holds the bundle name and the name->object table,\n"
             "    and it is the first thing AssetBundle.LoadFromFile reads. Without it the runtime\n"
             "    rejects the archive outright and blames the Unity version, which is misleading.\n"
             "    KNOWN CAUSE: the AssetBundle module is disabled in the Unity project --\n"
             "    add \"com.unity.modules.assetbundle\": \"1.0.0\" to Packages/manifest.json.\n"
             "    (Unity logs \"'AssetBundle' is not supported because the module AssetBundle is\n"
             "    disabled in the build\" during BuildAssetBundles, but still writes the archive\n"
             "    and still returns a non-null AssetBundleManifest.)")
    elif len(bundle_objects) > 1:
        fail("%d AssetBundle objects in one archive -- exactly one is expected" % len(bundle_objects))

    container = []
    if bundle_objects:
        try:
            tree = bundle_objects[0].read_typetree()
        except Exception as exc:
            tree = {}
            fail("the AssetBundle object could not be read: %s: %s" % (type(exc).__name__, exc))
        internal_name = tree.get("m_Name") or tree.get("m_AssetBundleName")
        print("bundle internal name: %r" % internal_name)
        container = [entry[0] for entry in tree.get("m_Container", []) if isinstance(entry, (list, tuple)) and entry]
        for path_key in container:
            print("  container: %s" % path_key)
        if expect_bundle_name and internal_name:
            if str(internal_name).lower() != expect_bundle_name.lower():
                fail("bundle internal name is %r but %r was expected. Limbonia refuses a second archive "
                     "with an internal name that is already open, so this must be the unique name "
                     "mod.json was written against." % (internal_name, expect_bundle_name))

    present = set()
    for obj in objects:
        name = object_name(obj)
        if name:
            present.add(name)
    for wanted in expect_assets:
        if wanted not in present:
            fail("no object named %r in the bundle -- mod.json declares it and Limbonia resolves assets by "
                 "NAME via LoadAsset(name, Type), so it would silently never load.\n"
                 "    names present: %s" % (wanted, ", ".join(sorted(present)) or "(none)"))

    verify_clips(objects, expect_clips, expect_path)

    for name, sub in env.files.items():
        externals = getattr(sub, "externals", None) or []
        for ext in externals:
            ext_path = getattr(ext, "path", str(ext))
            if ext_path.startswith("archive:/"):
                fail("the bundle references another archive (%s). Limbonia loads one file with "
                     "LoadFromFile and never resolves bundle dependencies, so that reference is dead."
                     % ext_path)
            else:
                note("external reference %r (resolved by the player, normally fine)" % ext_path)

    if any(o.type.name == "MonoScript" for o in objects):
        note("the bundle carries MonoScript objects (expected: Timeline's TimelineAsset / AnimationTrack / "
             "AnimationPlayableAsset). They are required for a standalone bundle, and they resolve in the "
             "IL2CPP player by assembly+namespace+class -- the game ships Unity.Timeline, so they should "
             "bind. Shipped game bundles have none only because Addressables puts them in a shared bundle.")

    return report()

def report():
    for msg in notes:
        print("note: %s" % msg)
    if problems:
        print("")
        print("FAILED -- this bundle will not work in game:")
        for msg in problems:
            print("  * %s" % msg)
        return 1
    print("OK -- the bundle is structurally loadable.")
    return 0

def main():
    ap = argparse.ArgumentParser(description="Verify a Limbonia motion AssetBundle before it is deployed.")
    ap.add_argument("bundle", help="path to the built .bundle")
    ap.add_argument("--bundle-name", default=None,
                    help="the internal bundle name the build asked for (compared case-insensitively)")
    ap.add_argument("--asset", action="append", default=[], dest="assets",
                    help="an asset name mod.json declares; repeatable. Verified by object name, "
                         "which is what LoadAsset(name, Type) matches on.")
    ap.add_argument("--clip", action="append", default=[], dest="clips", metavar="NAME:KEYS",
                    help="an AnimationClip that must carry a sprite curve with KEYS drawings; "
                         "repeatable. This is the check that an animation actually animates -- "
                         "an empty clip is invisible everywhere else.")
    ap.add_argument("--clip-path", default=None,
                    help="the transform path every sprite curve must bind to. Compared as CRC32, "
                         "which is what Unity stores. A curve on the wrong path plays invisibly.")
    args = ap.parse_args()

    expect_clips = {}
    for spec in args.clips:
        name, sep, count = spec.rpartition(":")
        if not sep or not count.isdigit():
            print("verify_bundle: --clip wants NAME:KEYS, got %r" % spec)
            return 2
        expect_clips[name] = int(count)

    if not os.path.isfile(args.bundle):
        print("verify_bundle: no such file: %s" % args.bundle)
        return 2
    return verify(args.bundle, args.bundle_name, args.assets, expect_clips, args.clip_path)

if __name__ == "__main__":
    sys.exit(main())
