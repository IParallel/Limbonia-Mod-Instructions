from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from limbusx import init_stdout
from limbusx.env import load_bundle
from limbusx.extract import (
    AppearanceNotFound,
    build_container_index,
    extract_appearance,
    extract_spine,
    list_bundle,
    open_appearance,
)
from limbusx.locate import BundleIndex, BundleNotFound, find_cache_dir, find_game_dir
from limbusx.vfx import extract_vfx


def add_source_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--game-dir",
        help="Limbus Company install directory (auto-detected if omitted)",
    )
    parser.add_argument(
        "--cache-dir",
        help="Addressables download cache "
        "(<LocalLow>/Unity/ProjectMoon_LimbusCompany; auto-detected if omitted)",
    )
    parser.add_argument(
        "--bundle",
        help="Bundle to read: either a base name from catalog.bin "
        "(e.g. p10916_assets_all) or a path to a __data / .bundle file. "
        "Skips the name-based lookup entirely.",
    )


def make_index(args: argparse.Namespace) -> BundleIndex:
    game_dir = find_game_dir(args.game_dir)
    cache_dir = find_cache_dir(args.cache_dir)
    return BundleIndex(game_dir, cache_dir)


def resolve_bundle_for_listing(args: argparse.Namespace, index: BundleIndex):
    if os.path.isfile(args.bundle or ""):
        return load_bundle(args.bundle, os.path.basename(args.bundle)), os.path.basename(args.bundle)
    hit = index.resolve(args.bundle)
    if not hit:
        raise BundleNotFound(
            f"bundle {args.bundle!r} not found. Names come from catalog.bin; "
            "try `list --grep <pattern>` to search them."
        )
    path, name = hit
    return load_bundle(path, name), name


def cmd_list(args: argparse.Namespace) -> int:
    index = make_index(args)

    if args.find:
        return _list_find(index, args.find)

    if args.grep:
        names = index.matching(args.grep)
        print(f"{len(names)} bundle name(s) in catalog.bin matching {args.grep!r}:")
        for name in names:
            hit = index.resolve(name)
            where = "on disk" if hit else "NOT on disk"
            print(f"  {name}  [{where}]")
        return 0

    if args.bundle:
        bundle, name = resolve_bundle_for_listing(args, index)
        for line in list_bundle(bundle, name):
            print(line)
        if args.container:
            print("\n  bundle container (original project asset paths):")
            for path in bundle.container():
                print(f"    {path}")
        return 0

    if not args.appearance:
        print("Give an appearance (id or name), or --bundle, or --grep. See --help.")
        return 2

    bundle, appearance, bundle_name = open_appearance(
        index, args.appearance, args.bundle, verbose=args.verbose
    )
    for line in list_bundle(bundle, bundle_name):
        print(line)
    if args.container:
        print("\n  bundle container (original project asset paths):")
        for path in bundle.container():
            print(f"    {path}")
    return 0


def _list_find(index: BundleIndex, pattern: str) -> int:

    if not index.appearances:
        raise BundleNotFound(
            "catalog.bin holds no readable appearance list"
            + (f" ({index.appearance_catalog_error})" if index.appearance_catalog_error else "")
            + ". Fall back to `list --grep <regex>` over bundle names."
        )
    try:
        rx = re.compile(pattern, re.IGNORECASE)
    except re.error as exc:
        raise BundleNotFound(f"--find {pattern!r} is not a valid regex: {exc}")
    hits = sorted(
        (
            e
            for e in index.appearances.values()
            if any(rx.search(spelling) for spelling in e.spellings)
        ),
        key=lambda e: (e.family, e.name),
    )
    print(
        f"{len(hits)} of {len(index.appearances)} appearance(s) in catalog.bin "
        f"matching {pattern!r}:"
    )
    for entry in hits:
        where = "on disk" if index.resolve(entry.bundle) else "NOT downloaded"
        print(f"  {entry.name:<52} {entry.kind:<15} {entry.bundle}  [{where}]")
    if not hits:
        print("  (nothing. `list --grep <regex>` searches bundle names instead.)")
    return 0


def cmd_motion(args: argparse.Namespace) -> int:
    index = make_index(args)
    total_errors = 0
    for wanted in args.appearance:
        print(f"== {wanted}")
        try:
            bundle, appearance, bundle_name = open_appearance(
                index, wanted, args.bundle, verbose=args.verbose
            )
        except AppearanceNotFound as exc:
            print(f"  FAILED: {exc}")
            total_errors += 1
            continue
        manifest = extract_appearance(
            bundle,
            appearance,
            bundle_name,
            args.out,
            motions_filter=args.motion,
            write_sidecars=not args.no_sidecars,
            include_tracks=not args.no_tracks,
        )
        _report_motion(manifest)
        total_errors += len(manifest["errors"])
    return 1 if total_errors and args.strict else 0


def _report_motion(manifest: Dict[str, Any]) -> None:
    appearance = manifest["appearance"]
    print(f"  bundle: {manifest['source']['bundle']}")
    print(f"  out:    {manifest['_outDir']}")
    flipbook_motions = [m for m in manifest["motions"] if any(c["frameCount"] for c in m["coins"])]
    print(
        f"  {len(manifest['motions'])} motion slot(s), "
        f"{len(flipbook_motions)} with flipbook frames, "
        f"{len(manifest['sprites'])} unique sprite PNG(s)"
    )
    inactive_total = 0
    for motion in manifest["motions"]:
        frames = sum(coin["frameCount"] for coin in motion["coins"])
        layers = max((coin.get("layerCount") or 0) for coin in motion["coins"]) if motion["coins"] else 0
        inactive = sum(coin.get("inactiveLayerCount") or 0 for coin in motion["coins"])
        inactive_total += inactive
        if not frames and not motion["isSpineAnim"]:
            continue
        tag = " [Spine]" if motion["isSpineAnim"] else ""
        layer_note = f"  layers {layers}" if layers > 1 else ""
        muted_note = f"  (+{inactive} muted)" if inactive else ""
        print(
            f"    {motion['motionName']:<12} slot {motion['slotIndex']:<3} "
            f"coins {len(motion['coins'])}  frames {frames}{layer_note}{muted_note}{tag}"
        )
    if inactive_total:
        print(
            f"  note: {inactive_total} muted animation layer(s) excluded from the "
            "playable frame lists (authoring alternates the game never plays) "
            "-- see inactiveLayers / inactiveTracks"
        )
    unlinked = manifest.get("unlinkedSpriteClips", {}).get("count", 0)
    if unlinked:
        print(
            f"  plus {unlinked} sprite clip(s) no timeline references "
            "(Animator-driven poses: Default/Damaged/Guard/Evade/Move/Dead) "
            "-- see unlinkedSpriteClips in appearance.json"
        )
    partial = manifest.get("partialReads", {}).get("count", 0)
    if partial:
        print(
            f"  note: {partial} object(s) needed a partial typetree read "
            "(mostly VFX clips; see partialReads in appearance.json)"
        )
    unused = manifest.get("spritesNeverDisplayed") or {}
    if unused.get("count"):
        print(
            f"  note: {unused['count']}/{unused['exportedTotal']} exported sprite(s) are "
            f"never displayed ({unused['onlyOnMutedTracks']} only on muted tracks, "
            f"{unused['outsideEveryPlayedWindow']} outside every played window) "
            "-- extra art, not lost art; see spritesNeverDisplayed"
        )
    lossy = [r for r in manifest["sprites"].values() if r.get("lossless") is False]
    if lossy:
        print(
            f"  note: {len(lossy)}/{len(manifest['sprites'])} sprite(s) were cut from a "
            "block-compressed atlas page (lossy; no lossless original ships)"
        )
    for warning in manifest["warnings"][:10]:
        print(f"  warning: {warning}")
    if len(manifest["warnings"]) > 10:
        print(f"  warning: ... and {len(manifest['warnings']) - 10} more (see appearance.json)")
    for error in manifest["errors"][:10]:
        print(f"  ERROR: {error}")
    if len(manifest["errors"]) > 10:
        print(f"  ERROR: ... and {len(manifest['errors']) - 10} more (see appearance.json)")


def cmd_vfx(args: argparse.Namespace) -> int:
    index = make_index(args)
    failures = 0
    for wanted in args.appearance:
        print(f"== {wanted}")
        try:
            bundle, appearance, bundle_name = open_appearance(
                index, wanted, args.bundle, verbose=args.verbose
            )
        except AppearanceNotFound as exc:
            print(f"  FAILED: {exc}")
            failures += 1
            continue
        manifest = extract_vfx(
            bundle,
            appearance,
            bundle_name,
            args.out,
            deep=args.deep,
            write_textures=args.textures,
        )
        _report_vfx(manifest, args.list)
    return 1 if failures and args.strict else 0


def _report_vfx(manifest: Dict[str, Any], show_list: bool) -> None:
    catalogue = manifest["catalogue"]
    imp = manifest["importability"]
    print(f"  bundle: {manifest['source']['bundle']}")
    print(f"  out:    {manifest['_outDir']}")
    print(
        f"  {catalogue['count']} effect clip(s) across "
        f"{catalogue['distinctEffects']} distinct effect(s)"
    )
    if show_list:
        for entry in catalogue["entries"]:
            flag = "  [never plays in vanilla]" if entry["neverPlaysInVanilla"] else ""
            print(
                f"    {entry['index']:>4}  {entry['key']:<46} {entry['effect']:<32} "
                f"t={entry['start']:.3f} dur={entry['duration']:.3f}{flag}"
            )
    else:
        for name, effect in sorted(manifest["effects"].items()):
            drawn = (effect.get("attackEffect") or {}).get("drawnOn", "self")
            print(
                f"    {name:<34} used {effect['clipCount']:>3}x  "
                f"{effect['particleSystems']:>3} particle system(s), "
                f"{effect['children']:>3} child object(s)  drawn on {drawn}"
            )
    if manifest["effectsNeverActivatedByAnyMotion"]:
        print(
            f"  note: {len(manifest['effectsNeverActivatedByAnyMotion'])} effect object(s) in "
            "the prefab are activated by no motion of this appearance -- see "
            "effectsNeverActivatedByAnyMotion"
        )
    print(
        f"  importability: {imp['shaderRebuildableInAnAuthoringProject']}"
        f"/{imp['materialsOnEffectRenderers']} effect material(s) use a shader that exists "
        "in an authoring project"
        + (
            f" ({imp['materialsThatCouldNotBeResolved']} material(s) live in a dependency "
            "bundle and were not read)"
            if imp["materialsThatCouldNotBeResolved"]
            else ""
        )
    )
    if manifest["textures"]:
        print(f"  wrote {len(manifest['textures'])} effect texture PNG(s) to vfx_textures/")
    for warning in manifest["warnings"][:6]:
        print(f"  warning: {warning}")
    if len(manifest["warnings"]) > 6:
        print(f"  warning: ... and {len(manifest['warnings']) - 6} more (see vfx.json)")


def cmd_spine(args: argparse.Namespace) -> int:
    index = make_index(args)
    failures = 0
    targets: List[tuple] = []

    if args.bundle:
        bundle, name = resolve_bundle_for_listing(args, index)
        targets.append((bundle, name, None))
    else:
        for wanted in args.appearance:
            try:
                bundle, appearance, bundle_name = open_appearance(
                    index, wanted, None, verbose=args.verbose
                )
                targets.append((bundle, appearance.name or bundle_name, appearance))
            except AppearanceNotFound as exc:
                print(f"== {wanted}\n  FAILED: {exc}")
                failures += 1

    for bundle, label, appearance in targets:
        print(f"== {label}")
        manifest = extract_spine(
            bundle,
            args.out,
            label,
            only=args.skeleton,
            resize_pages=not args.no_resize_pages,
            unpack_parts=args.unpack_parts,
            keep_pma_parts=args.keep_pma,
            appearance=appearance,
        )
        print(f"  out: {manifest['_outDir']}")
        print(f"  {manifest['skeletonCount']} skeleton(s)")
        skipped = manifest["skeletonsOwnedByOtherAppearancesInThisBundle"]
        if skipped:
            print(
                f"  note: {len(skipped)} rig(s) in this bundle belong to other "
                f"appearances and were skipped ({', '.join(skipped[:4])}"
                + (", ..." if len(skipped) > 4 else "")
                + "). Use --skeleton <name> to export one of them anyway."
            )
        for report in manifest["skeletons"]:
            animations = report.get("animations") or []
            print(
                f"    {report['skeletonDataAssetName']}  spine={report.get('spineVersion')} "
                f"bones={report.get('boneCount')} slots={report.get('slotCount')} "
                f"scale={report.get('scale')} animations={animations}"
            )
            for atlas in report.get("atlases", []):
                for page in atlas.get("pages", []):
                    if page.get("error"):
                        print(f"      page {page['index']}: ERROR {page['error']}")
                        continue
                    resize = " (resized to declared)" if page.get("resizedToDeclared") else ""
                    print(
                        f"      page {page['index']}: {page.get('file')} "
                        f"declared={page.get('declaredSize')} shipped={page.get('shippedSize')} "
                        f"{page.get('shippedFormat')}{resize} regions={page.get('regionCount')}"
                    )
                    parts = page.get("parts")
                    if parts:
                        print(
                            f"        parts: {parts['count']} written, alpha={parts['alphaMode']}"
                        )
                        for problem in parts.get("problems", [])[:5]:
                            print(f"        part problem: {problem}")
            for warning in report.get("warnings", []):
                print(f"      warning: {warning}")
    return 1 if failures and args.strict else 0


def cmd_index(args: argparse.Namespace) -> int:
    index = make_index(args)
    print("Scanning cached bundles (this reads every bundle it visits)...")
    result = build_container_index(index, args.filter, args.limit)
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False)
    print(
        f"  scanned {result['bundlesScanned']} bundle(s), "
        f"{result['assetPaths']} asset path(s) -> {args.out}"
    )
    for name, error in list(result["failures"].items())[:10]:
        print(f"  failed: {name}: {error}")
    return 0


GOLDEN_CLIP = {
    "appearance": "10916",
    "clipName": "Rodion_Thumb_Father_S1",
    "stopTime": 1.383333,
    "frames": [
        (0.0, "skill1_1"),
        (0.166667, "skill1_2"),
        (0.35, "skill1_3"),
        (0.516667, "skill1_4"),
        (0.666667, "skill1_5"),
        (0.783333, "skill1_6"),
        (1.216667, "skill1_7"),
        (1.366667, "skill1_8"),
    ],
}
GOLDEN_COIN = {
    "timelineName": "Rodion_Thumb_Father_S1_Timeline_1",
    "duration": 0.933333,
    "hitCheaker": 0.666667,
    "endCheaker": 0.866667,
}


GOLDEN_COIN_MOVES = [
    {
        "copyAs": "toTargetWide",
        "params": {
            "mode": "toTargetWide", "time": 0.5, "duration": 0.066,
            "arriveRadius": 0.0, "includeTargetRadius": False,
            "includeAttackerRadius": False, "chaseY": False, "refreshDir": True,
            "ease": 6, "x": 1.25, "y": 0.0, "z": 0.0, "overrideTarget": -1,
        },
    },
    {
        "copyAs": "relative",
        "params": {
            "mode": "relative", "time": 0.683333, "duration": 0.066,
            "refreshDir": True, "ease": 1, "x": -1.0, "y": 0.0, "z": 0.0,
            "yWorldZero": False,
        },
    },
]
GOLDEN_COIN_SHAKES = [
    {"time": 0.166667, "duration": 0.15, "strength": 0.25, "vibrato": 120,
     "randomness": 90.0, "fadeOut": True},
    {"time": 0.533333, "duration": 0.5, "strength": 0.5, "vibrato": 120,
     "randomness": 90.0, "fadeOut": True},
]


KNOWN_COPY_AS = {"cameraShake", "relative", "toTarget", "toTargetWide"}


ANIMATOR_POSE_MOTIONS = {"Default", "Dead", "Evade", "Guard", "Damaged", "Move"}
SPINE_MOTIONS = {"Idle"}


GOLDEN_SPRITE_NAME_COLLISIONS = {
    "skill1_5": [(665, 678), (680, 678)],
    "skill1_3": [(410, 484), (704, 567)],
}
TOLERANCE = 1e-4


class Check:
    def __init__(self) -> None:
        self.passed: List[str] = []
        self.failed: List[str] = []

    def ok(self, label: str) -> None:
        self.passed.append(label)
        print(f"  PASS  {label}")

    def bad(self, label: str, detail: str) -> None:
        self.failed.append(f"{label}: {detail}")
        print(f"  FAIL  {label}\n          {detail}")

    def check(self, condition: bool, label: str, detail: str = "") -> bool:
        if condition:
            self.ok(label)
        else:
            self.bad(label, detail)
        return condition


def _verify_golden(check: Check, manifest: Dict[str, Any]) -> None:
    record = next(
        (
            value
            for key, value in manifest["clips"].items()
            if value["clipName"] == GOLDEN_CLIP["clipName"]
        ),
        None,
    )
    if not check.check(
        record is not None,
        f"golden clip {GOLDEN_CLIP['clipName']} present",
        "clip not found in extracted manifest",
    ):
        return
    flip = record.get("flipbook")
    if not check.check(flip is not None, "golden clip has a sprite flipbook", "no sprite curve"):
        return

    frames = flip["frames"]
    check.check(
        len(frames) == len(GOLDEN_CLIP["frames"]),
        f"golden clip frame count == {len(GOLDEN_CLIP['frames'])}",
        f"got {len(frames)}",
    )
    check.check(
        abs(float(flip.get("stopTime") or 0) - GOLDEN_CLIP["stopTime"]) < 1e-3,
        f"golden clip stopTime == {GOLDEN_CLIP['stopTime']}",
        f"got {flip.get('stopTime')}",
    )
    for position, (want_time, want_sprite) in enumerate(GOLDEN_CLIP["frames"]):
        if position >= len(frames):
            check.bad(f"golden frame {position}", "missing")
            continue
        frame = frames[position]
        raw_time = frame.get("time")

        got_time = float(raw_time) if raw_time is not None else -1.0
        got_sprite = frame.get("spriteName")
        if abs(got_time - want_time) > TOLERANCE or got_sprite != want_sprite:
            check.bad(
                f"golden frame {position} == t={want_time} {want_sprite!r}",
                f"got t={got_time} {got_sprite!r}",
            )
        else:
            check.ok(f"golden frame {position}: t={want_time} {want_sprite}")

    coin = None
    for motion in manifest["motions"]:
        for candidate in motion["coins"]:
            if candidate["timelineName"] == GOLDEN_COIN["timelineName"]:
                coin = candidate
                break
    if check.check(
        coin is not None,
        f"golden coin timeline {GOLDEN_COIN['timelineName']} present",
        "timeline not found",
    ):
        check.check(
            abs(float(coin["duration"] or 0) - GOLDEN_COIN["duration"]) < 1e-3,
            f"golden coin duration == {GOLDEN_COIN['duration']}",
            f"got {coin['duration']}",
        )
        for kind, want in (("hitCheaker", GOLDEN_COIN["hitCheaker"]), ("endCheaker", GOLDEN_COIN["endCheaker"])):
            markers = coin.get("markers", {}).get(kind) or []
            got = float(markers[0]["time"]) if markers else -1.0
            check.check(
                abs(got - want) < 1e-3,
                f"golden coin {kind} marker == {want}",
                f"got {got} ({len(markers)} marker(s))",
            )


def _all_markers(manifest: Dict[str, Any]):

    for motion in manifest.get("motions") or []:
        for coin in motion.get("coins") or []:
            for group in (coin.get("markers") or {}).values():
                for marker in group or []:
                    yield motion.get("motionName"), coin.get("coinIndex"), marker


def _verify_motion_kinds(check: Check, manifest: Dict[str, Any]) -> None:

    kinds: Dict[str, str] = {}
    both: List[str] = []
    for motion in manifest["motions"]:
        name = motion["motionName"]
        spine = bool(motion.get("isSpineAnim"))
        coins = int(motion.get("coinCount") or 0)
        if spine and coins > 0:


            both.append(f"{name}: isSpineAnim with {coins} coin(s)")
        kinds[name] = "spine" if spine else ("timeline" if coins > 0 else "pose")

    check.check(
        not both,
        "no motion is both Spine and timeline-driven",
        "; ".join(both[:5]),
    )

    wrong_pose = [
        f"{name} is {kinds[name]}, expected pose"
        for name in ANIMATOR_POSE_MOTIONS & set(kinds)
        if kinds[name] != "pose"
    ]
    check.check(
        not wrong_pose,
        "Default/Dead/Evade/Guard/Damaged/Move ship no timeline (so they are filled, not overwritten)",
        "; ".join(wrong_pose)
        + "  <-- the motion template would emit a pose-shaped declaration (one slot at index 0, no timing) "
          "for a motion that actually has coins, and under-fill it",
    )

    wrong_spine = [
        f"{name} is {kinds[name]}, expected spine"
        for name in SPINE_MOTIONS & set(kinds)
        if kinds[name] != "spine"
    ]
    check.check(not wrong_spine, "Idle is Spine skeletal", "; ".join(wrong_spine))

    timeline_names = sorted(n for n, k in kinds.items() if k == "timeline")
    check.check(
        bool(timeline_names),
        "the identity has at least one timeline-driven motion to author",
        "none -- nothing in this appearance could be modded",
    )


    unresolved: List[str] = []
    for motion in manifest["motions"]:
        for coin in motion["coins"]:
            for layer in coin.get("layers") or []:
                if not layer.get("bindingPathName"):
                    unresolved.append(
                        f"{motion['motionName']} coin {coin['coinIndex']} hash {layer.get('bindingPath')}"
                    )
    check.check(
        not unresolved,
        "every playable layer's binding hash reverses to a transform path",
        f"{len(unresolved)} unresolved: " + "; ".join(unresolved[:4]),
    )
    print(f"        motion kinds: {sum(1 for k in kinds.values() if k == 'timeline')} timeline, "
          f"{sum(1 for k in kinds.values() if k == 'spine')} spine, "
          f"{sum(1 for k in kinds.values() if k == 'pose')} pose")


    sprites = manifest.get("sprites") or {}
    no_size = [
        name
        for name, rec in sprites.items()
        if not (rec.get("pixelSize") or {}).get("w") or not (rec.get("pixelSize") or {}).get("h")
    ]
    check.check(
        not no_size,
        "every sprite records its pixel size (replacement art is measured against it)",
        f"{len(no_size)} without pixelSize: " + ", ".join(no_size[:5]),
    )


    unlinked = manifest.get("unlinkedSpriteClips") or {}
    clips = unlinked.get("clips") or []
    single = [c for c in clips if len(c.get("frames") or []) == 1]
    bad_pose: List[str] = []
    for clip in single:
        frame = clip["frames"][0]
        if not frame.get("file"):
            bad_pose.append(f"{clip['clipName']}: no image file")
        elif not isinstance((frame.get("pivot") or {}).get("x"), (int, float)):
            bad_pose.append(f"{clip['clipName']}: no pivot")
        elif not isinstance(frame.get("ppu"), (int, float)):
            bad_pose.append(f"{clip['clipName']}: no ppu")
    check.check(
        not bad_pose,
        "every single-frame pose clip carries an image, a pivot and a ppu",
        "; ".join(bad_pose[:5]),
    )


    matched = {
        pose
        for pose in ANIMATOR_POSE_MOTIONS & set(kinds)
        for clip in single
        if clip["clipName"].lower().endswith("_" + pose.lower())
        or clip["clipName"].lower() == pose.lower()
    }
    unmatched = sorted((ANIMATOR_POSE_MOTIONS & set(kinds)) - matched)
    print(
        f"        pose reference clips: {len(matched)} of {len(ANIMATOR_POSE_MOTIONS & set(kinds))} poses "
        f"have one" + (f"; none found for {', '.join(unmatched)}" if unmatched else "")
    )


def _verify_copy_specs(check: Check, manifest: Dict[str, Any], golden: bool) -> None:

    tagged = untagged = 0
    unknown: List[str] = []
    no_params: List[str] = []
    bad_mode: List[str] = []
    for motion_name, coin_index, marker in _all_markers(manifest):
        kind = marker.get("kind") or ""
        if kind not in ("cameraShake",) and not kind.startswith("move"):
            continue
        where = f"{motion_name} coin {coin_index} {marker.get('name')!r}"
        copy_as = marker.get("copyAs")
        if copy_as is None:
            untagged += 1
            if "copySkipReason" not in marker:
                no_params.append(f"{where}: refused without saying why")
            continue
        tagged += 1
        if copy_as not in KNOWN_COPY_AS:
            unknown.append(f"{where}: copyAs={copy_as!r}")
            continue
        params = marker.get("copyParams")
        if not isinstance(params, dict) or not isinstance(params.get("time"), (int, float)):
            no_params.append(f"{where}: copyAs={copy_as} with no usable copyParams")
            continue
        if copy_as == "cameraShake":
            continue


        if params.get("mode") != copy_as:
            bad_mode.append(f"{where}: copyAs={copy_as} but mode={params.get('mode')!r}")

    check.check(tagged > 0, "presentation markers carry copyAs tags", "none tagged")
    check.check(not unknown, "every copyAs is one the generator writes", "; ".join(unknown[:5]))
    check.check(not no_params, "every tagged marker carries usable copyParams", "; ".join(no_params[:5]))
    check.check(not bad_mode, "every movement's copyParams.mode matches its copyAs", "; ".join(bad_mode[:5]))
    print(f"        presentation markers: {tagged} copied, {untagged} refused with a reason")

    if not golden:
        return
    coin = None
    for motion in manifest["motions"]:
        for candidate in motion["coins"]:
            if candidate["timelineName"] == GOLDEN_COIN["timelineName"]:
                coin = candidate
    if not check.check(coin is not None, "golden coin present for presentation check", "not found"):
        return

    moves = [
        m
        for group in (coin.get("markers") or {}).values()
        for m in group
        if m.get("copyAs") in ("relative", "toTarget", "toTargetWide")
    ]
    moves.sort(key=lambda m: m["copyParams"]["time"])
    if check.check(
        len(moves) == len(GOLDEN_COIN_MOVES),
        f"golden coin has {len(GOLDEN_COIN_MOVES)} copyable movement(s)",
        f"got {len(moves)}",
    ):
        for position, want in enumerate(GOLDEN_COIN_MOVES):
            got = moves[position]
            if got.get("copyAs") != want["copyAs"]:
                check.bad(
                    f"golden movement {position} copyAs == {want['copyAs']}",
                    f"got {got.get('copyAs')!r} -- the wrong marker class would be built",
                )
                continue
            wrong = _diff_params(want["params"], got.get("copyParams") or {})
            check.check(
                not wrong,
                f"golden movement {position} ({want['copyAs']}) carries the original's parameters",
                "; ".join(wrong),
            )

    shakes = [
        m
        for group in (coin.get("markers") or {}).values()
        for m in group
        if m.get("copyAs") == "cameraShake"
    ]
    shakes.sort(key=lambda m: m["copyParams"]["time"])
    if check.check(
        len(shakes) == len(GOLDEN_COIN_SHAKES),
        f"golden coin has {len(GOLDEN_COIN_SHAKES)} camera shake(s)",
        f"got {len(shakes)}",
    ):
        for position, want in enumerate(GOLDEN_COIN_SHAKES):
            wrong = _diff_params(want, shakes[position].get("copyParams") or {})
            check.check(
                not wrong,
                f"golden camera shake {position} carries the original's parameters",
                "; ".join(wrong),
            )


def _diff_params(want: Dict[str, Any], got: Dict[str, Any]) -> List[str]:
    problems: List[str] = []
    for key, expected in want.items():
        actual = got.get(key, "<missing>")
        if isinstance(expected, bool) or isinstance(actual, bool):
            same = expected is actual
        elif isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
            same = abs(float(expected) - float(actual)) < 1e-3
        else:
            same = expected == actual
        if not same:
            problems.append(f"{key}={actual!r} (want {expected!r})")
    return problems


def _verify_sprite_identity(check: Check, manifest: Dict[str, Any], golden: bool) -> None:

    records = manifest.get("sprites") or {}
    owner: Dict[Any, str] = {}
    duplicate: List[str] = []
    missing_id: List[str] = []
    for filename, record in records.items():
        path_id = record.get("spritePathID")
        if path_id is None:
            missing_id.append(filename)
            continue
        if path_id in owner:
            duplicate.append(f"PathID {path_id} claimed by {owner[path_id]} and {filename}")
        owner[path_id] = filename
    check.check(not missing_id, "every exported sprite records its PathID", "; ".join(missing_id[:5]))
    check.check(
        not duplicate,
        "one file per Sprite PathID (the index is injective)",
        "; ".join(duplicate[:5]),
    )

    unresolved: List[str] = []
    mismatched: List[str] = []
    without_id: List[str] = []
    frames_checked = 0
    for motion in manifest.get("motions") or []:
        for coin in motion.get("coins") or []:
            for layer in (coin.get("layers") or []) + (coin.get("inactiveLayers") or []):
                for frame in layer.get("frames") or []:
                    filename = (frame.get("file") or "").rsplit("/", 1)[-1]
                    if not filename:
                        continue
                    frames_checked += 1
                    record = records.get(filename)
                    if record is None:
                        unresolved.append(f"{motion['motionName']}: {filename} not in the sprite index")
                        continue
                    if frame.get("spritePathID") is None:
                        without_id.append(f"{motion['motionName']}: {filename}")
                        continue
                    if record.get("spritePathID") != frame.get("spritePathID"):
                        mismatched.append(
                            f"{motion['motionName']}: frame wants {frame.get('spritePathID')} "
                            f"but {filename} is {record.get('spritePathID')}"
                        )
    check.check(not unresolved, "every frame's file is in the sprite index", "; ".join(unresolved[:5]))
    check.check(not without_id, "every frame records the Sprite PathID it needs", "; ".join(without_id[:5]))
    check.check(
        not mismatched,
        f"every frame's file IS the sprite it asks for by PathID ({frames_checked} frames)",
        "; ".join(mismatched[:5]),
    )

    if not golden:
        return

    by_name: Dict[str, List[Dict[str, Any]]] = {}
    for record in records.values():
        by_name.setdefault(str(record.get("spriteName") or ""), []).append(record)
    for name, want_sizes in GOLDEN_SPRITE_NAME_COLLISIONS.items():
        group = by_name.get(name) or []
        got_sizes = sorted(
            (int((r.get("pixelSize") or {}).get("w") or 0), int((r.get("pixelSize") or {}).get("h") or 0))
            for r in group
        )
        files = {r.get("file") for r in group}
        pivots = {(r.get("pivot") or {}).get("y") for r in group}
        check.check(
            got_sizes == sorted(want_sizes) and len(files) == len(group) and len(pivots) == len(group),
            f"the two Sprites named {name!r} export as separate files with their own pivots",
            f"sizes {got_sizes} (want {sorted(want_sizes)}), {len(files)} file(s), {len(pivots)} pivot(s)",
        )


def _verify_pngs(check: Check, manifest: Dict[str, Any], expect_source: Optional[str]) -> None:
    from PIL import Image

    out_dir = manifest["_outDir"]
    records = manifest["sprites"]
    if not check.check(bool(records), "at least one sprite PNG written", "none written"):
        return

    bad_files: List[str] = []
    flat_alpha: List[str] = []
    wrong_size: List[str] = []
    sources = {}
    for filename, record in records.items():
        sources[record.get("source")] = sources.get(record.get("source"), 0) + 1
        path = os.path.join(out_dir, "sprites", filename)
        if not os.path.isfile(path):
            bad_files.append(f"{filename} missing on disk")
            continue
        try:
            with Image.open(path) as image:
                image.load()
                if image.mode != "RGBA":
                    bad_files.append(f"{filename} mode={image.mode}")
                declared = record.get("pixelSize") or {}
                if declared and tuple(image.size) != (declared.get("w"), declared.get("h")):
                    wrong_size.append(f"{filename} {image.size} != {declared}")
                alpha = image.getchannel("A")
                lo, hi = alpha.getextrema()
                if lo == hi:
                    flat_alpha.append(f"{filename} alpha flat at {lo}")
        except Exception as exc:
            bad_files.append(f"{filename} failed to open: {exc}")

    check.check(not bad_files, "every sprite PNG opens as RGBA", "; ".join(bad_files[:5]))
    check.check(not wrong_size, "PNG sizes match the manifest", "; ".join(wrong_size[:5]))
    check.check(
        not flat_alpha,
        "no sprite has a flat alpha channel (a flat cut means a bad rect)",
        "; ".join(flat_alpha[:5]),
    )
    print(f"        sprite sources: {sources}")
    if expect_source:
        check.check(
            sources.get(expect_source, 0) > 0,
            f"exercised the {expect_source!r} sprite path",
            f"no {expect_source} sprites; got {sources}",
        )


def _verify_vfx(check: Check, manifest: Dict[str, Any], run_golden: bool) -> None:

    catalogue = manifest["catalogue"]
    entries = catalogue["entries"]
    if not check.check(bool(entries), "vfx: catalogued at least one effect clip", "none found"):
        return
    check.check(
        all(e["index"] == n + 1 for n, e in enumerate(entries)),
        "vfx: `index` is the 1-based position in the catalogue walk",
        "index does not match position",
    )
    check.check(
        len({e["key"] for e in entries}) == len(entries),
        "vfx: every catalogue key is unique",
        f"{len(entries) - len({e['key'] for e in entries})} duplicate key(s)",
    )
    check.check(
        all(e["copyParams"]["effect"] == e["key"] for e in entries),
        "vfx: every copyParams names the key, never the fragile index",
        "a copyParams disagrees with its key",
    )
    described = set(manifest["effects"])
    labels = {e["effect"] for e in entries}
    print(
        f"        {len(entries)} clip(s), {len(labels)} distinct effect(s), "
        f"{len(described)} joined to a prefab object, "
        f"{manifest['importability']['shaderRebuildableInAnAuthoringProject']}"
        f"/{manifest['importability']['materialsOnEffectRenderers']} material(s) rebuildable"
    )
    if not run_golden:
        return
    golden = entries[0]
    check.check(
        golden["key"] == "S1/0/Effect Activate Timeline Track/0"
        and golden["effect"] == "Trail1_1_B",
        "vfx: 10916's first catalogue entry is the known key/effect pair",
        f"got {golden['key']!r} -> {golden['effect']!r}",
    )
    check.check(
        any(
            e["effect"] == "Damage1"
            and (manifest["effects"].get("Damage1") or {}).get("attackEffect", {}).get("drawnOn")
            == "target"
            for e in entries
        ),
        "vfx: 10916's Damage1 is read as an on-target effect",
        "Damage1 missing or not EFFECT_POSITION_TYPE.ENEMY",
    )


def cmd_verify(args: argparse.Namespace) -> int:
    check = Check()
    try:
        index = make_index(args)
    except BundleNotFound as exc:
        print(f"  FAIL  locate install: {exc}")
        return 1
    check.ok(f"located install {index.game_dir}")
    check.ok(f"located cache {index.cache_dir}")
    check.check(
        len(index.names) > 1000,
        "catalog.bin yielded a plausible bundle list",
        f"only {len(index.names)} names parsed",
    )

    out_root = args.out
    targets = [
        ("10916", "loose", True),
        ("10915", "atlas", False),
    ]
    targets.extend((extra, None, False) for extra in args.also)

    for wanted, expect_source, run_golden in targets:
        print(f"\n-- {wanted} ({expect_source or 'any'} sprite path)")
        try:
            bundle, appearance, bundle_name = open_appearance(index, wanted, None)
        except AppearanceNotFound as exc:
            check.bad(f"open {wanted}", str(exc))
            continue
        check.ok(f"opened {appearance.name} from {bundle_name}")
        try:
            manifest = extract_appearance(
                bundle, appearance, bundle_name, out_root, include_tracks=True
            )
        except Exception as exc:
            check.bad(f"extract {wanted}", f"{type(exc).__name__}: {exc}")
            continue
        frame_total = sum(
            coin["frameCount"] for motion in manifest["motions"] for coin in motion["coins"]
        )
        check.check(frame_total > 0, f"{wanted}: extracted flipbook frames", "zero frames")
        _verify_pngs(check, manifest, expect_source)
        _verify_sprite_identity(check, manifest, run_golden)
        _verify_copy_specs(check, manifest, run_golden)
        _verify_motion_kinds(check, manifest)
        if run_golden:
            _verify_golden(check, manifest)
        try:
            _verify_vfx(
                check,
                extract_vfx(bundle, appearance, bundle_name, out_root),
                run_golden,
            )
        except Exception as exc:
            check.bad(f"vfx catalogue {wanted}", f"{type(exc).__name__}: {exc}")
        if manifest["errors"]:


            print(f"        {len(manifest['errors'])} non-fatal error(s) recorded in appearance.json")
            for error in manifest["errors"][:3]:
                print(f"          {error}")

        print(f"-- {wanted}: spine export")
        try:
            spine_manifest = extract_spine(
                bundle,
                out_root,
                appearance.name,
                unpack_parts=args.unpack_parts,
                appearance=appearance,
            )
        except Exception as exc:
            check.bad(f"spine {wanted}", f"{type(exc).__name__}: {exc}")
            continue
        check.check(
            spine_manifest["skeletonCount"] > 0,
            f"{wanted}: found Spine skeletons",
            "none found",
        )
        versions = {r.get("spineVersion") for r in spine_manifest["skeletons"]}
        check.check(
            versions and all(str(v or "").startswith("4.0") for v in versions),
            f"{wanted}: skeleton data is Spine 4.0.x",
            f"got {versions}",
        )
        for report in spine_manifest["skeletons"]:
            for atlas in report.get("atlases", []):
                for page in atlas.get("pages", []):
                    if page.get("error"):
                        check.bad(
                            f"{wanted}: spine page {page['index']}", page["error"]
                        )
                        continue
                    declared = page.get("declaredSize")
                    if declared and page.get("resizedToDeclared"):
                        check.ok(
                            f"{wanted}: page {page.get('file')} resized "
                            f"{page.get('shippedSize')} -> {declared}"
                        )

    print("\n=========================================")
    print(f"  {len(check.passed)} passed, {len(check.failed)} failed")
    for failure in check.failed:
        print(f"  FAILED: {failure}")
    return 1 if check.failed else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="limbus_extract.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Extract Limbus Company sprites and Spine assets from local bundles.",
        epilog=(
            "Typical use:\n"
            "  # what motions does Rodion 'Thumb Father' actually have?\n"
            "  python limbus_extract.py list 10916\n\n"
            "  # extract every flipbook motion: frame PNGs + manifest + motions sidecars\n"
            "  python limbus_extract.py motion 10916 --out ./out\n\n"
            "  # extract its Spine rigs (idle + illustration), import-ready\n"
            "  python limbus_extract.py spine 10916 --out ./out --unpack-parts\n\n"
            "  # prove the extraction is right against known-good values\n"
            "  python limbus_extract.py verify --out ./verify-out\n"
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)


    listing = subparsers.add_parser(
        "list",
        help="Enumerate appearances, motions, coins and clip names",
        description=(
            "Filenames LIE about which motion they hold -- the timeline in slot S5 "
            "of Rodion 'Thumb Father' contains a clip named 'Rodion_Thumb_Father_S2'. "
            "This shows the real slot -> motion -> coin -> clip mapping, which is the "
            "only authority."
        ),
    )
    listing.add_argument("appearance", nargs="?", help="appearance id (10916) or name")
    listing.add_argument(
        "--find",
        help="instead, search every appearance catalog.bin ships -- sinners, "
        "enemies, abnormalities, EGO, dead scenes -- by id or name, and print "
        "the bundle each one lives in",
    )
    listing.add_argument("--grep", help="instead, list catalog bundle names matching a regex")
    listing.add_argument(
        "--container", action="store_true", help="also print the bundle's asset paths"
    )
    listing.add_argument("-v", "--verbose", action="store_true")
    add_source_args(listing)
    listing.set_defaults(func=cmd_list)


    motion = subparsers.add_parser(
        "motion",
        help="Extract flipbook motions: frame PNGs + manifest + motions sidecars",
        description=(
            "Writes, per appearance:\n"
            "  sprites/*.png       every unique frame image, deduped\n"
            "  sprites/index.json  per-frame pivot, ppu, size, source, losslessness\n"
            "  motions/<M>.json    a motions-mod compatible sidecar per motion\n"
            "  appearance.json     the full manifest: per motion, per coin, the frame\n"
            "                      list ({frame,time,spriteName,pivot,ppu}) plus the\n"
            "                      timeline composition -- clip start/duration/clipIn,\n"
            "                      camera / FX / FMOD track times, and the gameplay\n"
            "                      marker times (GiveDamage, HitCheaker, EndCheaker)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    motion.add_argument("appearance", nargs="+", help="one or more appearance ids or names")
    motion.add_argument("--out", default="./out", help="output root (default ./out)")
    motion.add_argument(
        "--motion",
        action="append",
        help="only this motion, by name (S1, Idle, ...). Repeatable.",
    )
    motion.add_argument(
        "--no-sidecars", action="store_true", help="skip the motions-mod JSON sidecars"
    )
    motion.add_argument(
        "--no-tracks",
        action="store_true",
        help="omit the full per-coin track dump from appearance.json (smaller file)",
    )
    motion.add_argument(
        "--strict", action="store_true", help="exit non-zero if anything failed"
    )
    motion.add_argument("-v", "--verbose", action="store_true")
    add_source_args(motion)
    motion.set_defaults(func=cmd_motion)


    vfx = subparsers.add_parser(
        "vfx",
        help="Catalogue the character's own visual effects, as mod.json addresses them",
        description=(
            "Writes vfx.json: every effect clip the appearance owns, with the EXACT `effect` "
            "key a Limbonia mod.json vfx entry takes (and the 1-based `index` it also "
            "accepts), plus what each effect is made of -- particle systems, materials, "
            "shaders, textures, and whether the game draws it on the attacker or on the "
            "target.\n\n"
            "This exists because Limbonia can REUSE a character's own effects with no asset "
            "at all, and the runtime pick-list only fills once that character has been in a "
            "battle. This is the same walk, done offline.\n\n"
            "It is NOT an importer, and cannot be: run over every appearance on disk (369 of "
            "them), 10 of the 8,842 materials on effect renderers use a shader an authoring "
            "project has. The rest are game-authored (Fx_Team/*, Shader Graphs/*) and ship "
            "compiled -- there is no source to import."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    vfx.add_argument("appearance", nargs="+", help="one or more appearance ids or names")
    vfx.add_argument("--out", default="./out", help="output root (default ./out)")
    vfx.add_argument(
        "--list",
        action="store_true",
        help="print every catalogue entry instead of the per-effect summary",
    )
    vfx.add_argument(
        "--deep",
        action="store_true",
        help="also record per-ParticleSystem settings (lifetime, speed, size, modules)",
    )
    vfx.add_argument(
        "--textures",
        action="store_true",
        help="write the textures the effect materials reference as PNGs",
    )
    vfx.add_argument("--strict", action="store_true", help="exit non-zero if anything failed")
    vfx.add_argument("-v", "--verbose", action="store_true")
    add_source_args(vfx)
    vfx.set_defaults(func=cmd_vfx)


    spine = subparsers.add_parser(
        "spine",
        help="Export Spine skeletons: skeleton JSON + .atlas + page PNGs",
        description=(
            "Import-ready triples. Pages are resized back to the size DECLARED in the "
            ".atlas by default, because Unity power-of-two-rescaled most of them at "
            "import and region cuts land in the wrong place otherwise. Pages stay "
            "premultiplied (pma:true) so a spine-unity import looks right; "
            "--unpack-parts additionally writes loose per-region PNGs with alpha "
            "un-premultiplied for editing.\n\n"
            "Given an appearance, only rigs that appearance owns are exported: a "
            "shared enemy or abnormality bundle holds a dozen characters' rigs and "
            "handing you all of them under one name is not an export. --skeleton "
            "overrides that; --bundle exports everything in the bundle."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    spine.add_argument("appearance", nargs="*", help="appearance ids or names")
    spine.add_argument("--out", default="./out", help="output root (default ./out)")
    spine.add_argument(
        "--skeleton", action="append", help="only skeletons whose name contains this"
    )
    spine.add_argument(
        "--unpack-parts",
        action="store_true",
        help="also cut the atlas into loose per-region PNGs (un-premultiplied)",
    )
    spine.add_argument(
        "--keep-pma",
        action="store_true",
        help="with --unpack-parts, leave parts premultiplied as shipped",
    )
    spine.add_argument(
        "--no-resize-pages",
        action="store_true",
        help="write pages at their shipped size instead of the declared size",
    )
    spine.add_argument("--strict", action="store_true")
    spine.add_argument("-v", "--verbose", action="store_true")
    add_source_args(spine)
    spine.set_defaults(func=cmd_spine)


    indexer = subparsers.add_parser(
        "index",
        help="Build an asset-path -> bundle map by scanning cached bundles",
        description=(
            "For assets other than appearances: catalog.bin already names the bundle "
            "of every appearance the game ships, so `list --find` answers that "
            "instantly. A full sweep here reads the whole ~15 GB cache, so narrow it "
            "with --filter."
        ),
    )
    indexer.add_argument("--out", default="./appearance_index.json")
    indexer.add_argument("--filter", help="regex over bundle base names")
    indexer.add_argument("--limit", type=int, help="stop after N bundles")
    add_source_args(indexer)
    indexer.set_defaults(func=cmd_index)


    verify = subparsers.add_parser(
        "verify",
        help="Self-check the extraction against known-good values",
        description=(
            "Structural verification, since the result cannot be opened in Unity from "
            "here. Re-derives Rodion 10916 S1 from a cold read and asserts the eight "
            "frame times and sprite names, the coin duration and the HitCheaker / "
            "EndCheaker marker times; checks every PNG opens as RGBA at the recorded "
            "size with a non-flat alpha channel; and exercises BOTH sprite paths by "
            "running a known loose-texture identity (10916) and a known atlas-only one "
            "(10915)."
        ),
    )
    verify.add_argument("--out", default="./verify-out")
    verify.add_argument(
        "--also", action="append", default=[], help="extra appearance to run. Repeatable."
    )
    verify.add_argument("--unpack-parts", action="store_true")
    add_source_args(verify)
    verify.set_defaults(func=cmd_verify)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    init_stdout()
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except (BundleNotFound, AppearanceNotFound) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
