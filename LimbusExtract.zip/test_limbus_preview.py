import unittest

from limbus_preview import frame_spans


class TimelineDrawingTests(unittest.TestCase):
    def test_non_looping_parry_tail_holds_the_last_drawing_past_source_end(self):
        keys = [dict(time=0, spritePathID=11), dict(time=2.4, spritePathID=22)]
        spans = list(frame_spans(keys, start=0, duration=.8, clip_in=2.35, speed=1))
        self.assertEqual([s[2]['spritePathID'] for s in spans], [11, 22])
        self.assertAlmostEqual(sum(s[1] for s in spans), .8)

    def test_trim_starts_inside_held_drawing_and_speed_maps_to_director_time(self):
        keys = [dict(time=0, spritePathID=11), dict(time=1, spritePathID=22), dict(time=2, spritePathID=11)]
        spans = list(frame_spans(keys, start=3, duration=1, clip_in=.5, speed=2))
        self.assertEqual([(t, d, k['spritePathID']) for t, d, k in spans],
                         [(3, .25, 11), (3.25, .5, 22), (3.75, .25, 11)])

    def test_terminal_sprite_key_has_no_display_span(self):
        keys = [dict(time=0, spritePathID=11), dict(time=1, spritePathID=22)]
        spans = list(frame_spans(keys, start=0, duration=1, clip_in=0, speed=1))
        self.assertEqual([(t, d, k['spritePathID']) for t, d, k in spans], [(0, 1, 11)])


if __name__ == '__main__':
    unittest.main()
