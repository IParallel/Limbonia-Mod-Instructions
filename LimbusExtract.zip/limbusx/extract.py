from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Tuple

from . import clips as clipmod
from . import hierarchy as hierarchymod
from . import motionsjson, spine as spinemod, timeline as timelinemod
from .appearance import (
    Appearance,
    animator_clip_ids,
    claimed_by_siblings,
    find_appearances,
    match_appearance,
    shared_timeline_report,
    spine_skeleton_ids,
)
from .env import Bundle, load_bundle
from .images import SpriteExporter
from .locate import (
    APPEARANCE_FAMILIES,
    BundleIndex,
    CatalogAppearance,
    iter_candidate_paths,
    sd_sweep_bundles,
)

TOOL_NAME = "LimbusExtract"
TOOL_VERSION = "1.0.0"


class AppearanceNotFound(Exception):
    pass


def open_appearance(
    index: BundleIndex,
    wanted: str,
    bundle_override: Optional[str] = None,
    verbose: bool = False,
) -> Tuple[Bundle, Appearance, str]:

    if bundle_override:
        if os.path.isfile(bundle_override):
            candidates = [(bundle_override, os.path.basename(bundle_override))]
        else:
            hit = index.resolve(bundle_override)
            if not hit:
                raise AppearanceNotFound(
                    f"--bundle {bundle_override!r} is neither a file nor a bundle "
                    "name present in catalog.bin"
                )
            candidates = [hit]
        opened, _tried = _open_first_match(candidates, wanted, verbose)
        if opened:
            return opened
        raise AppearanceNotFound(
            f"{wanted!r} is not in {bundle_override}.\n"
            f"  What that bundle does hold:  list --bundle {bundle_override}\n"
            f"  Where the catalog puts it:   list --find {wanted}"
        )

    known = index.catalog_lookup(wanted)
    uncached: List[CatalogAppearance] = []
    unreadable: List[Tuple[CatalogAppearance, str]] = []
    for entry in known:
        hit = index.resolve(entry.bundle)
        if hit is None:
            uncached.append(entry)
            continue
        if verbose:
            print(f"  catalog: {entry.key} -> {entry.bundle}")
        path, bundle_name = hit
        bundle = load_bundle(path, bundle_name)
        appearances = find_appearances(bundle)


        found = match_appearance(appearances, wanted) or match_appearance(
            appearances, entry.name
        )
        if found is not None:
            return bundle, found, bundle_name
        if entry.asset_path in bundle.container():


            unreadable.append((entry, bundle_name))

    if uncached or unreadable:


        raise AppearanceNotFound(
            _not_found_message(index, wanted, [], uncached, unreadable)
        )


    appearance_id = int(wanted) if wanted.isdigit() else None
    sweep = list(iter_candidate_paths(index, appearance_id))
    sweep.extend(iter_candidate_paths(index, None, sd_sweep_bundles(index)))
    opened, tried = _open_first_match(sweep, wanted, verbose)
    if opened:
        return opened
    raise AppearanceNotFound(_not_found_message(index, wanted, tried, []))


def _open_first_match(
    candidates: List[Tuple[str, str]], wanted: str, verbose: bool
) -> Tuple[Optional[Tuple[Bundle, Appearance, str]], List[str]]:
    tried: List[str] = []
    seen = set()
    for path, bundle_name in candidates:
        if path in seen:
            continue
        seen.add(path)
        tried.append(bundle_name)
        if verbose:
            print(f"  trying {bundle_name}")
        bundle = load_bundle(path, bundle_name)
        hit = match_appearance(find_appearances(bundle), wanted)
        if hit is not None:
            return (bundle, hit, bundle_name), tried
    return None, tried


def _not_found_message(
    index: BundleIndex,
    wanted: str,
    tried: List[str],
    uncached: List[CatalogAppearance],
    unreadable: List[Tuple[CatalogAppearance, str]] = (),
) -> str:

    lines: List[str] = []

    if unreadable:
        entry, _bundle_name = unreadable[0]
        lines.append(
            f"{entry.name} is in {entry.bundle}, exactly where catalog.bin puts "
            "it, but that prefab carries no SD.CharacterAppearance component -- "
            f"it is a {entry.kind}, and this tool reads motions off a "
            "`motionList`, which it has none of."
        )
        if entry.family == "SD_DeadScene":
            lines.append(
                "  Dead-scene prefabs are a Spine rig plus a dead-scene "
                f"component. Export the rigs:  spine --bundle {entry.bundle}"
            )
        else:
            lines.append(f"  What that bundle does hold:  list --bundle {entry.bundle}")
        return "\n".join(lines)

    if uncached:

        entry = uncached[0]
        lines.append(
            f"{wanted!r} is {entry.name} ({entry.kind}), which catalog.bin puts in "
            f"{entry.bundle} -- and that bundle is not in your Addressables cache."
        )
        lines.append(
            "  Extraction reads only what the game has already downloaded. Load "
            "that content once in game (the stage, the Mirror Dungeon floor, the "
            "character's own screen), then run this again."
        )
        return "\n".join(lines)

    catalog = index.appearances
    if not catalog:
        lines.append(
            f"{wanted!r} not found, and catalog.bin could not be read for the "
            "appearance list"
            + (
                f" ({index.appearance_catalog_error})"
                if index.appearance_catalog_error
                else ""
            )
            + f". Swept {len(tried)} bundle(s) by name instead."
        )
        lines.append("  Pick a bundle yourself:  list --grep <regex>  then  --bundle <name>")
        return "\n".join(lines)

    families = index.appearance_families()
    breakdown = ", ".join(
        f"{count} {APPEARANCE_FAMILIES.get(family, family)}"
        for family, count in sorted(families.items(), key=lambda pair: -pair[1])
    )
    lines.append(
        f"no appearance {wanted!r} in catalog.bin ({len(catalog)} appearances: "
        f"{breakdown}), and none of the {len(tried)} bundle(s) swept afterwards "
        "holds one."
    )

    nearest = index.nearest_appearance_ids(wanted)
    if nearest:
        lines.append("  Nearest ids in the catalog:")
        for entry in nearest:
            lines.append(f"    {entry.name}  ({entry.kind}, {entry.bundle})")
        lines.append(
            "  Enemy and abnormality UNIT ids are not appearance ids -- a unit "
            "points at an appearance, and the two numbers differ for plenty of "
            "them. Only the ids above address art."
        )

    hint = wanted[:-1] if wanted.isdigit() and len(wanted) > 2 else wanted
    lines.append(f"  Search the catalog by id or name:  list --find {hint}")
    lines.append("  Or open a bundle directly:         list --bundle <name>")
    return "\n".join(lines)


def list_bundle(bundle: Bundle, bundle_name: str) -> List[str]:

    lines = [f"{bundle_name}", f"  path: {bundle.path}"]
    appearances = find_appearances(bundle)
    if not appearances:
        lines.append("  (no SD.CharacterAppearance components in this bundle)")
    for appearance in appearances:
        summary = appearance.summary()
        declared = summary["declaredAppearanceId"] or "(empty)"
        lines.append("")
        lines.append(
            f"  appearance {appearance.name}"
            f"   declaredId={declared}  spineSkins={summary['spineSkinCount']}"
        )
        if summary["duplicateMotionDetails"]:
            lines.append(
                f"    note: motion detail(s) {summary['duplicateMotionDetails']} appear "
                "more than once -- slots are keyed by (slotIndex, coinIndex)"
            )
        if summary["spineDrivenMotions"]:
            lines.append(
                f"    Spine-driven motions: {', '.join(summary['spineDrivenMotions'])}"
            )
        lines.append(
            f"    {'slot':>4} {'detail':>6} {'motion':<12} {'coins':>5} {'spine':>5}  timelines"
        )
        for slot in summary["slots"]:
            name = slot["motionName"] + ("" if slot["motionNameIsKnown"] else " (?)")
            spine_flag = "yes" if slot["isSpineAnim"] else "-"
            lines.append(
                f"    {slot['slotIndex']:>4} {str(slot['motionDetail']):>6} "
                f"{name:<12} {slot['coinCount']:>5} {spine_flag:>5}"
            )
            for coin in slot["coins"]:
                timeline = timelinemod.read_timeline(bundle, coin["timelinePathID"])
                if timeline is None:
                    lines.append(
                        f"           coin {coin['coinIndex']}: "
                        f"<timeline {coin['timelinePathID']} unresolved>"
                    )
                    continue
                segments = timelinemod.animation_segments(timeline)
                if segments:
                    clip_names = []
                    for segment in segments:
                        clip_tt = bundle.tt(segment["animationClipPathID"])
                        flip = clipmod.read_flipbook(clip_tt) if clip_tt else None
                        frame_note = (
                            f", {len(flip['frames'])} frames" if flip else ", no sprite curve"
                        )
                        clip_names.append(
                            f"{segment['animationClipName']}"
                            f"[{segment['start']:.3f}+{segment['duration']:.3f}"
                            f" in={segment['clipIn']:.3f}{frame_note}]"
                        )
                    detail = "; ".join(clip_names)
                else:
                    detail = "no animation track clips"
                lines.append(
                    f"           coin {coin['coinIndex']}: {timeline['name']} "
                    f"({timeline['duration']}s, {timeline['trackCount']} tracks) {detail}"
                )
        shared = shared_timeline_report(summary["slots"])
        if shared:
            lines.append("    shared TimelineAssets (same PathID in >1 slot):")
            for path_id, users in shared.items():
                lines.append(f"      {path_id}: {', '.join(users)}")
    return lines


def extract_appearance(
    bundle: Bundle,
    appearance: Appearance,
    bundle_name: str,
    out_root: str,
    motions_filter: Optional[List[str]] = None,
    write_sidecars: bool = True,
    include_tracks: bool = True,
) -> Dict[str, Any]:

    out_dir = os.path.join(out_root, appearance.name or "appearance")
    sprites_dir = os.path.join(out_dir, "sprites")
    os.makedirs(out_dir, exist_ok=True)

    exporter = SpriteExporter(bundle)
    summary = appearance.summary()
    slots = summary["slots"]


    path_table = hierarchymod.build_path_table(bundle, appearance.tt)

    timeline_cache: Dict[int, Optional[Dict[str, Any]]] = {}
    clip_records: Dict[str, Dict[str, Any]] = {}
    warnings: List[str] = []


    clip_windows: Dict[int, List[tuple]] = {}

    wanted = {m.lower() for m in motions_filter} if motions_filter else None
    motions_out: List[Dict[str, Any]] = []

    for slot in slots:
        if wanted is not None and slot["motionName"].lower() not in wanted:
            continue
        coins_out: List[Dict[str, Any]] = []
        coin_timelines: List[Optional[Dict[str, Any]]] = []

        for coin in slot["coins"]:
            path_id = coin["timelinePathID"]
            if coin.get("timelineFileID"):
                warnings.append(
                    f"{slot['motionName']} coin {coin['coinIndex']}: timeline lives in "
                    "another bundle; skipped"
                )
                coin_timelines.append(None)
                continue
            if path_id not in timeline_cache:


                timeline_cache[path_id] = timelinemod.read_timeline(bundle, path_id)
            timeline = timeline_cache[path_id]
            coin_timelines.append(timeline)
            if timeline is None:
                warnings.append(
                    f"{slot['motionName']} coin {coin['coinIndex']}: timeline "
                    f"{path_id} could not be read"
                )
                continue


            segments = timelinemod.animation_segments(timeline)
            muted_segments = [
                s
                for s in timelinemod.animation_segments(timeline, include_muted=True)
                if s.get("trackMuted")
            ]


            layer_frames: Dict[tuple, List[Dict[str, Any]]] = {}
            inactive_layer_frames: Dict[tuple, List[Dict[str, Any]]] = {}

            for segment in segments + muted_segments:
                sink_map = (
                    inactive_layer_frames if segment.get("trackMuted") else layer_frames
                )
                clip_path_id = segment["animationClipPathID"]
                clip_tt = bundle.tt(clip_path_id)
                if not clip_tt:
                    warnings.append(
                        f"{slot['motionName']} coin {coin['coinIndex']}: animation clip "
                        f"{clip_path_id} could not be read"
                    )
                    continue
                clip_name = str(clip_tt.get("m_Name") or "")
                key = f"{clip_name}#{clip_path_id}"
                if key not in clip_records:
                    flip = clipmod.read_flipbook(clip_tt)
                    record: Dict[str, Any] = {
                        "clipName": clip_name,
                        "clipPathID": clip_path_id,
                        "describe": clipmod.describe_clip(clip_tt),
                    }
                    if flip:


                        for layer in flip.get("layers") or []:
                            for frame in layer["frames"]:
                                frame["file"] = exporter.export(
                                    frame.get("spritePathID"), sprites_dir
                                )
                                sprite_tt = bundle.tt(frame.get("spritePathID")) or {}
                                frame["spriteName"] = str(sprite_tt.get("m_Name") or "")
                        record["flipbook"] = flip
                        if flip["warnings"]:
                            warnings.extend(
                                f"clip {clip_name}: {w}" for w in flip["warnings"]
                            )


                    clip_records[key] = record

                if not segment.get("trackMuted"):
                    window_in = float(segment.get("clipIn") or 0.0)
                    scale = segment.get("timeScale")
                    scale = 1.0 if scale is None else float(scale)
                    window_len = float(segment.get("duration") or 0.0) * scale
                    clip_windows.setdefault(clip_path_id, []).append(
                        (window_in, window_in + window_len)
                    )

                flip = clip_records[key].get("flipbook")
                if not flip:
                    continue
                duration = timeline.get("duration")
                for layer in flip.get("layers") or []:


                    layer_key = (
                        segment.get("trackPathID"),
                        segment.get("track") or "",
                        layer["bindingPath"],
                    )
                    sink = sink_map.setdefault(layer_key, [])
                    for frame in timelinemod.map_frames_to_coin(
                        layer["frames"], [segment]
                    ):
                        sprite_file = frame.get("file")
                        sprite_record = (
                            exporter.records.get(sprite_file) if sprite_file else None
                        ) or {}
                        sink.append(
                            {
                                "frame": 0,
                                "time": frame["coinTime"],
                                "timeNorm": round(frame["coinTime"] / duration, 6)
                                if duration
                                else None,
                                "clipTime": frame["clipTime"],
                                "clipName": clip_records[key]["clipName"],
                                "spriteName": frame.get("spriteName") or "",


                                "spritePathID": frame.get("spritePathID"),
                                "file": f"sprites/{sprite_file}" if sprite_file else None,
                                "pivot": sprite_record.get("pivot"),
                                "ppu": sprite_record.get("ppu"),
                                "source": sprite_record.get("source"),
                                "lossless": sprite_record.get("lossless"),
                            }
                        )

            def build_layers(source: Dict[tuple, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
                built: List[Dict[str, Any]] = []
                for (track_path_id, track_name, binding_path), sequence in source.items():
                    sequence.sort(key=lambda f: f["time"])
                    for ordinal, frame in enumerate(sequence):
                        frame["frame"] = ordinal
                    built.append(
                        {
                            "track": track_name,
                            "trackPathID": track_path_id,
                            "bindingPath": binding_path,
                            "bindingPathIsCrc32": isinstance(binding_path, int),


                            "bindingPathName": hierarchymod.resolve_binding_path(
                                path_table, binding_path
                            ),
                            "frameCount": len(sequence),
                            "frames": sequence,
                        }
                    )
                built.sort(key=lambda entry: (-entry["frameCount"], str(entry["track"])))
                return built

            layers_out = build_layers(layer_frames)
            inactive_layers_out = build_layers(inactive_layer_frames)
            frames_out = layers_out[0]["frames"] if layers_out else []

            coin_record: Dict[str, Any] = {
                "coinIndex": coin["coinIndex"],
                "timelineName": timeline["name"],
                "timelinePathID": path_id,
                "duration": timeline["duration"],
                "durationMode": timeline["durationModeName"],
                "animationSegments": segments,


                "layerCount": len(layers_out),
                "layers": layers_out,
                "frameCount": len(frames_out),
                "framesAliasOfLayer": 0 if layers_out else None,
                "frames": frames_out,


                "inactiveLayerCount": len(inactive_layers_out),
                "inactiveLayers": inactive_layers_out,
                "inactiveTracks": [
                    {
                        "track": track.get("label") or track.get("name"),
                        "trackPathID": track.get("trackPathID"),
                        "kind": track.get("kind"),
                        "mutedLocally": bool(track.get("muted")),
                        "mutedByParent": bool(track.get("mutedInHierarchy"))
                        and not bool(track.get("muted")),
                        "clipCount": len(track.get("clips") or []),
                        "markerCount": len(track.get("markers") or []),
                    }
                    for track in timelinemod.inactive_tracks(timeline)
                ],
                "markers": {
                    kind: timelinemod.markers_of_kind(timeline, kind)
                    for kind in (
                        "giveDamage",
                        "hitCheaker",
                        "endCheaker",
                        "cameraShake",
                        "moveToTargetWide",
                        "moveToTarget",
                        "moveRelative",
                        "moveEnemy",
                        "moveOther",
                    )
                },
            }
            coin_record["markers"] = {
                k: v for k, v in coin_record["markers"].items() if v
            }
            if include_tracks:
                coin_record["tracks"] = timeline["tracks"]
            coins_out.append(coin_record)

        motion_record: Dict[str, Any] = {
            "slotIndex": slot["slotIndex"],
            "motionDetail": slot["motionDetail"],
            "motionName": slot["motionName"],
            "motionNameIsKnown": slot["motionNameIsKnown"],
            "isSpineAnim": slot["isSpineAnim"],
            "coinCount": slot["coinCount"],
            "motionObjectCount": slot["motionObjectCount"],
            "coins": coins_out,
        }
        motions_out.append(motion_record)

        if write_sidecars and coin_timelines and any(coin_timelines):
            sidecar_dir = os.path.join(out_dir, "motions")
            os.makedirs(sidecar_dir, exist_ok=True)
            document = motionsjson.motion_to_motions_json(coin_timelines)
            filename = f"{slot['motionName']}.json"
            if not slot["motionNameIsKnown"]:


                filename = f"{slot['motionName']}.UNMATCHED.json"
            with open(os.path.join(sidecar_dir, filename), "w", encoding="utf-8") as handle:
                json.dump(document, handle, indent=2, ensure_ascii=False)


    for record in clip_records.values():
        flip = record.get("flipbook")
        if not flip:
            continue
        windows = clip_windows.get(record["clipPathID"]) or []
        record["playedWindows"] = [
            {"clipIn": round(lo, 6), "clipEnd": round(hi, 6)} for lo, hi in sorted(windows)
        ]
        record["activeWindowCount"] = len(windows)


        record["playedByMutedTracksOnly"] = not windows
        outside: List[Dict[str, Any]] = []
        for layer in flip.get("layers") or []:
            for frame in layer["frames"]:
                time = frame.get("time")
                if time is None:
                    continue
                if not any(lo - 1e-6 <= time <= hi + 1e-6 for lo, hi in windows):
                    outside.append(
                        {
                            "clipTime": time,
                            "spriteName": frame.get("spriteName") or "",
                            "file": f"sprites/{frame['file']}" if frame.get("file") else None,
                        }
                    )


        record["framesOutsidePlayedWindows"] = outside
        record["activeCoverage"] = _coverage(flip, windows)


    linked = {record["clipPathID"] for record in clip_records.values()}
    foreign_clips = claimed_by_siblings(bundle, appearance, animator_clip_ids)
    unlinked: List[Dict[str, Any]] = []
    if motions_filter is None:
        for obj in bundle.of_type("AnimationClip"):
            if obj.path_id in linked or obj.path_id in foreign_clips:
                continue
            clip_tt = bundle.tt(obj.path_id)
            if not clip_tt:
                continue
            flip = clipmod.read_flipbook(clip_tt)
            if not flip or not flip["frames"]:
                continue
            for layer in flip.get("layers") or []:
                for frame in layer["frames"]:
                    frame["file"] = exporter.export(frame.get("spritePathID"), sprites_dir)
                    sprite_tt = bundle.tt(frame.get("spritePathID")) or {}
                    frame["spriteName"] = str(sprite_tt.get("m_Name") or "")
            unlinked.append(
                {
                    "clipName": flip["name"],
                    "clipPathID": obj.path_id,
                    "stopTime": flip["stopTime"],
                    "sampleRate": flip["sampleRate"],
                    "layerCount": flip["layerCount"],
                    "frames": [
                        {
                            "frame": ordinal,
                            "time": frame["time"],
                            "spriteName": frame.get("spriteName") or "",
                            "spritePathID": frame.get("spritePathID"),
                            "file": f"sprites/{frame['file']}" if frame.get("file") else None,
                            "pivot": (exporter.records.get(frame.get("file")) or {}).get("pivot"),
                            "ppu": (exporter.records.get(frame.get("file")) or {}).get("ppu"),
                        }
                        for ordinal, frame in enumerate(flip["frames"])
                    ],
                    "warnings": flip["warnings"],
                }
            )


            warnings.extend(f"clip {flip['name']}: {w}" for w in flip["warnings"])
        unlinked.sort(key=lambda record: record["clipName"])


    shown_active: set = set()
    shown_inactive: set = set()
    for motion in motions_out:
        for coin_record in motion["coins"]:
            for layer in coin_record.get("layers") or []:
                for frame in layer["frames"]:
                    if frame.get("file"):
                        shown_active.add(frame["file"].rsplit("/", 1)[-1])
            for layer in coin_record.get("inactiveLayers") or []:
                for frame in layer["frames"]:
                    if frame.get("file"):
                        shown_inactive.add(frame["file"].rsplit("/", 1)[-1])
    for clip_entry in unlinked:
        for frame in clip_entry["frames"]:
            if frame.get("file"):
                shown_active.add(frame["file"].rsplit("/", 1)[-1])

    never_displayed: List[Dict[str, Any]] = []
    for filename, record in exporter.records.items():
        if filename in shown_active:
            continue
        never_displayed.append(
            {
                "file": f"sprites/{filename}",
                "spriteName": record.get("spriteName"),
                "reason": "onlyOnMutedTracks"
                if filename in shown_inactive
                else "outsideEveryPlayedWindow",
            }
        )
    never_displayed.sort(key=lambda entry: (entry["reason"], entry["file"]))
    muted_only = sum(1 for e in never_displayed if e["reason"] == "onlyOnMutedTracks")


    if exporter.records:
        with open(
            os.path.join(sprites_dir, "index.json"), "w", encoding="utf-8"
        ) as handle:
            json.dump(exporter.records, handle, indent=2, ensure_ascii=False)

    manifest: Dict[str, Any] = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "source": {
            "bundle": bundle_name,
            "bundlePath": bundle.path,
            "unityVersionAssumed": "6000.3.12f1",
        },
        "appearance": {
            key: value for key, value in summary.items() if key != "slots"
        },


        "transformPaths": {str(k): v for k, v in sorted(path_table.items())},
        "sharedTimelines": shared_timeline_report(slots),
        "motions": motions_out,
        "unlinkedSpriteClips": {
            "count": len(unlinked),
            "note": (
                "Sprite clips present in the bundle that no coin timeline "
                "references -- the AnimatorController-driven poses (Default, "
                "Damaged, Guard, Evade, Move, Dead) live here, because those "
                "motionList slots carry no timeline. Clips another appearance in "
                "the same bundle owns through its own AnimatorController are "
                "excluded. Match them to a motion by clip name at your own risk: "
                "names are unreliable elsewhere in this data."
            ),
            "clipsOwnedByOtherAppearancesInThisBundle": len(foreign_clips),
            "clips": unlinked,
        },
        "clips": clip_records,
        "spritesNeverDisplayed": {
            "count": len(never_displayed),
            "exportedTotal": len(exporter.records),
            "onlyOnMutedTracks": muted_only,
            "outsideEveryPlayedWindow": len(never_displayed) - muted_only,
            "note": (
                "Images extracted for this appearance that no active coin and no "
                "Animator-driven pose ever shows. `onlyOnMutedTracks` means the "
                "only track referencing it is muted; `outsideEveryPlayedWindow` "
                "means every coin's slice of its clip skips it. Neither is lost "
                "data -- the art is on disk, the game just never draws it."
            ),
            "sprites": never_displayed,
        },
        "sprites": exporter.records,
        "warnings": warnings,
        "errors": exporter.errors
        + [f"object {pid} unreadable: {msg}" for pid, msg in bundle.read_errors.items()],
        "partialReads": {
            "count": len(bundle.partial_reads),
            "note": (
                "Objects whose strict typetree read failed and were recovered by "
                "truncating the typetree at a field boundary. Mostly "
                "EffectActivateTimelineBehaviour VFX clips losing only their "
                "trailing ExposedReference field."
            ),
            "objects": bundle.partial_reads,
        },
    }
    with open(os.path.join(out_dir, "appearance.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    manifest["_outDir"] = out_dir
    return manifest


def extract_spine(
    bundle: Bundle,
    out_root: str,
    label: str,
    only: Optional[List[str]] = None,
    resize_pages: bool = True,
    unpack_parts: bool = False,
    keep_pma_parts: bool = False,
    appearance: Optional[Appearance] = None,
) -> Dict[str, Any]:

    out_dir = os.path.join(out_root, _clean_label(label), "spine")
    os.makedirs(out_dir, exist_ok=True)
    skeletons = spinemod.find_skeletons(bundle)
    wanted = {name.lower() for name in only} if only else None
    foreign_skeletons: set = set()
    if appearance is not None and wanted is None:
        foreign_skeletons = claimed_by_siblings(bundle, appearance, spine_skeleton_ids)
    skipped: List[str] = []
    reports: List[Dict[str, Any]] = []


    name_counts: Dict[str, int] = {}
    for skeleton in skeletons:
        name = skeleton["skeletonDataAssetName"]
        if skeleton["componentPathID"] in foreign_skeletons:
            skipped.append(name)
            continue
        haystack = " ".join(
            [name]
            + [str(a.get("atlasFileName") or "") for a in skeleton.get("atlases", [])]
            + [str(skeleton.get("skeletonFileName") or "")]
        ).lower()
        if wanted is not None and not any(w in haystack for w in wanted):
            continue
        folder = spinemod._safe(name)
        seen = name_counts.get(folder, 0)
        name_counts[folder] = seen + 1
        if seen:
            folder = f"{folder}__{skeleton['componentPathID']}"
        target = os.path.join(out_dir, folder)
        report = spinemod.export_skeleton(
            bundle,
            skeleton,
            target,
            resize_pages=resize_pages,
            unpack_parts=unpack_parts,
            keep_pma_parts=keep_pma_parts,
        )
        report["dir"] = folder
        reports.append(report)
    manifest = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "source": {"bundle": bundle.label, "bundlePath": bundle.path},
        "skeletonCount": len(reports),
        "skeletons": reports,
        "skeletonsOwnedByOtherAppearancesInThisBundle": sorted(skipped),
        "pageAlphaMode": "premultiplied (pma:true) -- keep as-is for spine-unity",
    }
    with open(os.path.join(out_dir, "spine.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    manifest["_outDir"] = out_dir
    return manifest


def _coverage(flip: Dict[str, Any], windows: List[tuple]) -> Optional[Dict[str, Any]]:

    times = [
        frame["time"]
        for layer in flip.get("layers") or []
        for frame in layer["frames"]
        if frame.get("time") is not None
    ]
    if not times:
        return None
    start, stop = min(times), max(times)
    span = stop - start
    if not windows:
        return {"clipSpan": round(span, 6), "coveredSpan": 0.0, "fraction": 0.0}
    merged: List[List[float]] = []
    for lo, hi in sorted((max(lo, start), min(hi, stop)) for lo, hi in windows):
        if hi <= lo:
            continue
        if merged and lo <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    covered = sum(hi - lo for lo, hi in merged)
    return {
        "clipSpan": round(span, 6),
        "coveredSpan": round(covered, 6),
        "fraction": round(covered / span, 4) if span else 1.0,
    }


def _clean_label(label: Optional[str]) -> str:

    name = (label or "spine").strip()
    for suffix in (".bundle", "__data"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]

    parts = name.rsplit("_", 1)
    if len(parts) == 2 and len(parts[1]) == 32 and all(c in "0123456789abcdef" for c in parts[1]):
        name = parts[0]
    return name or "spine"


def build_container_index(
    index: BundleIndex, filter_pattern: Optional[str] = None, limit: Optional[int] = None
) -> Dict[str, Any]:

    import re

    inverse = {digest: name for name, digest in index.names.items()}
    rx = re.compile(filter_pattern) if filter_pattern else None
    mapping: Dict[str, str] = {}
    scanned: List[str] = []
    failures: Dict[str, str] = {}

    for data_path in index.all_cached_data_files():
        digest = os.path.basename(os.path.dirname(data_path))
        base_name = inverse.get(digest, digest)
        if rx and not rx.search(base_name):
            continue
        if limit is not None and len(scanned) >= limit:
            break
        try:
            bundle = load_bundle(data_path, base_name)
            for asset_path in bundle.container():
                mapping[asset_path] = base_name
            scanned.append(base_name)
        except Exception as exc:
            failures[base_name] = f"{type(exc).__name__}: {exc}"
    return {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "bundlesScanned": len(scanned),
        "assetPaths": len(mapping),
        "failures": failures,
        "paths": mapping,
    }
