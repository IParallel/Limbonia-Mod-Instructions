from __future__ import annotations

import collections
import json
import os
from typing import Any, Dict, List, Optional, Set, Tuple

from .appearance import Appearance
from .env import Bundle, texture_format_name


ATTACK_EFFECT_FIELDS = {"CurEffectType", "_additionalScale", "_offset", "disabletime"}
V2_MARKER_FIELD = "_effectPositionType"


EFFECT_POSITION_TYPE = {0: "NONE", 1: "CHARACTER", 2: "ENEMY", 3: "ZERO", 4: "POS"}


RENDER_MODES = {0: "Billboard", 1: "Stretch", 2: "HorizontalBillboard",
                3: "VerticalBillboard", 4: "Mesh", 5: "None"}


REBUILDABLE_SHADER_PREFIXES = (
    "Universal Render Pipeline/",
    "Particles/",
    "Sprites/",
    "Legacy Shaders/",
    "Mobile/",
    "Unlit/",
    "UI/",
    "Skybox/",
)


def _f(value: Any, ndigits: int = 6) -> Optional[float]:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if out != out or out in (float("inf"), float("-inf")):
        return None
    return round(out, ndigits)


def _v3(value: Any) -> Optional[Dict[str, float]]:
    if not isinstance(value, dict):
        return None
    return {axis: (_f(value.get(axis)) or 0.0) for axis in ("x", "y", "z")}


def shader_is_rebuildable(name: Optional[str]) -> bool:
    if not name:
        return False
    return name.startswith(REBUILDABLE_SHADER_PREFIXES)


class _Scene:


    def __init__(self, bundle: Bundle) -> None:
        self.b = bundle
        self.transforms: Dict[int, Dict[str, Any]] = {}
        for obj in bundle.of_type("Transform", "RectTransform"):
            tt = bundle.tt_of(obj)
            if tt:
                self.transforms[obj.path_id] = tt
        self.go_name: Dict[int, str] = {}
        self.go_components: Dict[int, List[int]] = collections.defaultdict(list)
        for obj in bundle.of_type("GameObject"):
            tt = bundle.tt_of(obj)
            if not tt:
                continue
            self.go_name[obj.path_id] = str(tt.get("m_Name") or "")
            for entry in tt.get("m_Component") or []:
                ref = (
                    entry.get("component")
                    if isinstance(entry, dict)
                    else (entry[1] if isinstance(entry, (list, tuple)) and len(entry) > 1 else None)
                )
                if isinstance(ref, dict) and not ref.get("m_FileID") and ref.get("m_PathID"):
                    self.go_components[obj.path_id].append(ref["m_PathID"])
        self.transform_of_go: Dict[int, int] = {}
        for tpid, tt in self.transforms.items():
            gpid = (tt.get("m_GameObject") or {}).get("m_PathID")
            if gpid:
                self.transform_of_go[gpid] = tpid
        self.shader_names: Dict[int, str] = {}
        for obj in bundle.of_type("Shader"):
            tt = bundle.tt_of(obj)
            parsed = (tt or {}).get("m_ParsedForm") or {}
            self.shader_names[obj.path_id] = str(parsed.get("m_Name") or (tt or {}).get("m_Name") or "")

    def children(self, go_pid: int) -> List[int]:
        tt = self.transforms.get(self.transform_of_go.get(go_pid, -1)) or {}
        out = []
        for ref in tt.get("m_Children") or []:
            cpid = (ref or {}).get("m_PathID")
            child = self.transforms.get(cpid) if cpid else None
            if child:
                gpid = (child.get("m_GameObject") or {}).get("m_PathID")
                if gpid:
                    out.append(gpid)
        return out

    def walk(self, go_pid: int, seen: Optional[Set[int]] = None):
        if seen is None:
            seen = set()
        if go_pid in seen:
            return
        seen.add(go_pid)
        yield go_pid
        for child in self.children(go_pid):
            yield from self.walk(child, seen)

    def components(self, go_pid: int) -> List[Tuple[int, str]]:
        return [(pid, self.b.type_name(pid) or "?") for pid in self.go_components.get(go_pid, [])]

    def local_transform(self, go_pid: int) -> Dict[str, Any]:
        tt = self.transforms.get(self.transform_of_go.get(go_pid, -1)) or {}
        return {
            "position": _v3(tt.get("m_LocalPosition")),
            "scale": _v3(tt.get("m_LocalScale")),
        }


def _flatten_tracks(bundle: Bundle, refs: Any, out: List[Tuple[int, Dict[str, Any]]],
                    seen: Optional[Set[int]] = None) -> None:

    if seen is None:
        seen = set()
    for ref in refs or []:
        pid = (ref or {}).get("m_PathID")
        if not pid or pid in seen:
            continue
        seen.add(pid)
        tt = bundle.tt(pid)
        if not isinstance(tt, dict):
            continue
        out.append((pid, tt))
        _flatten_tracks(bundle, tt.get("m_Children"), out, seen)


def _is_effect_clip_asset(asset_tt: Any) -> bool:
    if not isinstance(asset_tt, dict):
        return False
    template = asset_tt.get("template")
    return isinstance(template, dict) and "effectActiveInfo" in template


def build_catalogue(bundle: Bundle, appearance: Appearance) -> List[Dict[str, Any]]:

    entries: List[Dict[str, Any]] = []
    used: Set[str] = set()
    for slot in appearance.slots():
        motion = slot["motionName"]
        for coin in slot["coins"]:
            timeline = bundle.tt(coin.get("timelinePathID"))
            if not isinstance(timeline, dict):
                continue
            tracks: List[Tuple[int, Dict[str, Any]]] = []
            _flatten_tracks(bundle, timeline.get("m_Tracks"), tracks)
            for track_index, (_track_pid, track_tt) in enumerate(tracks):
                clips = track_tt.get("m_Clips") or []
                if not clips:
                    continue
                track_name = str(track_tt.get("m_Name") or "")
                muted = bool(track_tt.get("m_Muted"))
                for clip_index, clip in enumerate(clips):
                    asset = bundle.pptr(clip.get("m_Asset") or {})
                    if not _is_effect_clip_asset(asset):
                        continue
                    info = (asset.get("template") or {}).get("effectActiveInfo") or {}
                    key = f"{motion}/{coin['coinIndex']}/{track_name}/{clip_index}"
                    if key in used:
                        key = f"{key}#{track_index}"
                    used.add(key)
                    label = str(clip.get("m_DisplayName") or track_name)
                    entries.append({
                        "key": key,
                        "index": len(entries) + 1,
                        "effect": label,
                        "motion": motion,
                        "slotIndex": slot["slotIndex"],
                        "coin": coin["coinIndex"],
                        "track": track_name,
                        "trackIndex": track_index,
                        "clip": clip_index,
                        "start": _f(clip.get("m_Start")),
                        "duration": _f(clip.get("m_Duration")),
                        "once": bool(info.get("isOnceEffect")),
                        "hide": bool(info.get("isDisable")),
                        "activeTime": _f(info.get("activeTime")),


                        "neverPlaysInVanilla": muted,

                        "copyAs": "vfx",
                        "copyParams": {
                            "effect": key,
                            "time": _f(clip.get("m_Start")),
                            "duration": _f(clip.get("m_Duration")),
                        },
                    })
    return entries


def _material_record(scene: _Scene, ref: Any) -> Dict[str, Any]:
    bundle = scene.b
    if not isinstance(ref, dict) or not ref.get("m_PathID"):
        return {"resolved": False, "why": "no material assigned"}
    if ref.get("m_FileID"):
        return {"resolved": False, "why": "material lives in a dependency bundle",
                "fileID": ref.get("m_FileID"), "pathID": ref.get("m_PathID")}
    tt = bundle.tt(ref["m_PathID"])
    if not isinstance(tt, dict):
        return {"resolved": False, "why": "material could not be read", "pathID": ref["m_PathID"]}
    shader_ref = tt.get("m_Shader") or {}
    if shader_ref.get("m_FileID"):
        shader_name, shader_where = None, "dependency bundle"
    else:
        shader_name = scene.shader_names.get(shader_ref.get("m_PathID"))
        shader_where = "this bundle"
    saved = tt.get("m_SavedProperties") or {}
    textures: List[Dict[str, Any]] = []
    for entry in saved.get("m_TexEnvs") or []:
        name = entry[0] if isinstance(entry, (list, tuple)) else entry.get("first")
        value = entry[1] if isinstance(entry, (list, tuple)) else entry.get("second")
        tex = (value or {}).get("m_Texture") or {}
        if not tex.get("m_PathID"):
            continue
        record: Dict[str, Any] = {"property": str(name)}
        if tex.get("m_FileID"):
            record["where"] = "dependency bundle"
        else:
            tex_tt = bundle.tt(tex["m_PathID"]) or {}
            record["where"] = "this bundle"
            record["pathID"] = tex["m_PathID"]
            record["name"] = str(tex_tt.get("m_Name") or "")
            record["format"] = texture_format_name(tex_tt.get("m_TextureFormat"))
            record["size"] = {"w": tex_tt.get("m_Width"), "h": tex_tt.get("m_Height")}
        textures.append(record)
    return {
        "resolved": True,
        "name": str(tt.get("m_Name") or ""),
        "shader": shader_name,
        "shaderIn": shader_where,

        "shaderIsRebuildable": shader_is_rebuildable(shader_name),
        "renderQueue": tt.get("m_CustomRenderQueue"),
        "keywords": tt.get("m_ValidKeywords") or tt.get("m_ShaderKeywords") or [],
        "textures": textures,
    }


def _particle_summary(tt: Dict[str, Any]) -> Dict[str, Any]:

    initial = tt.get("InitialModule") or {}
    emission = tt.get("EmissionModule") or {}
    shape = tt.get("ShapeModule") or {}

    def curve(node: Any) -> Optional[Dict[str, Any]]:
        if not isinstance(node, dict):
            return None
        return {
            "minMaxState": node.get("minMaxState"),
            "scalar": _f(node.get("scalar")),
            "minScalar": _f(node.get("minScalar")),
            "curveKeys": len((node.get("maxCurve") or {}).get("m_Curve") or []),
        }

    return {
        "lengthInSec": _f(tt.get("lengthInSec")),
        "looping": bool(tt.get("looping")),
        "prewarm": bool(tt.get("prewarm")),
        "playOnAwake": bool(tt.get("playOnAwake")),
        "simulationSpeed": _f(tt.get("simulationSpeed")),


        "startDelay": curve(tt.get("startDelay")),
        "startLifetime": curve(initial.get("startLifetime")),
        "startSpeed": curve(initial.get("startSpeed")),
        "startSize": curve(initial.get("startSize")),
        "startRotation": curve(initial.get("startRotation")),
        "gravityModifier": curve(initial.get("gravityModifier")),
        "maxNumParticles": initial.get("maxNumParticles"),
        "emissionEnabled": bool(emission.get("enabled")),
        "rateOverTime": curve(emission.get("rateOverTime")),
        "burstCount": len(emission.get("m_Bursts") or []),
        "shapeEnabled": bool(shape.get("enabled")),
        "shapeType": shape.get("type"),
        "modulesEnabled": sorted(
            name for name, node in tt.items()
            if name.endswith("Module") and isinstance(node, dict) and node.get("enabled")
        ),
    }


def describe_effect(scene: _Scene, root_go: int, deep: bool) -> Dict[str, Any]:

    bundle = scene.b
    record: Dict[str, Any] = {
        "name": scene.go_name.get(root_go, ""),
        "gameObjectPathID": root_go,
        "children": 0,
        "particleSystems": 0,
        "trailRenderers": 0,
        "spriteRenderers": 0,
        "animators": 0,
        "meshRenderers": 0,


        "gameScripts": 0,
        "materials": [],
        "renderModes": {},
        "sortingLayerIDs": [],
        "sortingOrders": [],
    }
    material_seen: Set[Any] = set()
    render_modes: collections.Counter = collections.Counter()
    sorting_layers: Set[Any] = set()
    sorting_orders: Set[Any] = set()
    particles: List[Dict[str, Any]] = []

    for go_pid in scene.walk(root_go):
        if go_pid != root_go:
            record["children"] += 1
        for comp_pid, comp_type in scene.components(go_pid):
            if comp_type == "ParticleSystem":
                record["particleSystems"] += 1
                if deep:
                    tt = bundle.tt(comp_pid)
                    if isinstance(tt, dict):
                        particles.append({
                            "object": scene.go_name.get(go_pid, ""),
                            **_particle_summary(tt),
                        })
            elif comp_type == "ParticleSystemRenderer":
                tt = bundle.tt(comp_pid) or {}
                render_modes[RENDER_MODES.get(tt.get("m_RenderMode"), str(tt.get("m_RenderMode")))] += 1
                sorting_layers.add(tt.get("m_SortingLayerID"))
                sorting_orders.add(tt.get("m_SortingOrder"))
                for mref in tt.get("m_Materials") or []:
                    marker = (mref or {}).get("m_FileID"), (mref or {}).get("m_PathID")
                    if marker in material_seen:
                        continue
                    material_seen.add(marker)
                    record["materials"].append(_material_record(scene, mref))
            elif comp_type == "TrailRenderer":
                record["trailRenderers"] += 1
            elif comp_type == "SpriteRenderer":
                record["spriteRenderers"] += 1
            elif comp_type == "Animator":
                record["animators"] += 1
            elif comp_type == "MeshRenderer":
                record["meshRenderers"] += 1
            elif comp_type == "MonoBehaviour":
                record["gameScripts"] += 1

    record["renderModes"] = dict(render_modes)
    record["sortingLayerIDs"] = sorted(x for x in sorting_layers if x is not None)
    record["sortingOrders"] = sorted(x for x in sorting_orders if x is not None)
    if deep:
        record["particleDetail"] = particles


    for comp_pid, comp_type in scene.components(root_go):
        if comp_type != "MonoBehaviour":
            continue
        tt = bundle.tt(comp_pid)
        if not isinstance(tt, dict) or not ATTACK_EFFECT_FIELDS <= set(tt.keys()):
            continue
        v2 = V2_MARKER_FIELD in tt
        position_type = tt.get(V2_MARKER_FIELD)
        record["attackEffect"] = {
            "class": "CharacterAttackEffectV2" if v2 else "CharacterAttackEffect",
            "offset": _v3(tt.get("_offset")),
            "additionalScale": _v3(tt.get("_additionalScale")),
            "disableAfter": _f(tt.get("disabletime")),
            "effectPositionType": EFFECT_POSITION_TYPE.get(position_type, position_type) if v2 else None,


            "drawnOn": ("target" if position_type == 2 else "self") if v2 else "self",
            "targetIndex": tt.get("_index") if v2 else None,
        }
        break

    record["localTransform"] = scene.local_transform(root_go)
    return record


def find_effect_roots(scene: _Scene) -> Dict[str, List[int]]:

    found: Dict[str, List[int]] = collections.defaultdict(list)
    for go_pid, name in scene.go_name.items():
        for comp_pid, comp_type in scene.components(go_pid):
            if comp_type != "MonoBehaviour":
                continue
            tt = scene.b.tt(comp_pid)
            if isinstance(tt, dict) and ATTACK_EFFECT_FIELDS <= set(tt.keys()):
                found[name].append(go_pid)
                break
    return dict(found)


def extract_vfx(
    bundle: Bundle,
    appearance: Appearance,
    bundle_name: str,
    out_root: str,
    deep: bool = False,
    write_textures: bool = False,
) -> Dict[str, Any]:

    from .images import SpriteExporter

    scene = _Scene(bundle)
    catalogue = build_catalogue(bundle, appearance)
    roots = find_effect_roots(scene)

    used_labels = collections.Counter(e["effect"] for e in catalogue)
    effects: Dict[str, Dict[str, Any]] = {}
    unmatched: List[str] = []
    for label in sorted(used_labels):
        hits = roots.get(label) or []
        if not hits:
            unmatched.append(label)
            continue
        described = describe_effect(scene, hits[0], deep)
        described["clipCount"] = used_labels[label]
        if len(hits) > 1:
            described["ambiguous"] = (
                f"{len(hits)} GameObjects in this bundle are named {label!r}; the first was "
                "described. The runtime resolves the effect by its exposed name, not by this "
                "name, so REUSE is unaffected -- only this description could be of the wrong one."
            )
        effects[label] = described


    never_referenced = sorted(name for name in roots if name not in used_labels)

    warnings: List[str] = []
    if unmatched:
        warnings.append(
            f"{len(unmatched)} catalogue label(s) have no matching effect object in this "
            "bundle: " + ", ".join(sorted(unmatched)[:8]) +
            ("..." if len(unmatched) > 8 else "") +
            ". The `effect` key still resolves at runtime (the game looks the effect up by "
            "its exposed name); only the description below is missing."
        )


    all_materials = [m for e in effects.values() for m in e["materials"]]
    total_materials = sum(1 for m in all_materials if m.get("why") != "no material assigned")
    rebuildable = sum(1 for m in all_materials if m.get("shaderIsRebuildable"))
    unresolved_materials = sum(
        1 for m in all_materials
        if not m.get("resolved") and m.get("why") != "no material assigned"
    )
    empty_slots = sum(1 for m in all_materials if m.get("why") == "no material assigned")

    out_dir = os.path.join(out_root, appearance.name or bundle_name)
    os.makedirs(out_dir, exist_ok=True)

    textures: Dict[str, Any] = {}
    if write_textures:
        exporter = SpriteExporter(bundle)
        tex_dir = os.path.join(out_dir, "vfx_textures")
        seen_tex: Set[int] = set()
        for effect in effects.values():
            for material in effect["materials"]:
                for tex in material.get("textures") or []:
                    path_id = tex.get("pathID")
                    if not path_id or path_id in seen_tex:
                        continue
                    seen_tex.add(path_id)
                    safe = "".join(
                        c if (c.isalnum() or c in "._-") else "_" for c in (tex.get("name") or "tex")
                    )
                    written = exporter.export_texture(
                        path_id, os.path.join(tex_dir, f"{safe}.png")
                    )
                    if written:
                        written.pop("image", None)
                        textures[str(path_id)] = written
        for error in exporter.errors:
            warnings.append(f"texture export: {error}")

    manifest = {
        "tool": "LimbusExtract vfx",
        "source": {"bundle": bundle_name, "path": bundle.path},
        "appearance": appearance.name,
        "appearanceId": appearance.id_from_name,
        "catalogue": {
            "count": len(catalogue),
            "distinctEffects": len(used_labels),
            "howToUse": (
                "Put `effect` (the key) in a mod.json vfx entry. `index` is the same thing by "
                "1-based position and is FRAGILE -- it moves whenever the game changes this "
                "character's animations. The runtime catalogue "
                "(companion command ModMotion_VfxCatalog) is the authority; this is the same "
                "walk done offline so you can pick before ever entering a battle."
            ),
            "entries": catalogue,
        },
        "effects": effects,
        "effectsNeverActivatedByAnyMotion": never_referenced,
        "importability": {
            "materialsOnEffectRenderers": total_materials,
            "shaderRebuildableInAnAuthoringProject": rebuildable,
            "materialsThatCouldNotBeResolved": unresolved_materials,
            "emptyMaterialSlots": empty_slots,
            "verdict": (
                "Prefab structure and every ParticleSystem field are readable and would "
                "round-trip. The LOOK will not: an effect's appearance comes from its "
                "material's shader, and these are game-authored (Fx_Team/*, Shader Graphs/*) "
                "and ship compiled. Reuse the effect through mod.json instead; use the "
                "numbers and textures here only as a reference for rebuilding one."
            ),
        },
        "textures": textures,
        "warnings": warnings,
        "partialReads": {
            "count": len(bundle.partial_reads),
            "note": (
                "Effect clip assets need a partial typetree read -- UnityPy mis-sizes their "
                "trailing ExposedReference<T>. The recovered payload (isOnceEffect / isDisable "
                "/ activeTime) is what this catalogue uses; the lost field is the pointer at "
                "the effect object, which is why effects are joined by display name instead."
            ),
        },
        "readErrors": {"count": len(bundle.read_errors)},
        "_outDir": out_dir,
    }

    with open(os.path.join(out_dir, "vfx.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return manifest
