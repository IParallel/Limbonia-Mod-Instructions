from __future__ import annotations

import glob
import os
import re
import struct
from typing import Any, Dict, Iterable, List, NamedTuple, Optional, Tuple


BUNDLE_RE = re.compile(rb"([A-Za-z0-9_.\-]{3,160})_([0-9a-f]{32})\.bundle")


APPEARANCE_FAMILIES = {
    "SD_Personality": "sinner identity",
    "SD_Enemy": "enemy",
    "SD_Abnormality": "abnormality",
    "SD_EGO": "E.G.O.",
    "SD_DeadScene": "dead scene",
}

DEFAULT_GAME_DIRS = [
    r"H:\SteamLibrary\steamapps\common\Limbus Company",
    r"C:\Program Files (x86)\Steam\steamapps\common\Limbus Company",
    r"D:\SteamLibrary\steamapps\common\Limbus Company",
    r"E:\SteamLibrary\steamapps\common\Limbus Company",
]


class BundleNotFound(Exception):
    pass


def find_game_dir(explicit: Optional[str] = None) -> str:
    if explicit:
        if not os.path.isdir(explicit):
            raise BundleNotFound(f"--game-dir does not exist: {explicit}")
        return explicit
    for candidate in DEFAULT_GAME_DIRS:
        if os.path.isfile(os.path.join(candidate, "LimbusCompany.exe")):
            return candidate
    raise BundleNotFound(
        "Could not find the Limbus Company install. Pass --game-dir explicitly."
    )


def find_cache_dir(explicit: Optional[str] = None) -> str:
    if explicit:
        if not os.path.isdir(explicit):
            raise BundleNotFound(f"--cache-dir does not exist: {explicit}")
        return explicit

    local = os.environ.get("LOCALAPPDATA")
    roots = []
    if local:
        roots.append(os.path.join(os.path.dirname(local), "LocalLow"))
    profile = os.environ.get("USERPROFILE")
    if profile:
        roots.append(os.path.join(profile, "AppData", "LocalLow"))
    for root in roots:
        candidate = os.path.join(root, "Unity", "ProjectMoon_LimbusCompany")
        if os.path.isdir(candidate):
            return candidate
    raise BundleNotFound(
        "Could not find the Addressables cache "
        "(<LocalLow>/Unity/ProjectMoon_LimbusCompany). Pass --cache-dir."
    )


_DYNAMIC = 0x40000000
_UNICODE = 0x80000000
_OFFSET = 0x3FFFFFFF
_ABSENT = 0xFFFFFFFF
_KEY_TABLE = 36

_APPEARANCE_SUFFIX = ".prefab"


class CatalogAppearance(NamedTuple):


    key: str
    name: str
    family: str
    bundle: str
    asset_path: str
    address: str

    @property
    def kind(self) -> str:
        return APPEARANCE_FAMILIES.get(self.family, self.family)

    @property
    def spellings(self) -> Tuple[str, ...]:

        if self.address == self.name:
            return (self.name,)
        return (self.name, self.address)

    @property
    def ids(self) -> List[int]:

        return [int(run) for run in re.findall(r"\d+", self.name)]


class _CatalogReader:
    def __init__(self, data: bytes) -> None:
        self.data = data

    def u32(self, offset: int) -> int:
        return struct.unpack_from("<I", self.data, offset)[0]

    def raw_string(self, string_id: int) -> str:
        start = string_id & _OFFSET
        length = self.u32(start - 4)
        chunk = self.data[start : start + length]
        if string_id & _UNICODE:
            return chunk.decode("utf-16-le")
        return chunk.decode("latin1")

    def string(self, string_id: int, separator: str = "") -> Optional[str]:
        if string_id in (_ABSENT, 0):
            return None
        if not string_id & _DYNAMIC:
            return self.raw_string(string_id)
        parts: List[str] = []
        node = string_id & _OFFSET
        while True:
            parts.append(self.raw_string(self.u32(node)))
            following = self.u32(node + 4)
            if following == _ABSENT:
                break
            node = following & _OFFSET
        parts.reverse()
        return separator.join(parts)

    def block(self, offset: int) -> List[int]:

        start = offset & _OFFSET
        count = self.u32(start - 4) // 4
        return [self.u32(start + i * 4) for i in range(count)]


def read_appearance_catalog(data: bytes) -> Dict[str, CatalogAppearance]:

    reader = _CatalogReader(data)
    found: Dict[str, CatalogAppearance] = {}
    key_count = reader.u32(_KEY_TABLE - 4) // 8
    for index in range(key_count):
        key_node, location_list = struct.unpack_from(
            "<II", data, _KEY_TABLE + index * 8
        )
        _type, data_offset = struct.unpack_from("<II", data, key_node)
        separator = reader.u32(data_offset + 4)
        key = reader.string(
            reader.u32(data_offset), chr(separator) if separator else ""
        )
        if not key or not key.endswith(_APPEARANCE_SUFFIX) or "/" not in key:
            continue
        family, _, leaf = key.partition("/")
        if family not in APPEARANCE_FAMILIES:
            continue
        address = leaf[: -len(_APPEARANCE_SUFFIX)]
        for location in reader.block(location_list):
            base = location & _OFFSET
            dependencies = reader.u32(base + 12)
            if dependencies in (0, _ABSENT):
                continue
            bundle = _primary_bundle(reader, dependencies)
            if not bundle:
                continue
            asset_path = reader.string(reader.u32(base + 4), "/") or ""


            name = asset_path.rsplit("/", 1)[-1]
            if name.endswith(_APPEARANCE_SUFFIX):
                name = name[: -len(_APPEARANCE_SUFFIX)]
            name = name or address
            if name not in found:
                found[name] = CatalogAppearance(
                    key=key,
                    name=name,
                    family=family,
                    bundle=bundle,
                    asset_path=asset_path,
                    address=address,
                )
            break
    return found


def _primary_bundle(reader: _CatalogReader, dependencies: int) -> Optional[str]:

    for entry in reader.block(dependencies):
        filename = reader.string(reader.u32(entry & _OFFSET), "/")
        if not filename or not filename.endswith(".bundle"):
            continue
        base = re.sub(r"_[0-9a-f]{32}\.bundle$", "", filename)
        if base.endswith("_monoscripts") or base.startswith("vfx__unitybuiltin"):
            continue
        return base
    return None


class BundleIndex:


    def __init__(self, game_dir: str, cache_dir: str) -> None:
        self.game_dir = game_dir
        self.cache_dir = cache_dir
        self.aa_dir = os.path.join(
            game_dir, "LimbusCompany_Data", "StreamingAssets", "aa"
        )
        self.catalog_path = os.path.join(self.aa_dir, "catalog.bin")
        self.names: Dict[str, str] = {}
        self._inner_dirs: Optional[Dict[str, str]] = None
        self._catalog_bytes = b""
        self._appearances: Optional[Dict[str, CatalogAppearance]] = None

        self.appearance_catalog_error: Optional[str] = None
        self._load_catalog()

    def _load_catalog(self) -> None:
        if not os.path.isfile(self.catalog_path):
            raise BundleNotFound(f"catalog.bin not found at {self.catalog_path}")
        with open(self.catalog_path, "rb") as handle:
            self._catalog_bytes = handle.read()
        for match in BUNDLE_RE.finditer(self._catalog_bytes):
            base = match.group(1).decode("ascii", "replace")
            digest = match.group(2).decode("ascii")


            self.names.setdefault(base, digest)


    @property
    def appearances(self) -> Dict[str, CatalogAppearance]:

        if self._appearances is None:
            try:
                self._appearances = read_appearance_catalog(self._catalog_bytes)
            except Exception as exc:
                self._appearances = {}
                self.appearance_catalog_error = f"{type(exc).__name__}: {exc}"
        return self._appearances

    def appearance_families(self) -> Dict[str, int]:

        counts: Dict[str, int] = {}
        for entry in self.appearances.values():
            counts[entry.family] = counts.get(entry.family, 0) + 1
        return counts

    def catalog_lookup(self, wanted: str) -> List[CatalogAppearance]:

        entries = list(self.appearances.values())
        lowered = wanted.lower()
        exact = [
            e for e in entries if any(s.lower() == lowered for s in e.spellings)
        ]
        leading: List[CatalogAppearance] = []
        embedded: List[CatalogAppearance] = []
        if wanted.isdigit():
            target = int(wanted)
            for entry in entries:
                ids = entry.ids
                if not ids:
                    continue
                if entry.name.startswith(wanted):
                    leading.append(entry)
                elif target in ids:
                    embedded.append(entry)
        substring = [
            e
            for e in entries
            if any(lowered in s.lower() for s in e.spellings)
            and e not in exact
            and e not in leading
        ]
        ordered: List[CatalogAppearance] = []
        for group in (exact, leading, embedded, substring):
            for entry in sorted(group, key=lambda e: e.name):
                if entry not in ordered:
                    ordered.append(entry)
        return ordered

    def nearest_appearance_ids(self, wanted: str, limit: int = 6) -> List[CatalogAppearance]:

        if not wanted.isdigit():
            return []
        target = int(wanted)
        scored = [
            (min(abs(value - target) for value in entry.ids), entry)
            for entry in self.appearances.values()
            if entry.ids
        ]
        scored.sort(key=lambda pair: (pair[0], pair[1].name))
        return [entry for _distance, entry in scored[:limit]]

    def _cache_inner_dirs(self) -> Dict[str, str]:
        if self._inner_dirs is None:
            found: Dict[str, str] = {}
            pattern = os.path.join(self.cache_dir, "*", "*")
            for path in glob.glob(pattern):
                if os.path.isdir(path):
                    found[os.path.basename(path)] = path
            self._inner_dirs = found
        return self._inner_dirs

    def hash_for(self, base_name: str) -> Optional[str]:
        if base_name in self.names:
            return self.names[base_name]

        for name, digest in self.names.items():
            if name.endswith(base_name):
                return digest
        return None

    def resolve(self, base_name: str) -> Optional[Tuple[str, str]]:

        digest = self.hash_for(base_name)
        if not digest:
            return None
        full = f"{base_name}_{digest}.bundle"
        inner = self._cache_inner_dirs().get(digest)
        if inner:
            data = os.path.join(inner, "__data")
            if os.path.isfile(data):
                return data, full

        for path in glob.glob(os.path.join(self.aa_dir, "*", f"*{digest}.bundle")):
            return path, os.path.basename(path)
        return None

    def matching(self, pattern: str) -> List[str]:

        rx = re.compile(pattern)
        return sorted(n for n in self.names if rx.search(n))

    def all_cached_data_files(self) -> List[str]:
        return sorted(
            path
            for path in glob.glob(os.path.join(self.cache_dir, "*", "*", "__data"))
            if os.path.isfile(path)
        )


def sinner_of(appearance_id: int) -> int:

    return (appearance_id // 100) % 100


def candidate_bundles(appearance_id: int) -> List[str]:

    sinner = sinner_of(appearance_id)
    return [
        f"p{appearance_id}_assets_all",
        f"p{appearance_id}_sd_assets_all",
        f"sd_p{sinner}_assets_all",
        f"e{appearance_id}_assets_all",
    ]


def sd_sweep_bundles(index: "BundleIndex") -> List[str]:

    names: List[str] = []
    for pattern in (
        r"^sd_p\d+_assets_all$",
        r"^sd_enemy_assets_all$",
        r"^sd_abnormality_assets_all$",
        r"^sd_deadscene_assets_all$",
        r"^sd_ego\d+_assets_all$",
        r"_sd_enemy_assets_all$",
        r"_enemy_sd_assets_all$",
        r"_sd_abnormality_assets_all$",
        r"_abnormality_assets_all$",
        r"_enemy_assets_all$",
        r"_assistant_assets_all$",
    ):
        names.extend(index.matching(pattern))
    seen = set()
    ordered = []
    for name in names:
        if name not in seen:
            seen.add(name)
            ordered.append(name)
    return ordered


def iter_candidate_paths(
    index: BundleIndex, appearance_id: Optional[int], extra: Iterable[str] = ()
) -> Iterable[Tuple[str, str]]:

    names: List[str] = list(extra)
    if appearance_id is not None:
        names.extend(candidate_bundles(appearance_id))
    seen = set()
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        hit = index.resolve(name)
        if hit:
            yield hit
