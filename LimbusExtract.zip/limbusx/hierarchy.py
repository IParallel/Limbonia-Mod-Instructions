from __future__ import annotations

import zlib
from typing import Any, Dict, List, Optional

from .env import Bundle


def crc32_path(path: str) -> int:
    return zlib.crc32(path.encode("utf-8")) & 0xFFFFFFFF


def _transform_index(bundle: Bundle) -> Dict[int, Dict[str, Any]]:
    index: Dict[int, Dict[str, Any]] = {}
    for obj in bundle.of_type("Transform", "RectTransform"):
        tt = bundle.tt_of(obj)
        if not tt:
            continue
        game_object = bundle.pptr(tt.get("m_GameObject") or {}) or {}
        index[obj.path_id] = {
            "name": str(game_object.get("m_Name") or ""),
            "children": [
                (child or {}).get("m_PathID") for child in (tt.get("m_Children") or [])
            ],
        }
    return index


def _root_transform_of(bundle: Bundle, game_object_tt: Dict[str, Any], index: Dict[int, Dict[str, Any]]) -> Optional[int]:
    for component in game_object_tt.get("m_Component") or []:
        if isinstance(component, dict):
            ref = component.get("component") or component.get("second") or component
        elif isinstance(component, (list, tuple)):
            ref = component[1] if len(component) > 1 else component[0]
        else:
            continue
        path_id = (ref or {}).get("m_PathID") if isinstance(ref, dict) else None
        if path_id in index:
            return path_id
    return None


def build_path_table(bundle: Bundle, appearance_component_tt: Dict[str, Any]) -> Dict[int, str]:

    index = _transform_index(bundle)
    root_go = bundle.pptr(appearance_component_tt.get("m_GameObject") or {}) or {}
    root = _root_transform_of(bundle, root_go, index)
    if root is None:
        return {}

    table: Dict[int, str] = {}
    seen: set = set()

    def walk(path_id: Optional[int], prefix: Optional[str]) -> None:
        node = index.get(path_id)
        if node is None or path_id in seen:
            return
        seen.add(path_id)
        if prefix is None:
            current = None
        else:
            current = node["name"] if not prefix else f"{prefix}/{node['name']}"


            table.setdefault(crc32_path(current), current)
        for child in node["children"]:
            walk(child, "" if current is None else current)

    walk(root, None)
    return table


def resolve_binding_path(table: Dict[int, str], binding_path: Any) -> Optional[str]:
    try:
        return table.get(int(binding_path) & 0xFFFFFFFF)
    except (TypeError, ValueError):
        return None
