from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from .env import Bundle

_CLONE_RE = re.compile(r"(?:\(Clone\))+\s*$")
_TRAILING_INDEX_RE = re.compile(r"\s*\(\d+\)\s*$")


EASE_NAMES = [
    "Unset", "Linear", "InSine", "OutSine", "InOutSine", "InQuad", "OutQuad",
    "InOutQuad", "InCubic", "OutCubic", "InOutCubic", "InQuart", "OutQuart",
    "InOutQuart", "InQuint", "OutQuint", "InOutQuint", "InExpo", "OutExpo",
    "InOutExpo", "InCirc", "OutCirc", "InOutCirc", "InElastic", "OutElastic",
    "InOutElastic", "InBack", "OutBack", "InOutBack", "InBounce", "OutBounce",
    "InOutBounce",
]


def ease_name(value: Any) -> Optional[str]:
    try:
        index = int(value)
    except (TypeError, ValueError):
        return None
    if 0 <= index < len(EASE_NAMES):
        return EASE_NAMES[index]
    return None


def normalise_name(raw: Any) -> str:
    name = str(raw or "")
    previous = None
    while previous != name:
        previous = name
        name = _CLONE_RE.sub("", name).strip()
        name = _TRAILING_INDEX_RE.sub("", name).strip()
    return name


MARKER_KINDS = [
    ("Skill Give Timing_Give Damage", "giveDamage"),
    ("Character Appearance Marker_Hit Cheaker", "hitCheaker"),
    ("Character Appearance Marker_End Cheaker", "endCheaker"),
    ("Character Appearance Marker_Camera Shaker", "cameraShake"),
    ("Skill Give Timing_Tween Move_To Target_Wide", "moveToTargetWide"),
    ("Skill Give Timing_Tween Move_To Target", "moveToTarget"),
    ("Skill Give Timing_Tween Move_Relative", "moveRelative"),
    ("Skill Give Timing_Tween Move_Move Enemy", "moveEnemy"),
    ("Skill Give Timing_Tween Move", "moveOther"),
]

TRACK_KINDS = [
    ("Animation Track", "animation"),
    ("On Battle Cam Zoom Track", "camZoom"),
    ("On Battle Cam Rotate Track", "camRotate"),
    ("Skill Give Timing Track", "skillGiveTiming"),
    ("Character Appearance Timeline Track", "characterAppearance"),
    ("Effect Activate Timeline Track", "effectActivate"),
    ("FMOD Custom Track_Voice", "fmodVoice"),
    ("FMOD Custom Track", "fmod"),
]


_ANIMATION_TRACK_FIELDS = {
    "m_ApplyAvatarMask",
    "m_AvatarMask",
    "m_InfiniteClipRemoveOffset",
    "m_InfiniteClipPreExtrapolation",
    "m_ApplyOffsets",
}


def _classify(name: str, table: List[tuple]) -> str:
    for prefix, kind in table:
        if name.startswith(prefix):
            return kind
    return "other"


def marker_kind(raw_name: Any, payload: Optional[Dict[str, Any]] = None) -> str:

    if payload:
        keys = set(payload.keys())
        if "hitCheakerInfo" in keys:
            return "hitCheaker"
        if "sturnInfo" in keys or ("ratios" in keys and "info" in keys):
            return "giveDamage"
        if {"strength", "vibrato", "randomness", "fadeOut"} <= keys:
            return "cameraShake"
        move_info = payload.get("moveInfo")
        if isinstance(move_info, dict):
            if "movePos" in move_info:
                return "moveRelative"
            if "arriveRadius" in move_info:


                return "moveToTargetWide" if "moveInfo_wide" in keys else "moveToTarget"
            return "moveOther"
    by_name = _classify(normalise_name(raw_name), MARKER_KINDS)
    if by_name != "other":
        return by_name

    if payload is not None and not payload:
        return "endCheaker"
    return "other"


_MOVE_MODE_STRING = {
    "relative": "relative",
    "toTarget": "toTarget",
    "toTargetWide": "toTargetWide",
}


def _num_or(source: Any, key: str, default: Any = None) -> Any:
    if not isinstance(source, dict):
        return default
    value = source.get(key)
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    if result != result or result in (float("inf"), float("-inf")):
        return default
    return round(result, 6)


def _bool_or(source: Any, key: str, default: Optional[bool] = None) -> Optional[bool]:
    if not isinstance(source, dict) or key not in source:
        return default
    try:
        return bool(int(source[key]))
    except (TypeError, ValueError):
        return bool(source[key])


def _int_or(source: Any, key: str, default: Any = None) -> Any:
    value = _num_or(source, key, None)
    return default if value is None else int(round(value))


def _vector(source: Any, key: str) -> Optional[Dict[str, float]]:
    holder = (source or {}).get(key) if isinstance(source, dict) else None
    if not isinstance(holder, dict):
        return None
    out = {}
    for axis in ("x", "y", "z"):
        value = _num_or(holder, axis, None)
        out[axis] = 0.0 if value is None else value
    return out


def _moves_the_target(normalised_name: str) -> bool:

    return normalised_name.endswith("_Target")


def marker_copy_spec(
    kind: str, raw_name: Any, time: Optional[float], payload: Optional[Dict[str, Any]]
) -> Optional[Dict[str, Any]]:

    if kind not in (
        "cameraShake",
        "moveToTargetWide",
        "moveToTarget",
        "moveRelative",
        "moveEnemy",
        "moveOther",
    ):
        return None

    name = normalise_name(raw_name)
    payload = payload or {}
    if time is None:
        return {"copyAs": None, "copySkipReason": f"{name!r} has no usable time"}

    if kind == "cameraShake":
        params: Dict[str, Any] = {"time": round(float(time), 6)}
        for key, source_key in (
            ("duration", "duration"),
            ("strength", "strength"),
            ("randomness", "randomness"),
        ):
            value = _num_or(payload, source_key, None)
            if value is not None:
                params[key] = value
        vibrato = _int_or(payload, "vibrato", None)
        if vibrato is not None:
            params["vibrato"] = vibrato
        fade_out = _bool_or(payload, "fadeOut", None)
        if fade_out is not None:
            params["fadeOut"] = fade_out
        spec: Dict[str, Any] = {"copyAs": "cameraShake", "copyParams": params}


        lost = [k for k in ("direction", "isShakeStartZero") if k in payload]
        if lost:
            spec["copyNote"] = (
                f"{name!r} is the _Detail shake variant; {', '.join(lost)} has no "
                "mod.json equivalent and is not carried over"
            )
        return spec

    if kind in ("moveEnemy", "moveOther"):
        return {
            "copyAs": None,
            "copySkipReason": (
                f"{name!r} is a '{kind}' movement, which mod.json's move list "
                "cannot express -- skipped rather than mapped to a mode it is not"
            ),
        }

    move_info = payload.get("moveInfo")
    if not isinstance(move_info, dict):
        return {
            "copyAs": None,
            "copySkipReason": (
                f"{name!r} has no readable moveInfo payload, so how far and how "
                "long it moves is unknown -- skipped"
            ),
        }
    if _moves_the_target(name):
        return {
            "copyAs": None,
            "copySkipReason": (
                f"{name!r} moves the TARGET, and a mod.json move only ever moves "
                "the attacker -- skipped rather than applied to the wrong character"
            ),
        }

    params = {"time": round(float(time), 6)}
    duration = _num_or(move_info, "duration", None)
    if duration is not None:
        params["duration"] = duration
    refresh = _bool_or(move_info, "isRefreshDir", None)
    if refresh is not None:
        params["refreshDir"] = refresh
    ease = _int_or(move_info, "ease", None)
    if ease is not None:
        params["ease"] = ease

    if "movePos" in move_info:
        offset = _vector(move_info, "movePos") or {"x": 0.0, "y": 0.0, "z": 0.0}
        params.update({"mode": _MOVE_MODE_STRING["relative"], **offset})
        y_zero = _bool_or(payload, "isYPosWorldZero", None)
        params["yWorldZero"] = bool(y_zero) if y_zero is not None else False
        spec = {"copyAs": "relative", "copyParams": params}
        if "isYPosWorldZero" not in payload:
            spec["copyNote"] = (
                f"{name!r} is the older Relative marker with no isYPosWorldZero "
                "field; copied as RelativeV2 with yWorldZero off, which is what "
                "the old one does"
            )
        return spec

    if "arriveRadius" not in move_info:
        return {
            "copyAs": None,
            "copySkipReason": (
                f"{name!r} has a moveInfo shaped like neither TweenMoveInfo_Relative "
                "(movePos) nor TweenMoveInfo_ToTarget (arriveRadius) -- skipped "
                "rather than guessed"
            ),
        }

    arrive = _num_or(move_info, "arriveRadius", None)
    if arrive is not None:
        params["arriveRadius"] = arrive
    for out_key, source_key in (
        ("includeTargetRadius", "isInclude_targetRadius"),

        ("includeAttackerRadius", "isInclude_attakcerRadius"),
        ("chaseY", "isChaseY"),
    ):
        value = _bool_or(move_info, source_key, None)
        if value is not None:
            params[out_key] = value

    wide = payload.get("moveInfo_wide")
    if not isinstance(wide, dict):
        params["mode"] = _MOVE_MODE_STRING["toTarget"]
        return {"copyAs": "toTarget", "copyParams": params}

    params["mode"] = _MOVE_MODE_STRING["toTargetWide"]
    vector = _vector(wide, "arriveRadius_Vector")
    if vector:
        params.update(vector)
    override = _int_or(wide, "overrideTarget", None)
    if override is not None:
        params["overrideTarget"] = override


    return {"copyAs": "toTargetWide", "copyParams": params}


def track_kind(raw_name: Any, track_tt: Optional[Dict[str, Any]] = None) -> str:
    if track_tt and _ANIMATION_TRACK_FIELDS & set(track_tt.keys()):
        return "animation"
    return _classify(normalise_name(raw_name), TRACK_KINDS)


def _kind_from_clip_asset(asset_tt: Dict[str, Any]) -> Optional[str]:

    if "m_Clip" in asset_tt:
        return "animation"
    template = asset_tt.get("template")
    if isinstance(template, dict):
        if "zoomInfo" in template:
            return "camZoom"
        if "rotateInfo" in template or "targetAngle" in template:
            return "camRotate"
        if "effectActiveInfo" in template:
            return "effectActivate"
    if "eventName" in asset_tt or "EventReference" in asset_tt:
        return "fmod"
    return None


_SKIP_KEYS = {"m_GameObject", "m_Enabled", "m_Script", "m_Name"}


def _payload(tt: Dict[str, Any]) -> Dict[str, Any]:

    out: Dict[str, Any] = {}
    for key, value in tt.items():
        if key in _SKIP_KEYS or key == "m_Time":
            continue
        if key == "easeCurve" or key == "moveAnimationCurve":

            curve = (value or {}).get("m_Curve") or []
            out[key] = {"keyCount": len(curve)}
            continue
        out[key] = value
    return out


def read_timeline(bundle: Bundle, path_id: int) -> Optional[Dict[str, Any]]:

    tt = bundle.tt(path_id)
    if not tt or "m_Tracks" not in tt:
        return None

    duration_mode = tt.get("m_DurationMode")
    fixed_duration = tt.get("m_FixedDuration")

    tracks: List[Dict[str, Any]] = []
    effect_track_ordinal = 0
    max_end = 0.0
    visited: set = set()

    def walk(refs: Any, parent: Optional[str], depth: int, parent_muted: bool) -> None:
        nonlocal max_end
        for ref in refs or []:
            track_path_id = (ref or {}).get("m_PathID")
            track_tt = bundle.pptr(ref)
            if not track_tt:
                tracks.append({"unresolved": ref, "parentTrack": parent, "depth": depth})
                continue
            if track_path_id in visited:
                continue
            visited.add(track_path_id)
            entry = build(track_tt, track_path_id, parent, depth, parent_muted)
            tracks.append(entry)
            walk(
                track_tt.get("m_Children"),
                entry["label"],
                depth + 1,
                entry["mutedInHierarchy"],
            )

    def build(
        track_tt: Dict[str, Any],
        track_path_id: Optional[int],
        parent: Optional[str],
        depth: int,
        parent_muted: bool,
    ) -> Dict[str, Any]:
        nonlocal max_end
        raw_name = track_tt.get("m_Name")
        kind = track_kind(raw_name, track_tt)
        name = str(raw_name or "")
        entry: Dict[str, Any] = {
            "name": name,


            "trackPathID": track_path_id,
            "label": f"{parent}/{name}" if parent else name,
            "kind": kind,
            "parentTrack": parent,
            "depth": depth,


            "muted": bool(track_tt.get("m_Muted")),
            "mutedInHierarchy": bool(track_tt.get("m_Muted")) or parent_muted,
            "clips": [],
            "markers": [],
        }

        for clip in track_tt.get("m_Clips", []) or []:
            start = _f(clip.get("m_Start"))
            duration = _f(clip.get("m_Duration"))
            if start is not None and duration is not None:
                if not entry["mutedInHierarchy"]:
                    max_end = max(max_end, start + duration)
            asset_tt = bundle.pptr(clip.get("m_Asset") or {})
            record: Dict[str, Any] = {
                "start": start,
                "duration": duration,
                "clipIn": _f(clip.get("m_ClipIn")),
                "timeScale": _f(clip.get("m_TimeScale")),
                "displayName": clip.get("m_DisplayName"),
                "preExtrapolationMode": clip.get("m_PreExtrapolationMode"),
                "postExtrapolationMode": clip.get("m_PostExtrapolationMode"),
            }
            if asset_tt is None:
                asset_ref = clip.get("m_Asset") or {}
                record["asset"] = None
                if asset_ref.get("m_PathID"):


                    record["assetUnresolved"] = {
                        "pathID": asset_ref.get("m_PathID"),
                        "fileID": asset_ref.get("m_FileID"),
                        "reason": bundle.read_errors.get(
                            asset_ref.get("m_PathID"), "object not present in this bundle"
                        ),
                    }
            else:
                asset_name = str(asset_tt.get("m_Name") or "")
                record["asset"] = asset_name
                if "m_Clip" in asset_tt:

                    clip_ref = asset_tt.get("m_Clip") or {}
                    clip_tt = bundle.pptr(clip_ref)
                    record["animationClipPathID"] = clip_ref.get("m_PathID")
                    record["animationClipName"] = str((clip_tt or {}).get("m_Name") or "")
                    record["removeStartOffset"] = asset_tt.get("m_RemoveStartOffset")
                    record["loop"] = asset_tt.get("m_Loop")
                elif "template" in asset_tt:
                    record["template"] = _payload(asset_tt).get("template")
                elif "eventName" in asset_tt or "EventReference" in asset_tt:
                    record["eventName"] = asset_tt.get("eventName")
                    record["eventLength"] = asset_tt.get("EventLength")
                    record["eventReference"] = asset_tt.get("EventReference")
                else:
                    record["payload"] = _payload(asset_tt)
                if entry["kind"] == "other":


                    refined = _kind_from_clip_asset(asset_tt)
                    if refined:
                        entry["kind"] = refined
                        entry["kindFromClipAsset"] = True
            entry["clips"].append(record)

        markers_field = track_tt.get("m_Markers")
        marker_refs = (
            markers_field.get("m_Objects")
            if isinstance(markers_field, dict)
            else markers_field
        ) or []
        for ref_marker in marker_refs:
            marker_tt = bundle.pptr(ref_marker)
            if not marker_tt:
                entry["markers"].append({"unresolved": ref_marker})
                continue
            time = _f(marker_tt.get("m_Time"))
            if time is not None and not entry["mutedInHierarchy"]:
                max_end = max(max_end, time)
            payload = _payload(marker_tt)
            kind = marker_kind(marker_tt.get("m_Name"), payload)
            record: Dict[str, Any] = {
                "kind": kind,
                "name": str(marker_tt.get("m_Name") or ""),
                "time": time,
                "payload": payload,
            }


            spec = marker_copy_spec(kind, marker_tt.get("m_Name"), time, payload)
            if spec:
                record.update(spec)
            entry["markers"].append(record)

        entry["clips"].sort(key=lambda c: (c["start"] is None, c["start"]))
        entry["markers"].sort(key=lambda m: (m.get("time") is None, m.get("time")))
        return entry

    walk(tt.get("m_Tracks"), None, 0, False)


    for track in tracks:
        if track.get("kind") == "effectActivate":
            effect_track_ordinal += 1
            track["effectTrackIndex"] = effect_track_ordinal

    if duration_mode == 1 and fixed_duration:
        duration = _f(fixed_duration)
    else:
        duration = round(max_end, 6) if max_end else _f(fixed_duration)

    return {
        "timelinePathID": path_id,
        "name": str(tt.get("m_Name") or ""),
        "durationMode": duration_mode,
        "durationModeName": "FixedLength" if duration_mode == 1 else "BasedOnClips",
        "fixedDuration": _f(fixed_duration),
        "duration": duration,
        "trackCount": len(tracks),
        "tracks": tracks,
    }


def is_active(track: Dict[str, Any]) -> bool:

    return not track.get("mutedInHierarchy")


def markers_of_kind(
    timeline: Dict[str, Any], kind: str, include_muted: bool = False
) -> List[Dict[str, Any]]:

    found: List[Dict[str, Any]] = []
    for track in timeline.get("tracks", []):
        if not include_muted and not is_active(track):
            continue
        for marker in track.get("markers", []) or []:
            if marker.get("kind") == kind:
                found.append(marker)
    found.sort(key=lambda m: (m.get("time") is None, m.get("time")))
    return found


def tracks_of_kind(
    timeline: Dict[str, Any], kind: str, include_muted: bool = False
) -> List[Dict[str, Any]]:
    return [
        t
        for t in timeline.get("tracks", [])
        if t.get("kind") == kind and (include_muted or is_active(t))
    ]


def inactive_tracks(timeline: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        t
        for t in timeline.get("tracks", [])
        if t.get("mutedInHierarchy") and ((t.get("clips") or []) or (t.get("markers") or []))
    ]


def animation_segments(
    timeline: Dict[str, Any], include_muted: bool = False
) -> List[Dict[str, Any]]:

    segments: List[Dict[str, Any]] = []
    for track in timeline.get("tracks", []):
        if not include_muted and not is_active(track):
            continue
        for clip in track.get("clips", []) or []:
            if not clip.get("animationClipPathID"):
                continue
            segments.append(
                {
                    "track": track.get("label") or track.get("name"),
                    "trackPathID": track.get("trackPathID"),
                    "trackMuted": bool(track.get("mutedInHierarchy")),
                    "animationClipName": clip.get("animationClipName"),
                    "animationClipPathID": clip.get("animationClipPathID"),
                    "start": clip.get("start"),
                    "duration": clip.get("duration"),
                    "clipIn": clip.get("clipIn"),
                    "timeScale": clip.get("timeScale"),
                }
            )
    segments.sort(key=lambda s: (s["start"] is None, s["start"]))
    return segments


def map_frames_to_coin(
    frames: List[Dict[str, Any]], segments: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:

    out: List[Dict[str, Any]] = []
    for segment in segments:
        start = segment.get("start")
        duration = segment.get("duration")
        clip_in = segment.get("clipIn")
        clip_in = 0.0 if clip_in is None else float(clip_in)
        scale = segment.get("timeScale")
        scale = 1.0 if scale is None else float(scale)
        if start is None or duration is None or scale == 0.0:
            continue
        clip_window_end = clip_in + duration * scale
        for frame in frames:
            clip_time = frame.get("time")
            if clip_time is None:
                continue
            if clip_time < clip_in - 1e-6 or clip_time > clip_window_end + 1e-6:
                continue
            coin_time = start + (clip_time - clip_in) / scale
            out.append(
                {
                    **frame,
                    "clipTime": clip_time,
                    "coinTime": round(coin_time, 6),
                    "segmentStart": start,
                }
            )
    out.sort(key=lambda f: f["coinTime"])
    return out


def _f(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if result != result or result in (float("inf"), float("-inf")):
        return None
    return round(result, 6)
