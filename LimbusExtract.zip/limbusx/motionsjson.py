from __future__ import annotations

from typing import Any, Dict, List, Optional

from .timeline import ease_name, markers_of_kind, tracks_of_kind

SCHEMA_URL = (
    "https://raw.githubusercontent.com/LEAGUE-OF-NINE/motions-schema/"
    "refs/heads/main/schema.json"
)


def _fraction(time: Optional[float], duration: Optional[float]) -> float:
    if not time or not duration:
        return 0.0
    value = float(time) / float(duration)
    return round(min(1.0, max(0.0, value)), 6)


def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    if result != result:
        return default
    return round(result, 6)


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    try:
        return bool(int(value))
    except (TypeError, ValueError):
        return bool(value)


def coin_to_motions_json(timeline: Dict[str, Any]) -> Dict[str, Any]:
    duration = _num(timeline.get("duration")) or 0.0
    coin: Dict[str, Any] = {"totalDuration": duration, "phases": []}


    phases: List[Dict[str, Any]] = []
    for marker in markers_of_kind(timeline, "giveDamage"):
        fraction = _fraction(marker.get("time"), duration)
        payload = marker.get("payload") or {}
        info = payload.get("info") or {}
        sturn_info = payload.get("sturnInfo") or {}
        phase: Dict[str, Any] = {
            "type": "GiveDamage",
            "start": fraction,
            "end": fraction,
            "steps": 1,
        }
        ratio = _num(payload.get("ratios"))
        if ratio is not None:
            phase["damageRatio"] = ratio
        damage: Dict[str, Any] = {}
        if info.get("multiHit") is not None:
            damage["multiHit"] = max(1, int(info.get("multiHit") or 1))
        if info.get("isUpAttack") is not None:
            damage["isUpAttack"] = _bool(info.get("isUpAttack"))
        if info.get("multiHitDuration") is not None:
            damage["multiHitDuration"] = _num(info.get("multiHitDuration"), 0.0)
        if damage:
            phase["damage"] = damage
        sturn: Dict[str, Any] = {}
        for source, target in (
            ("forcePower", "forcePower"),
            ("randomPower", "randomPower"),
            ("airborneAngle", "airborneAngle"),
            ("targetRotateAngle", "targetRotateAngle"),
        ):
            value = _num(sturn_info.get(source))
            if value is not None:
                sturn[target] = value
        if sturn_info.get("isRotateTarget") is not None:
            sturn["isRotateTarget"] = _bool(sturn_info.get("isRotateTarget"))
        if sturn:
            phase["sturn"] = sturn
        phases.append(phase)

    move_types = {
        "moveToTargetWide": "ToTargetWide",
        "moveToTarget": "ToTargetWide",
        "moveRelative": "Relative",
        "moveEnemy": "MoveEnemy",
    }
    for kind, phase_type in move_types.items():
        for marker in markers_of_kind(timeline, kind):
            fraction = _fraction(marker.get("time"), duration)
            move_info = (marker.get("payload") or {}).get("moveInfo") or {}
            phase = {
                "type": phase_type,
                "start": fraction,
                "end": fraction,
                "steps": 1,
            }
            position = move_info.get("movePos")
            if isinstance(position, dict):
                phase["move"] = {
                    "x": _num(position.get("x"), 0.0),
                    "y": _num(position.get("y"), 0.0),
                    "z": _num(position.get("z"), 0.0),
                }
            if move_info.get("isRefreshDir") is not None and phase_type != "ToTargetWide":
                phase["isRefreshDir"] = _bool(move_info.get("isRefreshDir"))
            phases.append(phase)

    phases.sort(key=lambda p: (p["start"], p["type"]))
    coin["phases"] = phases


    hit_checkers: List[Dict[str, Any]] = []
    for marker in markers_of_kind(timeline, "hitCheaker"):
        info = (marker.get("payload") or {}).get("hitCheakerInfo") or {}
        entry: Dict[str, Any] = {"time": _fraction(marker.get("time"), duration)}
        delay = _num(info.get("isNextMotionCoinDelay"))
        if delay is not None:
            entry["isNextMotionCoinDelay"] = delay
        hit_checkers.append(entry)
    if hit_checkers:
        coin["hitCheckers"] = hit_checkers


    shakes: List[Dict[str, Any]] = []
    for marker in markers_of_kind(timeline, "cameraShake"):
        payload = marker.get("payload") or {}
        shake: Dict[str, Any] = {"start": _fraction(marker.get("time"), duration)}
        for source, target, default in (
            ("duration", "duration", 0.5),
            ("strength", "strength", 0.25),
            ("randomness", "randomness", 90.0),
        ):
            value = _num(payload.get(source), default)
            if value is not None:
                shake[target] = value
        if payload.get("vibrato") is not None:
            try:
                shake["vibrato"] = int(payload.get("vibrato"))
            except (TypeError, ValueError):
                pass
        if payload.get("fadeOut") is not None:
            shake["fadeOut"] = _bool(payload.get("fadeOut"), True)
        shakes.append(shake)
    if shakes:
        coin["shakes"] = shakes


    zooms: List[Dict[str, Any]] = []
    for track in tracks_of_kind(timeline, "camZoom"):
        for clip in track.get("clips", []) or []:
            info = ((clip.get("template") or {}) or {}).get("zoomInfo") or {}
            zoom: Dict[str, Any] = {
                "start": _fraction(clip.get("start"), duration),
                "duration": _num(clip.get("duration"), 0.5),
            }
            if info.get("SetZoomAttacker") is not None:
                zoom["attacker"] = _bool(info.get("SetZoomAttacker"), True)
            if info.get("SetZoomTargets") is not None:
                zoom["targets"] = _bool(info.get("SetZoomTargets"), True)
            for source, target in (
                ("SetZoomBetweenPoint", "between"),
                ("AxizY", "axisY"),
                ("size", "size"),
                ("duration", "zoomDuration"),
                ("focusSpeed", "focusSpeed"),
            ):
                value = _num(info.get(source))
                if value is not None:
                    zoom[target] = value
            if info.get("isRelative") is not None:
                zoom["isRelative"] = _bool(info.get("isRelative"), True)
            ease = ease_name(info.get("easeType"))
            if ease:
                zoom["easeType"] = ease
            zooms.append(zoom)
    if zooms:
        zooms.sort(key=lambda z: z["start"])
        coin["zooms"] = zooms


    rotates: List[Dict[str, Any]] = []
    for track in tracks_of_kind(timeline, "camRotate"):
        for clip in track.get("clips", []) or []:
            template = clip.get("template") or {}
            info = next(
                (v for v in template.values() if isinstance(v, dict)), {}
            ) if isinstance(template, dict) else {}
            rotate: Dict[str, Any] = {
                "start": _fraction(clip.get("start"), duration),
                "duration": _num(clip.get("duration"), 0.5),
            }
            angle = info.get("targetAngle") or info.get("TargetAngle")
            if isinstance(angle, dict):
                rotate["targetAngle"] = {
                    "x": _num(angle.get("x"), 0.0),
                    "y": _num(angle.get("y"), 0.0),
                    "z": _num(angle.get("z"), 0.0),
                }
            speed = _num(info.get("focusRotateSpeed"))
            if speed is not None:
                rotate["focusRotateSpeed"] = speed
            ease = ease_name(info.get("easeType"))
            if ease:
                rotate["easeType"] = ease
            rotates.append(rotate)
    if rotates:
        rotates.sort(key=lambda r: r["start"])
        coin["rotates"] = rotates


    vfx: List[int] = []
    for track in tracks_of_kind(timeline, "effectActivate"):
        index = track.get("effectTrackIndex")
        if index and (track.get("clips") or []):
            vfx.append(int(index))
    if vfx:
        coin["vfx"] = sorted(set(vfx))

    return coin


def motion_to_motions_json(coin_timelines: List[Optional[Dict[str, Any]]]) -> Dict[str, Any]:

    coins: List[Dict[str, Any]] = []
    for timeline in coin_timelines:
        if timeline is None:

            coins.append({"totalDuration": 0.0, "phases": []})
            continue
        coins.append(coin_to_motions_json(timeline))
    return {"$schema": SCHEMA_URL, "coins": coins}
