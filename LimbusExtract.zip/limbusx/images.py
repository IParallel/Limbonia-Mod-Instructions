from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image

from .env import Bundle, texture_format_name

ROT_NONE = 0
ROT_FLIP_H = 1
ROT_FLIP_V = 2
ROT_180 = 3
ROT_90 = 4

_ROT_TRANSFORM = {
    ROT_NONE: None,
    ROT_FLIP_H: Image.FLIP_LEFT_RIGHT,
    ROT_FLIP_V: Image.FLIP_TOP_BOTTOM,
    ROT_180: Image.ROTATE_180,
}

ROT_NAMES = {
    ROT_NONE: "None",
    ROT_FLIP_H: "FlipHorizontal",
    ROT_FLIP_V: "FlipVertical",
    ROT_180: "Rotate180",
    ROT_90: "Rotate90",
}


class UnsupportedPacking(Exception):
    pass


def _render_data_key(value: Any) -> Optional[Tuple[Any, Any]]:
    if not isinstance(value, dict):
        return None
    guid = value.get("first")
    local_id = value.get("second")
    if isinstance(guid, dict):
        guid_key: Any = tuple(guid.values())
    elif isinstance(guid, (list, tuple)):
        guid_key = tuple(guid)
    else:
        guid_key = guid
    return (guid_key, local_id)


def decode_settings_raw(raw: Any) -> Dict[str, Any]:
    value = int(raw or 0)
    return {
        "settingsRaw": value,
        "packed": bool(value & 1),
        "packingMode": (value >> 1) & 1,
        "packingRotation": (value >> 2) & 0xF,
        "packingRotationName": ROT_NAMES.get((value >> 2) & 0xF, f"unknown({(value >> 2) & 0xF})"),
        "meshType": (value >> 6) & 1,
    }


class SpriteExporter:


    def __init__(self, bundle: Bundle) -> None:
        self.bundle = bundle
        self._atlas_map: Optional[Dict[Tuple[Any, Any], Tuple[str, Dict[str, Any]]]] = None
        self._page_cache: Dict[int, Image.Image] = {}
        self._written: Dict[int, str] = {}
        self.records: Dict[str, Dict[str, Any]] = {}
        self.errors: List[str] = []
        self._used_filenames: Dict[str, int] = {}


    def _atlas(self) -> Dict[Tuple[Any, Any], Tuple[str, Dict[str, Any]]]:
        if self._atlas_map is None:
            table: Dict[Tuple[Any, Any], Tuple[str, Dict[str, Any]]] = {}
            for obj in self.bundle.of_type("SpriteAtlas"):
                tt = self.bundle.tt_of(obj)
                if not tt:
                    continue
                atlas_name = str(tt.get("m_Name") or "")
                for entry in tt.get("m_RenderDataMap", []) or []:
                    if isinstance(entry, (list, tuple)):
                        key_raw, value = entry[0], entry[1]
                    else:
                        key_raw, value = entry.get("first"), entry.get("second")
                    key = _render_data_key(key_raw)
                    if key is not None and isinstance(value, dict):
                        table[key] = (atlas_name, value)
            self._atlas_map = table
        return self._atlas_map

    def _page_image(self, path_id: int) -> Optional[Image.Image]:
        if path_id in self._page_cache:
            return self._page_cache[path_id]
        obj = self.bundle.by_path_id.get(path_id)
        if obj is None:
            return None
        try:
            image = obj.read().image
        except Exception as exc:
            self.errors.append(f"atlas page {path_id} failed to decode: {exc}")
            return None
        self._page_cache[path_id] = image
        return image


    def _unique_filename(self, base: str, path_id: int) -> str:
        safe = "".join(c if (c.isalnum() or c in "._-") else "_" for c in base) or "sprite"
        count = self._used_filenames.get(safe, 0)
        self._used_filenames[safe] = count + 1
        if count == 0:
            return f"{safe}.png"


        return f"{safe}__{path_id}.png"

    def export(self, path_id: int, out_dir: str) -> Optional[str]:

        if not path_id:
            return None
        if path_id in self._written:
            return self._written[path_id]

        sprite_tt = self.bundle.tt(path_id)
        if not sprite_tt:
            self.errors.append(f"sprite {path_id} could not be read")
            return None

        name = str(sprite_tt.get("m_Name") or f"sprite_{path_id}")
        render_data = sprite_tt.get("m_RD") or {}
        texture_ref = render_data.get("texture") or {}
        pivot = sprite_tt.get("m_Pivot") or {}
        rect = sprite_tt.get("m_Rect") or {}

        record: Dict[str, Any] = {
            "spriteName": name,
            "spritePathID": path_id,
            "pivot": {
                "x": _num(pivot.get("x")),
                "y": _num(pivot.get("y")),
            },
            "ppu": _num(sprite_tt.get("m_PixelsToUnits")),
            "spriteRect": _rect(rect),
        }

        os.makedirs(out_dir, exist_ok=True)
        image: Optional[Image.Image] = None

        if texture_ref.get("m_PathID"):
            if texture_ref.get("m_FileID"):
                self.errors.append(
                    f"sprite {name!r} ({path_id}) points at a texture in another "
                    "bundle; cross-bundle sprites are not resolved"
                )
                return None
            image, extra = self._export_loose(path_id, texture_ref)
            record.update(extra)
        else:
            try:
                image, extra = self._export_from_atlas(sprite_tt)
            except UnsupportedPacking as exc:
                self.errors.append(f"sprite {name!r} ({path_id}): {exc}")
                return None
            record.update(extra)

        if image is None:
            self.errors.append(f"sprite {name!r} ({path_id}) produced no image")
            return None

        filename = self._unique_filename(name, path_id)
        image.save(os.path.join(out_dir, filename))
        record["file"] = filename
        record["pixelSize"] = {"w": image.size[0], "h": image.size[1]}


        if image.mode == "RGBA":
            alpha = image.getchannel("A")
            lo, hi = alpha.getextrema()
            record["alphaRange"] = [lo, hi]
            if lo == hi:
                record.setdefault("warnings", []).append(
                    f"alpha channel is flat ({lo}); cut may be wrong"
                )
        else:
            record.setdefault("warnings", []).append(f"image mode is {image.mode}, not RGBA")

        self._written[path_id] = filename
        self.records[filename] = record
        return filename

    def _export_loose(
        self, path_id: int, texture_ref: Dict[str, Any]
    ) -> Tuple[Optional[Image.Image], Dict[str, Any]]:
        texture_tt = self.bundle.tt(texture_ref.get("m_PathID")) or {}
        extra = {
            "source": "loose",
            "sourceTexture": str(texture_tt.get("m_Name") or ""),
            "sourceTextureFormat": texture_format_name(texture_tt.get("m_TextureFormat")),
            "sourceTextureSize": {
                "w": texture_tt.get("m_Width"),
                "h": texture_tt.get("m_Height"),
            },
            "lossless": texture_format_name(texture_tt.get("m_TextureFormat"))
            in ("RGBA32", "ARGB32", "RGB24", "BGRA32"),
        }
        obj = self.bundle.by_path_id.get(path_id)
        if obj is None:
            return None, extra
        try:


            return obj.read().image, extra
        except Exception as exc:
            self.errors.append(f"loose sprite {path_id} decode failed: {exc}")
            return None, extra

    def _export_from_atlas(
        self, sprite_tt: Dict[str, Any]
    ) -> Tuple[Optional[Image.Image], Dict[str, Any]]:
        key = _render_data_key(sprite_tt.get("m_RenderDataKey"))
        hit = self._atlas().get(key) if key else None
        if not hit:
            raise UnsupportedPacking(
                "texture stripped and no SpriteAtlas render-data entry matched "
                "m_RenderDataKey in this bundle"
            )
        atlas_name, render_data = hit
        settings = decode_settings_raw(render_data.get("settingsRaw"))
        rotation = settings["packingRotation"]

        page_ref = render_data.get("texture") or {}
        if page_ref.get("m_FileID"):
            raise UnsupportedPacking("atlas page lives in another bundle")
        page_tt = self.bundle.tt(page_ref.get("m_PathID")) or {}
        page = self._page_image(page_ref.get("m_PathID"))
        if page is None:
            raise UnsupportedPacking("atlas page texture could not be decoded")

        rect = render_data.get("textureRect") or {}
        x = int(round(float(rect.get("x") or 0)))
        y = int(round(float(rect.get("y") or 0)))
        w = int(round(float(rect.get("width") or 0)))
        h = int(round(float(rect.get("height") or 0)))
        if w <= 0 or h <= 0:
            raise UnsupportedPacking(f"degenerate textureRect {w}x{h}")
        page_w, page_h = page.size
        if x < 0 or y < 0 or x + w > page_w or y + h > page_h:
            raise UnsupportedPacking(
                f"textureRect ({x},{y},{w},{h}) falls outside page {page_w}x{page_h}"
            )


        crop = page.crop((x, page_h - y - h, x + w, page_h - y))

        if rotation == ROT_90:
            raise UnsupportedPacking(
                "packingRotation=Rotate90 has never been observed in this game's "
                "data and the rotation direction is therefore unverified; refusing "
                "to guess. Report this sprite so the direction can be pinned down."
            )
        if rotation not in _ROT_TRANSFORM:
            raise UnsupportedPacking(f"unknown packingRotation {rotation}")
        transform = _ROT_TRANSFORM[rotation]
        if transform is not None:
            crop = crop.transpose(transform)

        extra = {
            "source": "atlas",
            "atlas": atlas_name,
            "atlasPage": str(page_tt.get("m_Name") or ""),
            "atlasPageFormat": texture_format_name(page_tt.get("m_TextureFormat")),
            "atlasRect": {"x": x, "y": y, "w": w, "h": h},
            "lossless": texture_format_name(page_tt.get("m_TextureFormat"))
            in ("RGBA32", "ARGB32", "RGB24", "BGRA32"),
        }
        extra.update(settings)
        if not extra["lossless"]:
            extra.setdefault("warnings", []).append(
                f"cut from a {extra['atlasPageFormat']} page; block-compression "
                "artefacts are baked in and the original lossless frame is not in "
                "the shipped data"
            )
        return crop, extra

    def export_texture(self, path_id: int, out_path: str) -> Optional[Dict[str, Any]]:

        obj = self.bundle.by_path_id.get(path_id)
        tt = self.bundle.tt(path_id)
        if obj is None or tt is None:
            return None
        try:
            image = obj.read().image
        except Exception as exc:
            self.errors.append(f"texture {path_id} decode failed: {exc}")
            return None
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        image.save(out_path)
        return {
            "name": str(tt.get("m_Name") or ""),
            "file": os.path.basename(out_path),
            "format": texture_format_name(tt.get("m_TextureFormat")),
            "size": {"w": image.size[0], "h": image.size[1]},
            "image": image,
        }


def _num(value: Any) -> Any:
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        return value


def _rect(rect: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "x": _num(rect.get("x")),
        "y": _num(rect.get("y")),
        "w": _num(rect.get("width")),
        "h": _num(rect.get("height")),
    }
