"""Sprite geometry in the exact local space used by tracked Mang clones."""
import math


def effect_alpha(image):
    """Make an opaque black-backed effect mask usable by the browser's alpha compositor.

    Unpremultiply RGB as brightness becomes coverage, keeping dim edges bright
    rather than multiplying their brightness a second time during alpha blending.
    Authored alpha textures are already usable and must remain unchanged.
    """
    if image.getchannel('A').getextrema() != (255, 255):
        return image
    corners = [(0, 0), (image.width-1, 0), (0, image.height-1), (image.width-1, image.height-1)]
    if any(max(image.getpixel(p)[:3]) > 0 for p in corners):
        return image
    result = image.copy()
    result.putdata([(round(r*255/a), round(g*255/a), round(b*255/a), a) if (a := max(r, g, b)) else (0, 0, 0, 0)
                    for r, g, b, _ in image.getdata()])
    return result


def multiply(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def transform(tt, root=False):
    s = tt.get('m_LocalScale') or dict(x=1, y=1, z=1)
    p = {} if root else tt.get('m_LocalPosition') or {}
    q = dict(x=0, y=0, z=0, w=1) if root else tt.get('m_LocalRotation') or dict(w=1)
    x, y, z, w = (q.get(k, 0) for k in ('x', 'y', 'z', 'w'))
    r = [[1-2*y*y-2*z*z, 2*x*y-2*z*w, 2*x*z+2*y*w],
         [2*x*y+2*z*w, 1-2*x*x-2*z*z, 2*y*z-2*x*w],
         [2*x*z-2*y*w, 2*y*z+2*x*w, 1-2*x*x-2*y*y]]
    return [[r[i][j] * s.get('xyz'[j], 1) for j in range(3)] + [p.get('xyz'[i], 0)] for i in range(3)] + [[0, 0, 0, 1]]


def export_mang_artwork(bundle, appearance, controller, sprite_image, exporter):
    def components(go):
        return [c.get('component', c) for c in go.get('m_Component', [])]

    transforms = {o.path_id: bundle.tt_of(o) for o in bundle.of_type('Transform')}
    go_transforms = {t['m_GameObject']['m_PathID']: pid for pid, t in transforms.items() if t}
    root_go = appearance.tt['m_GameObject']['m_PathID']
    controllers = []

    def discover(pid):
        t = transforms[pid]
        go = bundle.pptr(t['m_GameObject']) or {}
        for ref in components(go):
            if bundle.type_name(ref.get('m_PathID')) == 'MonoBehaviour':
                ct = bundle.pptr(ref) or {}
                if 'mangList' in ct:
                    controllers.append((pid, ct))
        for child in t.get('m_Children', []):
            if child.get('m_FileID'):
                raise ValueError('Mang hierarchy references another bundle.')
            discover(child['m_PathID'])

    discover(go_transforms[root_go])
    if not 0 <= controller < len(controllers):
        raise ValueError('The source has no Mang controller at this index.')
    root, ct = controllers[controller]
    rings = {ref['m_PathID']: i for i, ref in enumerate(ct['mangList'])}
    layers, images = [], {}

    def visit(pid, matrix, ring=None):
        t = transforms[pid]
        go_id = t['m_GameObject']['m_PathID']
        ring = rings.get(go_id, ring)
        go = bundle.pptr(t['m_GameObject']) or {}
        if ring is not None:
            for ref in components(go):
                if bundle.type_name(ref.get('m_PathID')) != 'SpriteRenderer':
                    continue
                renderer = bundle.pptr(ref) or {}
                sprite = renderer.get('m_Sprite') or {}
                if sprite.get('m_FileID'):
                    raise ValueError('Mang artwork references a sprite in another bundle.')
                sid = sprite.get('m_PathID')
                if not sid:
                    continue
                if sid not in images:
                    images[sid] = sprite_image(bundle, exporter, sid, black_background=True)
                # Convert Unity's Y-up matrix to SVG's Y-down matrix. Sprite rect itself is also Y-down.
                flip_x = -1 if renderer.get('m_FlipX') else 1
                flip_y = -1 if renderer.get('m_FlipY') else 1
                m = [matrix[0][0]*flip_x, -matrix[1][0]*flip_x,
                     -matrix[0][1]*flip_y, matrix[1][1]*flip_y, matrix[0][3], -matrix[1][3]]
                if not all(math.isfinite(v) for v in m):
                    raise ValueError('Mang artwork has a non-finite transform.')
                layers.append(dict(**images[sid], ring=ring, matrix=m, order=renderer.get('m_SortingOrder', 0)))
        for child in t.get('m_Children', []):
            cid = child['m_PathID']
            visit(cid, multiply(matrix, transform(transforms[cid])), ring)

    visit(root, transform(transforms[root], root=True))
    if not layers or len(layers) > 128:
        raise ValueError('This Mang source has no supported sprite artwork.')
    layers.sort(key=lambda layer: layer['order'])
    return dict(version=1, layers=layers, capacity=len(rings), source=appearance.name, controller=controller)
