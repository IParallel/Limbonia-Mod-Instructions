from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Set

from .env import Bundle


MOTION_NAMES: Dict[int, str] = {
    0: "Default", 1: "Dead", 2: "Evade", 3: "Guard", 4: "Damaged", 5: "Move",
    6: "Attack", 7: "S1", 8: "S2", 9: "S3", 10: "S4", 11: "S5", 12: "S6",
    13: "S7", 14: "S8", 15: "S9", 16: "S10", 17: "Parrying", 18: "Idle",
    20: "Special1", 37: "Duel_Win", 48: "Reload",
}


def motion_name(detail: Any) -> str:
    try:
        value = int(detail)
    except (TypeError, ValueError):
        return f"Motion_{detail}"
    return MOTION_NAMES.get(value, f"Motion_{value}")


def is_named_motion(detail: Any) -> bool:
    try:
        return int(detail) in MOTION_NAMES
    except (TypeError, ValueError):
        return False


class Appearance:
    def __init__(
        self,
        bundle: Bundle,
        component_path_id: int,
        component_tt: Dict[str, Any],
        game_object_name: str,
    ) -> None:
        self.bundle = bundle
        self.component_path_id = component_path_id
        self.tt = component_tt
        self.name = game_object_name
        char_info = component_tt.get("charInfo") or {}
        self.declared_id = str(char_info.get("appearanceID") or "")
        self.spine_skin_count = len(component_tt.get("_spineSkins") or [])

    @property
    def id_from_name(self) -> Optional[int]:
        head = self.name.split("_", 1)[0]
        return int(head) if head.isdigit() else None

    def slots(self) -> List[Dict[str, Any]]:

        out: List[Dict[str, Any]] = []
        for index, entry in enumerate(self.tt.get("motionList") or []):
            if not isinstance(entry, dict):
                continue
            timelines = entry.get("timelineAssets") or []
            motion_objects = entry.get("motionObjects") or []
            detail = entry.get("_motiondetail")
            coins = []
            for coin_index, ref in enumerate(timelines):
                coins.append(
                    {
                        "coinIndex": coin_index,
                        "timelinePathID": (ref or {}).get("m_PathID"),
                        "timelineFileID": (ref or {}).get("m_FileID"),
                    }
                )
            out.append(
                {
                    "slotIndex": index,
                    "motionDetail": detail,
                    "motionName": motion_name(detail),
                    "motionNameIsKnown": is_named_motion(detail),
                    "isSpineAnim": bool(entry.get("isSpineAnim")),
                    "coinCount": len(timelines),
                    "motionObjectCount": len(motion_objects),
                    "coins": coins,
                }
            )
        return out

    def summary(self) -> Dict[str, Any]:
        slots = self.slots()
        duplicate_details = _duplicate_details(slots)
        return {
            "appearanceName": self.name,
            "appearanceIdFromName": self.id_from_name,
            "declaredAppearanceId": self.declared_id or None,
            "componentPathID": self.component_path_id,
            "spineSkinCount": self.spine_skin_count,
            "slotCount": len(slots),
            "spineDrivenMotions": [
                s["motionName"] for s in slots if s["isSpineAnim"]
            ],
            "duplicateMotionDetails": duplicate_details,
            "slots": slots,
        }


def _duplicate_details(slots: List[Dict[str, Any]]) -> List[Any]:
    seen: Dict[Any, int] = {}
    for slot in slots:
        detail = slot.get("motionDetail")
        seen[detail] = seen.get(detail, 0) + 1
    return sorted(
        [detail for detail, count in seen.items() if count > 1],
        key=lambda d: (d is None, d),
    )


def find_appearances(bundle: Bundle) -> List[Appearance]:

    found: List[Appearance] = []
    for obj in bundle.of_type("MonoBehaviour"):
        tt = bundle.tt_of(obj)
        if not tt or "motionList" not in tt:
            continue
        game_object = bundle.pptr(tt.get("m_GameObject") or {}) or {}
        name = str(game_object.get("m_Name") or "")
        found.append(Appearance(bundle, obj.path_id, tt, name))
    found.sort(key=lambda a: a.name)
    return found


def match_appearance(
    appearances: List[Appearance], wanted: str
) -> Optional[Appearance]:

    lowered = wanted.lower()
    for appearance in appearances:
        if appearance.name.lower() == lowered:
            return appearance
    if wanted.isdigit():
        target = int(wanted)
        for appearance in appearances:
            if appearance.id_from_name == target:
                return appearance
        for appearance in appearances:
            if appearance.declared_id == wanted:
                return appearance
    for appearance in appearances:
        if lowered in appearance.name.lower():
            return appearance
    return None


def _components_of(bundle: Bundle, appearance: "Appearance") -> List[int]:
    game_object = bundle.pptr(appearance.tt.get("m_GameObject") or {}) or {}
    found: List[int] = []
    for component in game_object.get("m_Component") or []:
        if isinstance(component, (list, tuple)):
            ref = component[1] if len(component) > 1 else component[0]
        elif isinstance(component, dict):
            ref = component.get("component") or component.get("second") or component
        else:
            continue
        path_id = (ref or {}).get("m_PathID") if isinstance(ref, dict) else None
        if path_id:
            found.append(path_id)
    return found


def animator_clip_ids(bundle: Bundle, appearance: "Appearance") -> Set[int]:

    owned: Set[int] = set()
    for path_id in _components_of(bundle, appearance):
        if bundle.type_name(path_id) != "Animator":
            continue
        animator = bundle.tt(path_id) or {}
        controller = bundle.pptr(animator.get("m_Controller") or {}) or {}
        for clip in controller.get("m_AnimationClips") or []:
            clip_id = (clip or {}).get("m_PathID")
            if clip_id:
                owned.add(clip_id)
    return owned


def spine_skeleton_ids(bundle: Bundle, appearance: "Appearance") -> Set[int]:

    owned: Set[int] = set()
    for ref in appearance.tt.get("_spineSkins") or []:
        holder = bundle.pptr(ref or {}) or {}
        animation = bundle.pptr(holder.get("_spine_Animation") or {}) or {}
        data = (animation.get("skeletonDataAsset") or {}).get("m_PathID")
        if data:
            owned.add(data)
    return owned


def claimed_by_siblings(
    bundle: Bundle,
    appearance: "Appearance",
    claim: Callable[[Bundle, "Appearance"], Set[int]],
) -> Set[int]:

    mine = claim(bundle, appearance)
    theirs: Set[int] = set()
    for other in find_appearances(bundle):
        if other.component_path_id == appearance.component_path_id:
            continue
        theirs |= claim(bundle, other)
    return theirs - mine


def shared_timeline_report(slots: List[Dict[str, Any]]) -> Dict[str, List[str]]:

    users: Dict[int, List[str]] = {}
    for slot in slots:
        for coin in slot.get("coins", []):
            path_id = coin.get("timelinePathID")
            if not path_id:
                continue
            label = f"{slot['motionName']}[slot {slot['slotIndex']}] coin {coin['coinIndex']}"
            users.setdefault(path_id, []).append(label)
    return {str(k): v for k, v in users.items() if len(v) > 1}
