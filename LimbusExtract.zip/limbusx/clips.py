from __future__ import annotations

import struct
from typing import Any, Dict, List, Optional

CLASSID_SPRITE_RENDERER = 212
CUSTOMTYPE_SPRITE = 23


CLASSID_NAMES = {
    1: "GameObject", 4: "Transform", 95: "Animator", 114: "MonoBehaviour",
    198: "ParticleSystem", 199: "ParticleSystemRenderer", 210: "SortingGroup",
    212: "SpriteRenderer", 224: "RectTransform",
}

_SENTINEL = -1e30


def decode_streamed_clip(words: List[int]) -> List[Dict[str, Any]]:

    if not words:
        return []
    try:
        buf = struct.pack(f"<{len(words)}I", *[w & 0xFFFFFFFF for w in words])
    except struct.error:
        return []
    frames: List[Dict[str, Any]] = []
    offset = 0
    size = len(buf)
    while offset + 8 <= size:
        time, curve_count = struct.unpack_from("<fi", buf, offset)
        offset += 8
        if curve_count < 0 or offset + curve_count * 20 > size:
            break
        keys = []
        for _ in range(curve_count):
            index, c0, c1, c2, c3 = struct.unpack_from("<i4f", buf, offset)
            offset += 20
            keys.append({"index": index, "coeffs": (c0, c1, c2, c3)})
        if time < _SENTINEL:
            time = 0.0
        frames.append({"time": float(time), "keys": keys})
    return frames


def _binding_dimension(binding: Dict[str, Any]) -> int:

    if int(binding.get("typeID", 0)) == 4:
        attribute = int(binding.get("attribute", 0))
        if attribute in (1, 3, 4):
            return 3
        if attribute == 2:
            return 4
    return 1


def _curve_index_map(bindings: List[Dict[str, Any]]) -> List[tuple]:

    entries: List[tuple] = []
    cursor = 0
    for binding in bindings:
        dimension = _binding_dimension(binding)
        entries.append((cursor, dimension, binding))
        cursor += dimension
    return entries


def _binding_for_index(entries: List[tuple], index: int) -> Optional[Dict[str, Any]]:
    for first, dimension, binding in entries:
        if first <= index < first + dimension:
            return binding
    return None


def _is_sprite_binding(binding: Optional[Dict[str, Any]]) -> bool:
    if not binding or not binding.get("isPPtrCurve"):
        return False
    return (
        int(binding.get("typeID", 0)) == CLASSID_SPRITE_RENDERER
        and int(binding.get("customType", 0)) == CUSTOMTYPE_SPRITE
    )


def _sprite_bindings(bindings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [b for b in bindings if _is_sprite_binding(b)]


def read_flipbook(clip_tt: Dict[str, Any]) -> Optional[Dict[str, Any]]:

    binding_const = clip_tt.get("m_ClipBindingConstant") or {}
    bindings = binding_const.get("genericBindings") or []
    mapping = binding_const.get("pptrCurveMapping") or []
    sprite_bindings = _sprite_bindings(bindings)
    if not sprite_bindings or not mapping:
        return None

    warnings: List[str] = []
    muscle = clip_tt.get("m_MuscleClip") or {}
    clip = (muscle.get("m_Clip") or {}).get("data") or muscle.get("m_Clip") or {}
    streamed = clip.get("m_StreamedClip") or {}
    dense = clip.get("m_DenseClip") or {}
    constant = clip.get("m_ConstantClip") or {}

    entries = _curve_index_map(bindings)

    layers: Dict[Any, List[Dict[str, Any]]] = {}
    source = "streamedClip"
    out_of_range = 0

    def add_frame(layer_key: Any, time: float, mapping_index: int) -> None:
        nonlocal out_of_range
        if not (0 <= mapping_index < len(mapping)):
            out_of_range += 1
            return
        ref = mapping[mapping_index] or {}
        layers.setdefault(layer_key, []).append(
            {
                "time": round(float(time), 6),
                "mappingIndex": mapping_index,
                "spritePathID": ref.get("m_PathID"),
                "spriteFileID": ref.get("m_FileID"),
            }
        )


    legacy_curves = clip_tt.get("m_PPtrCurves") or []
    if legacy_curves:
        source = "m_PPtrCurves"
        for position, curve in enumerate(legacy_curves):
            for key in curve.get("curve", []) or []:
                ref = key.get("value") or {}
                layers.setdefault(f"pptrCurve{position}", []).append(
                    {
                        "time": round(float(key.get("time", 0.0)), 6),
                        "mappingIndex": None,
                        "spritePathID": ref.get("m_PathID"),
                        "spriteFileID": ref.get("m_FileID"),
                    }
                )
    else:
        for entry in decode_streamed_clip(streamed.get("data") or []):
            for key in entry["keys"]:
                index = int(key["index"])
                binding = _binding_for_index(entries, index)
                if not _is_sprite_binding(binding):


                    continue
                add_frame(
                    binding.get("path", index),
                    entry["time"],
                    int(round(key["coeffs"][3])),
                )


        highest_streamed = -1
        for entry in decode_streamed_clip(streamed.get("data") or []):
            for key in entry["keys"]:
                highest_streamed = max(highest_streamed, int(key["index"]))
        streamed_base = max(int(streamed.get("curveCount") or 0), highest_streamed + 1)
        dense_count = int(dense.get("m_CurveCount") or 0)

        dense_data = dense.get("m_SampleArray") or []
        dense_frames = int(dense.get("m_FrameCount") or 0)
        dense_rate = float(dense.get("m_SampleRate") or 0) or 60.0
        dense_begin = float(dense.get("m_BeginTime") or 0.0)
        for position in range(dense_count):
            index = streamed_base + position
            binding = _binding_for_index(entries, index)
            if not _is_sprite_binding(binding):
                continue
            layer_key = binding.get("path", index)
            previous = None
            for frame_number in range(dense_frames):
                offset = frame_number * dense_count + position
                if offset >= len(dense_data):
                    break
                value = int(round(float(dense_data[offset])))
                if value == previous:
                    continue
                previous = value
                add_frame(layer_key, dense_begin + frame_number / dense_rate, value)

        constant_data = constant.get("data") or []
        for position, value in enumerate(constant_data):
            index = streamed_base + dense_count + position
            binding = _binding_for_index(entries, index)
            if not _is_sprite_binding(binding):
                continue
            layer_key = binding.get("path", index)
            if layers.get(layer_key):


                continue
            add_frame(layer_key, float(muscle.get("m_StartTime") or 0.0), int(round(float(value))))
            warnings.append(
                f"layer {layer_key} was recovered from the CONSTANT curve block "
                "(a single sprite held for the whole clip)"
            )

    if out_of_range:
        warnings.append(
            f"{out_of_range} sprite key(s) indexed outside pptrCurveMapping "
            f"(len {len(mapping)}) and were dropped"
        )

    layer_list: List[Dict[str, Any]] = []
    for layer_key, frames in layers.items():
        frames.sort(key=lambda f: f["time"])
        layer_list.append(
            {
                "bindingPath": layer_key,
                "bindingPathIsCrc32": isinstance(layer_key, int),
                "frameCount": len(frames),
                "frames": frames,
            }
        )
    layer_list.sort(key=lambda entry: (-entry["frameCount"], str(entry["bindingPath"])))

    primary = layer_list[0]["frames"] if layer_list else []
    null_refs = sum(1 for frame in primary if not frame.get("spritePathID"))
    if null_refs:
        warnings.append(
            f"{null_refs} frame reference(s) are null in pptrCurveMapping "
            "(stripped at build time); they are reported as missing"
        )


    return {
        "name": str(clip_tt.get("m_Name") or ""),
        "frameSource": source,
        "sampleRate": clip_tt.get("m_SampleRate"),
        "startTime": muscle.get("m_StartTime"),
        "stopTime": muscle.get("m_StopTime"),
        "mappingCount": len(mapping),
        "spriteCurveCount": len(sprite_bindings),
        "layerCount": len(layer_list),
        "layers": layer_list,
        "frames": primary,
        "warnings": warnings,
    }


def describe_clip(clip_tt: Dict[str, Any]) -> Dict[str, Any]:

    binding_const = clip_tt.get("m_ClipBindingConstant") or {}
    bindings = binding_const.get("genericBindings") or []
    kinds: Dict[str, int] = {}
    for binding in bindings:
        type_id = int(binding.get("typeID", 0))
        label = CLASSID_NAMES.get(type_id, f"class{type_id}")
        if binding.get("isPPtrCurve"):
            label += "(pptr)"
        kinds[label] = kinds.get(label, 0) + 1
    muscle = clip_tt.get("m_MuscleClip") or {}
    return {
        "name": str(clip_tt.get("m_Name") or ""),
        "stopTime": muscle.get("m_StopTime"),
        "sampleRate": clip_tt.get("m_SampleRate"),
        "bindingCount": len(bindings),
        "bindingKinds": kinds,
        "hasSpriteCurve": bool(_sprite_bindings(bindings)),


        "transformBindingsAreCrc32Paths": any(
            int(b.get("typeID", 0)) == 4 for b in bindings
        ),
    }
