from __future__ import annotations

import sys
from typing import Any, Dict, Iterator, List, Optional

import UnityPy
from UnityPy import config as unitypy_config


UNITY_VERSION = "6000.3.12f1"

unitypy_config.FALLBACK_UNITY_VERSION = UNITY_VERSION


def init_stdout() -> None:

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:

            pass


TEXTURE_FORMATS: Dict[int, str] = {
    1: "Alpha8", 2: "ARGB4444", 3: "RGB24", 4: "RGBA32", 5: "ARGB32",
    7: "RGB565", 9: "R16", 10: "DXT1", 12: "DXT5", 13: "RGBA4444",
    14: "BGRA32", 15: "RHalf", 16: "RGHalf", 17: "RGBAHalf", 18: "RFloat",
    19: "RGFloat", 20: "RGBAFloat", 21: "YUY2", 22: "RGB9e5Float",
    24: "BC6H", 25: "BC7", 26: "BC4", 27: "BC5", 28: "DXT1Crunched",
    29: "DXT5Crunched", 30: "PVRTC_RGB2", 31: "PVRTC_RGBA2",
    32: "PVRTC_RGB4", 33: "PVRTC_RGBA4", 34: "ETC_RGB4", 41: "EAC_R",
    45: "ETC2_RGB", 46: "ETC2_RGBA1", 47: "ETC2_RGBA8",
}


def texture_format_name(value: Any) -> str:
    try:
        return TEXTURE_FORMATS.get(int(value), str(value))
    except (TypeError, ValueError):
        return str(value)


class Bundle:


    def __init__(self, path: str, label: Optional[str] = None) -> None:
        self.path = str(path)
        self.label = label or self.path
        self.env = UnityPy.load(self.path)
        self.objects: List[Any] = list(self.env.objects)
        self.by_path_id: Dict[int, Any] = {o.path_id: o for o in self.objects}
        self._tt_cache: Dict[int, Optional[Dict[str, Any]]] = {}
        self.read_errors: Dict[int, str] = {}
        self.partial_reads: Dict[int, str] = {}


    def of_type(self, *type_names: str) -> Iterator[Any]:
        wanted = set(type_names)
        for obj in self.objects:
            if obj.type.name in wanted:
                yield obj

    def type_name(self, path_id: int) -> Optional[str]:
        obj = self.by_path_id.get(path_id)
        return obj.type.name if obj is not None else None

    def tt(self, path_id: Optional[int]) -> Optional[Dict[str, Any]]:

        if not path_id:
            return None
        if path_id in self._tt_cache:
            return self._tt_cache[path_id]
        obj = self.by_path_id.get(path_id)
        result: Optional[Dict[str, Any]] = None
        if obj is not None:
            try:
                result = obj.read_typetree()
            except Exception as exc:
                result, note = self._partial_read(obj, exc)
                if result is None:
                    self.read_errors[path_id] = _one_line(exc)
                elif note:
                    self.partial_reads[path_id] = note
        self._tt_cache[path_id] = result
        return result

    def _partial_read(
        self, obj: Any, original: Exception
    ) -> tuple[Optional[Dict[str, Any]], Optional[str]]:

        try:
            nodes = obj.get_typetree_nodes()
        except Exception:
            return None, None
        if not nodes:
            return None, None
        base_level = nodes[0].m_Level


        boundaries = [
            index
            for index, node in enumerate(nodes)
            if index > 0 and node.m_Level == base_level + 1
        ]
        for cut in reversed(boundaries):
            try:
                partial = obj.read_typetree(nodes[:cut])
            except Exception:
                continue
            dropped = [
                nodes[index].m_Name
                for index in boundaries
                if index >= cut
            ]
            return partial, (
                f"partial read: recovered {len(partial)} field(s), dropped "
                f"{dropped} because the strict read failed ({_one_line(original)})"
            )
        return None, None

    def tt_of(self, obj: Any) -> Optional[Dict[str, Any]]:
        return self.tt(obj.path_id)

    def pptr(self, ref: Any) -> Optional[Dict[str, Any]]:

        if not isinstance(ref, dict):
            return None
        if ref.get("m_FileID"):
            return None
        return self.tt(ref.get("m_PathID"))


    def container(self) -> List[str]:

        for obj in self.of_type("AssetBundle"):
            tt = self.tt_of(obj)
            if not tt:
                continue
            paths = []
            for entry in tt.get("m_Container", []) or []:
                key = entry[0] if isinstance(entry, (list, tuple)) else entry.get("first")
                if key:
                    paths.append(str(key))
            return sorted(set(paths))
        return []


def load_bundle(path: str, label: Optional[str] = None) -> Bundle:
    return Bundle(path, label)


def name_of(tt: Optional[Dict[str, Any]]) -> str:
    if not tt:
        return ""
    return str(tt.get("m_Name") or "")


def _one_line(exc: Exception) -> str:
    text = f"{type(exc).__name__}: {exc}"
    return " / ".join(part.strip() for part in text.splitlines() if part.strip())
