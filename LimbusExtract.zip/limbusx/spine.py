from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image

from .env import Bundle, texture_format_name


def parse_atlas(text: str) -> List[Dict[str, Any]]:

    pages: List[Dict[str, Any]] = []
    current_page: Optional[Dict[str, Any]] = None
    current_region: Optional[Dict[str, Any]] = None
    expect_page_name = True

    for raw_line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw_line.strip()
        if not line:
            expect_page_name = True
            current_region = None
            continue
        if expect_page_name:
            current_page = {"page": line, "props": {}, "regions": []}
            pages.append(current_page)
            current_region = None
            expect_page_name = False
            continue
        if ":" in line:
            key, _, value = line.partition(":")
            target = current_region["props"] if current_region else current_page["props"]
            target[key.strip()] = value.strip()
            continue
        current_region = {"name": line, "props": {}}
        current_page["regions"].append(current_region)
    return pages


def _ints(value: Optional[str]) -> List[int]:
    if not value:
        return []
    out: List[int] = []
    for part in value.split(","):
        part = part.strip()
        try:
            out.append(int(float(part)))
        except ValueError:
            pass
    return out


def declared_page_size(page: Dict[str, Any]) -> Optional[Tuple[int, int]]:
    values = _ints(page["props"].get("size"))
    return (values[0], values[1]) if len(values) >= 2 else None


def region_bounds(region: Dict[str, Any]) -> Optional[Tuple[int, int, int, int]]:
    values = _ints(region["props"].get("bounds"))
    return tuple(values[:4]) if len(values) >= 4 else None


def region_degrees(region: Dict[str, Any]) -> int:
    value = (region["props"].get("rotate") or "").strip().lower()
    if not value or value == "false":
        return 0
    if value == "true":
        return 90
    try:
        return int(float(value))
    except ValueError:
        return 0


def _text_asset_bytes(bundle: Bundle, ref: Dict[str, Any]) -> Optional[bytes]:
    tt = bundle.pptr(ref or {})
    if not tt:
        return None
    script = tt.get("m_Script")
    if script is None:
        return None
    if isinstance(script, str):
        return script.encode("utf-8", "surrogateescape")
    return bytes(script)


def _material_main_textures(bundle: Bundle, material_ref: Dict[str, Any]) -> List[int]:
    tt = bundle.pptr(material_ref or {})
    if not tt:
        return []
    saved = tt.get("m_SavedProperties") or {}
    found: List[int] = []
    for entry in saved.get("m_TexEnvs", []) or []:
        if isinstance(entry, (list, tuple)):
            name, value = entry[0], entry[1]
        else:
            name, value = entry.get("first"), entry.get("second")
        if str(name) != "_MainTex":
            continue
        ref = (value or {}).get("m_Texture") or {}
        if ref.get("m_PathID") and not ref.get("m_FileID"):
            found.append(ref["m_PathID"])
    return found


def find_skeletons(bundle: Bundle) -> List[Dict[str, Any]]:

    results: List[Dict[str, Any]] = []
    for obj in bundle.of_type("MonoBehaviour"):
        tt = bundle.tt_of(obj)
        if not tt or "skeletonJSON" not in tt:
            continue
        name = str(tt.get("m_Name") or f"skeleton_{obj.path_id}")
        skeleton_bytes = _text_asset_bytes(bundle, tt.get("skeletonJSON") or {})
        skeleton_tt = bundle.pptr(tt.get("skeletonJSON") or {}) or {}
        atlases: List[Dict[str, Any]] = []
        for atlas_ref in tt.get("atlasAssets", []) or []:
            atlas_tt = bundle.pptr(atlas_ref or {})
            if not atlas_tt:
                continue
            atlas_bytes = _text_asset_bytes(bundle, atlas_tt.get("atlasFile") or {})
            atlas_name_tt = bundle.pptr(atlas_tt.get("atlasFile") or {}) or {}
            pages: List[int] = []
            for material_ref in atlas_tt.get("materials", []) or []:
                pages.extend(_material_main_textures(bundle, material_ref))
            atlases.append(
                {
                    "atlasAssetName": str(atlas_tt.get("m_Name") or ""),
                    "atlasFileName": str(atlas_name_tt.get("m_Name") or ""),
                    "atlasBytes": atlas_bytes,
                    "pageTexturePathIDs": pages,
                }
            )
        results.append(
            {
                "skeletonDataAssetName": name,
                "componentPathID": obj.path_id,
                "skeletonFileName": str(skeleton_tt.get("m_Name") or ""),
                "skeletonBytes": skeleton_bytes,
                "scale": tt.get("scale"),
                "defaultMix": tt.get("defaultMix"),
                "atlases": atlases,
            }
        )
    results.sort(key=lambda r: r["skeletonDataAssetName"])
    return results


_DIVIDE_LUT: Optional[List[bytes]] = None


def _divide_lut() -> List[bytes]:

    global _DIVIDE_LUT
    if _DIVIDE_LUT is None:
        tables: List[bytes] = []
        for alpha in range(256):
            if alpha == 0:

                tables.append(bytes(range(256)))
            else:
                tables.append(
                    bytes(min(255, (channel * 255 + alpha // 2) // alpha) for channel in range(256))
                )
        _DIVIDE_LUT = tables
    return _DIVIDE_LUT


def unpremultiply(image: Image.Image) -> Image.Image:

    if image.mode != "RGBA":
        image = image.convert("RGBA")
    data = bytearray(image.tobytes())
    lut = _divide_lut()
    for offset in range(0, len(data), 4):
        alpha = data[offset + 3]
        if alpha == 255 or alpha == 0:
            continue
        table = lut[alpha]
        data[offset] = table[data[offset]]
        data[offset + 1] = table[data[offset + 1]]
        data[offset + 2] = table[data[offset + 2]]
    return Image.frombytes("RGBA", image.size, bytes(data))


def export_skeleton(
    bundle: Bundle,
    skeleton: Dict[str, Any],
    out_dir: str,
    resize_pages: bool = True,
    unpack_parts: bool = False,
    keep_pma_parts: bool = False,
) -> Dict[str, Any]:

    os.makedirs(out_dir, exist_ok=True)
    report: Dict[str, Any] = {
        "skeletonDataAssetName": skeleton["skeletonDataAssetName"],
        "scale": skeleton.get("scale"),
        "defaultMix": skeleton.get("defaultMix"),
        "files": [],
        "atlases": [],
        "warnings": [],
    }

    skeleton_bytes = skeleton.get("skeletonBytes")
    if not skeleton_bytes:
        report["warnings"].append("skeletonJSON TextAsset missing or unreadable")
    else:
        base = skeleton.get("skeletonFileName") or skeleton["skeletonDataAssetName"]
        json_name = base if base.lower().endswith(".json") else f"{base}.json"
        json_name = _safe(json_name)
        with open(os.path.join(out_dir, json_name), "wb") as handle:
            handle.write(skeleton_bytes)
        report["files"].append(json_name)
        report.update(_skeleton_info(skeleton_bytes, report["warnings"]))

    for atlas in skeleton.get("atlases", []):
        report["atlases"].append(
            _export_atlas(
                bundle,
                atlas,
                out_dir,
                resize_pages=resize_pages,
                unpack_parts=unpack_parts,
                keep_pma_parts=keep_pma_parts,
                warnings=report["warnings"],
            )
        )
    return report


def _skeleton_info(raw: bytes, warnings: List[str]) -> Dict[str, Any]:
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception as exc:
        warnings.append(f"skeleton JSON did not parse ({exc}); written verbatim")
        return {"skeletonFormat": "unparsed"}
    header = data.get("skeleton") or {}
    animations = data.get("animations") or {}
    skins = data.get("skins")
    if isinstance(skins, list):
        skin_names = [s.get("name") for s in skins]
    elif isinstance(skins, dict):
        skin_names = list(skins.keys())
    else:
        skin_names = []
    return {
        "skeletonFormat": "json",
        "spineVersion": header.get("spine"),
        "boneCount": len(data.get("bones") or []),
        "slotCount": len(data.get("slots") or []),
        "skins": skin_names,
        "animations": sorted(animations.keys()),
        "animationCount": len(animations),
    }


def _export_atlas(
    bundle: Bundle,
    atlas: Dict[str, Any],
    out_dir: str,
    resize_pages: bool,
    unpack_parts: bool,
    keep_pma_parts: bool,
    warnings: List[str],
) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "atlasAssetName": atlas["atlasAssetName"],
        "pages": [],
    }
    atlas_bytes = atlas.get("atlasBytes")
    if not atlas_bytes:
        warnings.append(f"{atlas['atlasAssetName']}: atlasFile TextAsset missing")
        return result

    base = atlas.get("atlasFileName") or atlas["atlasAssetName"]
    atlas_name = base if base.lower().endswith(".atlas") else f"{base}.atlas"
    atlas_name = _safe(atlas_name)
    with open(os.path.join(out_dir, atlas_name), "wb") as handle:
        handle.write(atlas_bytes)
    result["atlasFile"] = atlas_name

    text = atlas_bytes.decode("utf-8", "replace")
    parsed = parse_atlas(text)
    result["pageCount"] = len(parsed)
    result["pma"] = parsed[0]["props"].get("pma") if parsed else None
    result["regionScale"] = parsed[0]["props"].get("scale") if parsed else None

    page_ids = atlas.get("pageTexturePathIDs") or []
    if len(page_ids) != len(parsed):
        warnings.append(
            f"{atlas['atlasAssetName']}: .atlas declares {len(parsed)} page(s) but "
            f"{len(page_ids)} page texture(s) resolved from the materials; pages are "
            "matched in order and any surplus is skipped"
        )

    for index, page in enumerate(parsed):
        page_record: Dict[str, Any] = {
            "index": index,
            "declaredFile": page["page"],
            "declaredSize": declared_page_size(page),
            "regionCount": len(page["regions"]),
        }
        if index >= len(page_ids):
            page_record["error"] = "no page texture resolved for this page"
            result["pages"].append(page_record)
            continue

        texture_path_id = page_ids[index]
        texture_tt = bundle.tt(texture_path_id) or {}
        obj = bundle.by_path_id.get(texture_path_id)
        if obj is None:
            page_record["error"] = "page texture object missing"
            result["pages"].append(page_record)
            continue
        try:
            image = obj.read().image
        except Exception as exc:
            page_record["error"] = f"page texture decode failed: {exc}"
            result["pages"].append(page_record)
            continue

        page_record["shippedSize"] = list(image.size)
        page_record["shippedFormat"] = texture_format_name(texture_tt.get("m_TextureFormat"))
        declared = page_record["declaredSize"]
        mismatch = bool(declared) and tuple(image.size) != tuple(declared)


        page_file = _safe(page["page"] or f"page_{index}.png")
        if not page_file.lower().endswith(".png"):
            page_file += ".png"
        image.save(os.path.join(out_dir, page_file))
        page_record["file"] = page_file


        cut_source = image
        page_record["resizedToDeclared"] = False
        if mismatch and resize_pages:
            cut_source = image.resize((declared[0], declared[1]), Image.LANCZOS)
            declared_file = f"{os.path.splitext(page_file)[0]}.declared-{declared[0]}x{declared[1]}.png"
            cut_source.save(os.path.join(out_dir, declared_file))
            page_record["declaredSizeFile"] = declared_file
            page_record["resizedToDeclared"] = True
        if mismatch:
            page_record["note"] = (
                "the shipped page size differs from the size declared in the "
                ".atlas (Unity power-of-two rescale at import). "
                + (
                    f"{page_record.get('declaredSizeFile')} is the declared-space "
                    "copy and is what regions were cut from."
                    if page_record["resizedToDeclared"]
                    else "--no-resize-pages was set, so regions were cut straight "
                    "from the shipped page and are geometrically shifted."
                )
            )

        if unpack_parts:
            page_record["parts"] = _unpack_page(
                cut_source, page, out_dir, keep_pma_parts=keep_pma_parts
            )
        result["pages"].append(page_record)

    return result


def _unpack_page(
    page_image: Image.Image,
    page: Dict[str, Any],
    out_dir: str,
    keep_pma_parts: bool,
) -> Dict[str, Any]:
    parts_dir = os.path.join(out_dir, "parts")
    os.makedirs(parts_dir, exist_ok=True)
    written: List[Dict[str, Any]] = []
    problems: List[str] = []
    page_w, page_h = page_image.size

    for region in page["regions"]:
        bounds = region_bounds(region)
        if not bounds:
            problems.append(f"{region['name']}: no bounds")
            continue
        x, y, width, height = bounds
        degrees = region_degrees(region)

        packed_w, packed_h = (height, width) if degrees == 90 else (width, height)
        if x < 0 or y < 0 or x + packed_w > page_w or y + packed_h > page_h:
            problems.append(
                f"{region['name']}: bounds ({x},{y},{width},{height}) rotate={degrees} "
                f"outside page {page_w}x{page_h}"
            )
            continue

        crop = page_image.crop((x, y, x + packed_w, y + packed_h))
        if degrees == 90:
            crop = crop.transpose(Image.ROTATE_270)
        elif degrees == 180:
            crop = crop.transpose(Image.ROTATE_180)
        elif degrees == 270:
            crop = crop.transpose(Image.ROTATE_90)
        elif degrees != 0:
            problems.append(f"{region['name']}: unsupported rotate={degrees}")
            continue
        if tuple(crop.size) != (width, height):
            problems.append(
                f"{region['name']}: restored size {crop.size} != declared "
                f"({width},{height}); not written"
            )
            continue
        if not keep_pma_parts:
            crop = unpremultiply(crop)
        filename = _safe(region["name"]) + ".png"
        crop.save(os.path.join(parts_dir, filename))
        written.append(
            {
                "region": region["name"],
                "file": f"parts/{filename}",
                "size": [width, height],
                "rotate": degrees,
            }
        )

    return {
        "dir": "parts",
        "count": len(written),
        "alphaMode": "premultiplied (as shipped)" if keep_pma_parts else "straight (un-premultiplied)",
        "regions": written,
        "problems": problems,
    }


def _safe(name: str) -> str:
    return "".join(c if (c.isalnum() or c in "._- ") else "_" for c in str(name)).strip() or "asset"
