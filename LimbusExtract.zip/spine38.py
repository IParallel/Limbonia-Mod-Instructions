from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple

RELEASES_URL = "https://github.com/wang606/SpineSkeletonDataConverter/releases"


IMAGE_ATTACHMENT_TYPES = {"region", "mesh"}


def _safe(name: str) -> str:

    return "".join(c if (c.isalnum() or c in "._- ") else "_" for c in str(name)).strip() or "asset"


def find_skeleton_dirs(root: str) -> List[str]:

    if os.path.isfile(root):
        root = os.path.dirname(root)
    root = os.path.abspath(root)
    if _skeleton_json_in(root):
        return [root]
    found: List[str] = []
    for current, dirs, _files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("parts", "images", "__pycache__", ".venv")]
        if _skeleton_json_in(current):
            found.append(current)
    return sorted(found)


def _skeleton_json_in(directory: str) -> Optional[str]:

    try:
        names = os.listdir(directory)
    except OSError:
        return None
    for name in sorted(names):
        if not name.lower().endswith(".json") or name == "spine.json":
            continue
        path = os.path.join(directory, name)
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                head = handle.read(2048)
        except OSError:
            continue
        if '"skeleton"' in head and '"spine"' in head:
            return path
    return None


def locate_tool(explicit: Optional[str], env_var: str, exe_name: str) -> Optional[str]:
    candidates: List[str] = []
    if explicit:
        candidates.append(explicit)
    if os.environ.get(env_var):
        candidates.append(os.environ[env_var])
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(os.path.join(here, "spine38-tools", exe_name))
    candidates.append(os.path.join(here, exe_name))
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return os.path.abspath(candidate)
    return shutil.which(exe_name)


def skeleton_version(data: Dict[str, Any]) -> str:
    return str((data.get("skeleton") or {}).get("spine") or "?")


def required_images(data: Dict[str, Any]) -> Dict[str, Optional[Tuple[int, int]]]:

    skins = data.get("skins")
    if isinstance(skins, dict):
        skin_list = [{"name": key, "attachments": value} for key, value in skins.items()]
    elif isinstance(skins, list):
        skin_list = skins
    else:
        skin_list = []

    wanted: Dict[str, Optional[Tuple[int, int]]] = {}
    for skin in skin_list:
        for _slot, attachments in (skin.get("attachments") or {}).items():
            for name, attachment in (attachments or {}).items():
                if not isinstance(attachment, dict):
                    continue
                if attachment.get("type", "region") not in IMAGE_ATTACHMENT_TYPES:
                    continue
                image = str(attachment.get("path") or name)
                width, height = attachment.get("width"), attachment.get("height")
                size = (round(width), round(height)) if width and height else None


                if size and (wanted.get(image) is None or size > wanted[image]):
                    wanted[image] = size
                else:
                    wanted.setdefault(image, size)
    return wanted


def atlas_scale(skeleton_dir: str) -> float:

    for name in sorted(os.listdir(skeleton_dir)):
        if not name.lower().endswith(".atlas"):
            continue
        with open(os.path.join(skeleton_dir, name), "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                key, _, value = line.strip().partition(":")
                if key.strip() == "scale":
                    try:
                        found = float(value)
                    except ValueError:
                        continue
                    if found > 0:
                        return found
    return 1.0


def convert_skeleton(converter: str, source: str, target: str, version: str) -> None:
    os.makedirs(os.path.dirname(target), exist_ok=True)
    result = subprocess.run(
        [converter, source, target, "-v", version],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0 or not os.path.isfile(target):
        detail = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"skeleton conversion failed ({result.returncode}): {detail}")


def build_images(
    skeleton_dir: str,
    out_dir: str,
    wanted: Dict[str, Optional[Tuple[int, int]]],
    scale_parts: bool,
) -> Tuple[int, List[str], int, Optional[str]]:

    parts_dir = os.path.join(skeleton_dir, "parts")
    if not os.path.isdir(parts_dir):
        raise RuntimeError(
            "no parts/ folder -- re-run the extraction with --unpack-parts, e.g.\n"
            "    limbus_extract.py spine <id> --out ./out --unpack-parts"
        )
    images_dir = os.path.join(out_dir, "images")
    os.makedirs(images_dir, exist_ok=True)

    resampler = None
    note: Optional[str] = None
    if scale_parts:
        try:
            from PIL import Image

            resampler = Image
        except ImportError:
            note = (
                "Pillow not installed, so parts were left at atlas pack scale -- region "
                "attachments will import small. Run this with the extractor's virtualenv."
            )

    fallback = 1.0 / atlas_scale(skeleton_dir)
    copied = 0
    resized = 0
    missing: List[str] = []
    for image, size in sorted(wanted.items()):
        source = os.path.join(parts_dir, _safe(image) + ".png")
        if not os.path.isfile(source):
            missing.append(image)
            continue
        target = os.path.join(images_dir, image + ".png")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if resampler is None:
            shutil.copyfile(source, target)
        else:
            with resampler.open(source) as handle:
                picture = handle.convert("RGBA")
                want = size or (
                    max(1, round(picture.width * fallback)),
                    max(1, round(picture.height * fallback)),
                )
                if want != picture.size:
                    picture = picture.resize(want, resampler.LANCZOS)
                    resized += 1
                picture.save(target)
        copied += 1
    return copied, missing, resized, note


def convert_atlas(atlas_converter: str, skeleton_dir: str, out_dir: str) -> List[str]:

    written: List[str] = []
    for name in sorted(os.listdir(skeleton_dir)):
        if not name.lower().endswith(".atlas"):
            continue
        staged = os.path.join(out_dir, "_atlas-src")
        os.makedirs(staged, exist_ok=True)
        shutil.copyfile(os.path.join(skeleton_dir, name), os.path.join(staged, name))


        for page in _pages_for(skeleton_dir, name):
            shutil.copyfile(page[0], os.path.join(staged, page[1]))
        result = subprocess.run(
            [atlas_converter, os.path.join(staged, name), os.path.join(out_dir, "atlas")],
            capture_output=True,
            text=True,
        )
        shutil.rmtree(staged, ignore_errors=True)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            raise RuntimeError(f"atlas conversion failed ({result.returncode}): {detail}")
        written.append(name)
    return written


def _pages_for(skeleton_dir: str, atlas_name: str) -> List[Tuple[str, str]]:

    pages: List[Tuple[str, str]] = []
    with open(os.path.join(skeleton_dir, atlas_name), "r", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    expect_name = True
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line:
            expect_name = True
            continue
        if expect_name:
            expect_name = False
            if not line.lower().endswith(".png"):
                continue
            stem = os.path.splitext(line)[0]
            declared = [
                f
                for f in os.listdir(skeleton_dir)
                if f.startswith(stem + ".declared-") and f.lower().endswith(".png")
            ]
            source = os.path.join(skeleton_dir, declared[0] if declared else line)
            if os.path.isfile(source):
                pages.append((source, line))
        elif ":" not in line:
            expect_name = False
    return pages


def process(skeleton_dir: str, out_root: str, args: argparse.Namespace, converter: str) -> bool:
    source_json = _skeleton_json_in(skeleton_dir)
    if not source_json:
        return False
    name = os.path.splitext(os.path.basename(source_json))[0]
    out_dir = os.path.join(out_root, os.path.basename(skeleton_dir))
    target_json = os.path.join(out_dir, os.path.basename(source_json))

    with open(source_json, "r", encoding="utf-8", errors="replace") as handle:
        original = json.load(handle)

    print(f"{name}  (Spine {skeleton_version(original)} -> {args.spine_version})")
    if os.path.exists(out_dir) and not args.force:
        print(f"  SKIPPED: {out_dir} exists (use --force to overwrite)\n")
        return False
    shutil.rmtree(out_dir, ignore_errors=True)

    convert_skeleton(converter, source_json, target_json, args.spine_version)
    with open(target_json, "r", encoding="utf-8", errors="replace") as handle:
        converted = json.load(handle)
    print(f"  skeleton  -> {os.path.relpath(target_json, out_root)} "
          f"(now {skeleton_version(converted)})")

    wanted = required_images(converted) or required_images(original)
    copied, missing, resized, note = build_images(
        skeleton_dir, out_dir, wanted, scale_parts=not args.no_scale_parts
    )
    detail = f", {resized} resized to declared size" if resized else ""
    print(f"  images    -> images/ ({copied}/{len(wanted)} attachment images{detail})")
    if note:
        print(f"  WARNING: {note}")
    if missing:
        print(f"  WARNING: {len(missing)} image(s) not in parts/: {', '.join(sorted(missing)[:8])}"
              + (" ..." if len(missing) > 8 else ""))

    if args.atlas:
        atlas_converter = locate_tool(
            args.atlas_converter, "SPINE_ATLAS_CONVERTER", "SpineAtlasDowngrade.exe"
        )
        if not atlas_converter:
            print(f"  WARNING: SpineAtlasDowngrade.exe not found; skipping --atlas ({RELEASES_URL})")
        else:
            for written in convert_atlas(atlas_converter, skeleton_dir, out_dir):
                print(f"  atlas     -> atlas/ (from {written})")

    print()
    return True


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Convert extracted Limbus Spine rigs (4.0.64) for an older Spine Editor.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="example:\n"
        "  python spine38.py out --out ./spine38\n"
        "  python spine38.py out/10916_Rodion_Thumb_FatherAppearance --spine-version 3.8.99",
    )
    parser.add_argument(
        "path",
        help="an extracted *_SkeletonData folder, an appearance folder, or the out/ root "
        "(searched recursively)",
    )
    parser.add_argument("--out", default="./spine38", help="output root (default: ./spine38)")
    parser.add_argument(
        "--spine-version",
        default="3.8.99",
        help="target version, complete x.y.z (default: 3.8.99)",
    )
    parser.add_argument("--converter", help="path to SpineSkeletonDataConverter.exe")
    parser.add_argument(
        "--no-scale-parts",
        action="store_true",
        help="keep parts at the atlas pack scale instead of resizing them to the size the "
        "skeleton declares (region attachments will then import at a fraction of their size)",
    )
    parser.add_argument(
        "--atlas",
        action="store_true",
        help="also emit a 3.8-format .atlas and rescaled page (for a runtime; the Editor "
        "does not need it)",
    )
    parser.add_argument("--atlas-converter", help="path to SpineAtlasDowngrade.exe")
    parser.add_argument("--force", action="store_true", help="overwrite existing output")
    args = parser.parse_args(argv)

    converter = locate_tool(args.converter, "SPINE_CONVERTER", "SpineSkeletonDataConverter.exe")
    if not converter:
        print(
            "SpineSkeletonDataConverter.exe not found.\n"
            f"Download it from {RELEASES_URL} and either pass --converter <path>, set "
            "SPINE_CONVERTER, or drop it in spine38-tools/ next to this script.",
            file=sys.stderr,
        )
        return 2

    skeleton_dirs = find_skeleton_dirs(args.path)
    if not skeleton_dirs:
        print(
            f"no extracted skeletons under {args.path!r}. Extract some first:\n"
            "    limbus_extract.py spine <appearance-id> --out ./out --unpack-parts",
            file=sys.stderr,
        )
        return 1

    out_root = os.path.abspath(args.out)
    os.makedirs(out_root, exist_ok=True)
    print(f"converter: {converter}")
    print(f"found {len(skeleton_dirs)} skeleton(s)\n")

    done = 0
    for skeleton_dir in skeleton_dirs:
        try:
            done += 1 if process(skeleton_dir, out_root, args, converter) else 0
        except RuntimeError as exc:
            print(f"  ERROR: {exc}\n", file=sys.stderr)

    print(f"{done}/{len(skeleton_dirs)} written to {out_root}")
    if done:
        print(
            "\nIn the Spine Editor: Import Data -> pick the .json, UNCHECK 'New Project',\n"
            "then set the images path to that skeleton's images/ folder."
        )
    return 0 if done else 1


if __name__ == "__main__":
    raise SystemExit(main())
