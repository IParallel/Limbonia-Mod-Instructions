"""Bounded, read-only game-prefab preview bridge used by the companion.

Unlike an image list, each frame here is an occurrence in the selected coin's
Timeline, including the drawing already held when a clip is trimmed.
"""
from __future__ import annotations

import argparse
import base64
import contextlib
import io
import json
import math
import sys

from PIL import Image

from limbusx.clips import read_flipbook
from limbusx.appearance import animator_clip_ids
from limbusx.extract import open_appearance
from limbusx.hierarchy import build_path_table, resolve_binding_path
from limbusx.images import SpriteExporter, _render_data_key
from limbusx.locate import BundleIndex, find_cache_dir
from limbusx.timeline import read_timeline

MAX_IMAGE_BYTES = 4 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_FRAMES = 1200
EPSILON = 0.00001


def frame_spans(keys, start, duration, clip_in, speed):
    """Intersect source key holds with a Timeline clip; never infer FPS."""
    end = clip_in + duration * speed
    for i, key in enumerate(keys):
        lo = max(clip_in, float(key['time']))
        hi = min(end, float(keys[i + 1]['time']) if i + 1 < len(keys) else end)
        if hi - lo <= EPSILON:
            continue
        yield start + (lo - clip_in) / speed, (hi - lo) / speed, key


def sprite_image(bundle, exporter, path_id, black_background=False):
    sprite = bundle.tt(path_id)
    if not sprite:
        raise ValueError('A sprite reference could not be resolved in this bundle.')
    rect, pivot = sprite.get('m_Rect') or {}, sprite.get('m_Pivot') or {}
    width, height = round(rect.get('width', 0)), round(rect.get('height', 0))
    ppu = float(sprite.get('m_PixelsToUnits') or 0)
    if not (0 < width <= 4096 and 0 < height <= 4096 and math.isfinite(ppu) and ppu > 0):
        raise ValueError('A sprite has unsupported dimensions or pixels-per-unit.')
    # UnityPy decodes the sprite mesh/atlas packing, including tight-packed alpha.
    # Restore its untrimmed rect so the sprite pivot matches the game exactly.
    cropped = bundle.by_path_id[path_id].read().image.convert('RGBA')
    if black_background:
        from limbusx.mang_preview import effect_alpha
        cropped = effect_alpha(cropped)
    rd = sprite.get('m_RD') or {}
    atlas = exporter._atlas().get(_render_data_key(sprite.get('m_RenderDataKey')))
    if atlas:
        rd = atlas[1]
    offset = rd.get('textureRectOffset') or {}
    x, y = round(offset.get('x', 0)), round(offset.get('y', 0))
    if x < 0 or y < 0 or x + cropped.width > width or y + cropped.height > height:
        raise ValueError('The packed sprite cannot be restored to its original rectangle.')
    canvas = Image.new('RGBA', (width, height))
    canvas.paste(cropped, (x, height - y - cropped.height))
    output = io.BytesIO()
    canvas.save(output, format='PNG')
    data = output.getvalue()
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError('A preview image exceeds the 4 MB limit.')
    return dict(image='data:image/png;base64,' + base64.b64encode(data).decode('ascii'),
                width=width, height=height, pivotX=float(pivot.get('x', .5)) * width,
                pivotY=float(pivot.get('y', .5)) * height, pixelsPerUnit=ppu,
                visible=True)


def export_pose_preview(bundle, appearance, label, motion, spine=False):
    # Only inspect clips belonging to this appearance's Animator, never other bundle residents.
    target = 'Default' if spine else motion
    clips = [bundle.tt(i) for i in animator_clip_ids(bundle, appearance)]
    clips = [c for c in clips if c and c.get('m_Name', '').lower().endswith('_' + target.lower())]
    if len(clips) != 1:
        raise ValueError('No unique sprite pose clip was found for this motion.')
    flip = read_flipbook(clips[0])
    if not flip or len(flip['layers']) != 1:
        raise ValueError('This pose needs a composite character preview.')
    layer = flip['layers'][0]
    path = resolve_binding_path(build_path_table(bundle, appearance.tt), layer['bindingPath'])
    if not path:
        raise ValueError('The pose sprite renderer could not be resolved.')
    duration = max(float(flip.get('stopTime') or 0), 1 / 60)
    if spine:
        duration = 1.0
    keys = layer['frames'][:1] if spine else layer['frames']
    exporter, images, frames, total = SpriteExporter(bundle), {}, [], 0
    for time, span, key in frame_spans(keys, 0, duration, 0, 1):
        sprite = key.get('spritePathID')
        if key.get('spriteFileID') or not sprite:
            raise ValueError('The pose sprite is unavailable in this bundle.')
        if sprite not in images:
            images[sprite] = sprite_image(bundle, exporter, sprite)
            total += len(images[sprite]['image'])
            if total > MAX_TOTAL_BYTES:
                raise ValueError('This pose exceeds the preview image budget.')
        frames.append({**images[sprite], 'time': time, 'duration': span})
        if len(frames) > MAX_FRAMES:
            raise ValueError('This pose exceeds the preview frame limit.')
    return dict(version=1, duration=duration, spritePath=path, frames=frames,
                source='game', appearance=appearance.name, bundle=label,
                referenceOnly=spine,
                note='Standing reference; this motion uses a Spine rig.' if spine else '')


def export_preview(game_dir, appearance_id, motion, coin):
    bundle, appearance, label = open_appearance(BundleIndex(game_dir, find_cache_dir()), appearance_id)
    slots = [s for s in appearance.slots() if s['motionName'] == motion]
    if len(slots) != 1:
        raise ValueError('This appearance has no unique motion with that name.')
    slot = slots[0]
    if slot['isSpineAnim'] or not slot['coins']:
        return export_pose_preview(bundle, appearance, label, motion, slot['isSpineAnim'])
    if not 0 <= coin < len(slot['coins']):
        raise ValueError('This motion has no Timeline for that coin.')
    ref = slot['coins'][coin]
    if ref.get('timelineFileID'):
        raise ValueError('This Timeline is in another bundle; cross-bundle previews are not supported yet.')
    timeline = read_timeline(bundle, ref['timelinePathID'])
    if not timeline:
        raise ValueError('The coin Timeline could not be decoded.')
    duration = float(timeline.get('duration') or 0)
    paths = build_path_table(bundle, appearance.tt)
    segments, renderer_path, track_id = [], None, None
    for track in timeline['tracks']:
        if track.get('mutedInHierarchy'):
            continue
        for segment in track.get('clips', []):
            if not segment.get('animationClipPathID'):
                continue
            clip = bundle.tt(segment['animationClipPathID'])
            muscle = (clip or {}).get('m_MuscleClip') or {}
            clip_data = (muscle.get('m_Clip') or {}).get('data') or muscle.get('m_Clip') or {}
            dense = clip_data.get('m_DenseClip') or {}
            if dense.get('m_CurveCount') and not dense.get('m_SampleRate'):
                raise ValueError('A dense animation curve has no sample rate; preview timing cannot be recovered.')
            flip = read_flipbook(clip or {})
            if not flip or not flip['layers']:
                continue
            if len(flip['layers']) != 1:
                raise ValueError('This motion animates several sprite layers; composite previews are not supported yet.')
            layer = flip['layers'][0]
            if any('outside pptrCurveMapping' in warning for warning in flip.get('warnings', [])):
                raise ValueError('The sprite key mapping is incomplete; preview timing cannot be recovered safely.')
            path = resolve_binding_path(paths, layer['bindingPath'])
            if not path:
                raise ValueError('The animated sprite renderer path could not be resolved.')
            if renderer_path not in (None, path) or track_id not in (None, track['trackPathID']):
                raise ValueError('This coin has several drawing tracks; a composite preview is needed.')
            renderer_path, track_id = path, track['trackPathID']
            start = float(segment['start'] or 0)
            length = float(segment['duration'] or 0)
            clip_in = float(segment['clipIn'] or 0)
            speed = float(segment['timeScale'] or 1)
            stop = float(flip.get('stopTime') or 0)
            if speed <= 0 or length <= 0:
                raise ValueError('Reverse or zero-length drawing clips are not supported yet.')
            # Non-looping clips keep their final drawing when Timeline extends past the source.
            # Parrying's last variant deliberately trims into an attack's tail and holds it.
            loops = int(segment.get('loop') or 0) == 1 or (int(segment.get('loop') or 0) == 0 and bool(muscle.get('m_LoopTime')))
            if loops and clip_in + length * speed > stop + EPSILON:
                raise ValueError('This drawing extends beyond its source clip; looping previews are not supported yet.')
            if any(int(segment.get(key) or 0) not in (0, 1) for key in ('preExtrapolationMode', 'postExtrapolationMode')):
                raise ValueError('Loop, ping-pong and continued drawing extrapolation are not supported yet.')
            segments.append((start, length, segment, list(frame_spans(layer['frames'], start, length, clip_in, speed))))
    if not segments:
        raise ValueError('No sprite drawing curve was found in this coin Timeline.')
    segments.sort(key=lambda item: item[0])
    frames, images, total, previous_end = [], {}, 0, 0.0
    exporter = SpriteExporter(bundle)
    blank = dict(visible=False, width=0, height=0, pivotX=0, pivotY=0, pixelsPerUnit=100)
    for start, length, segment, spans in segments:
        if start < previous_end - EPSILON:
            raise ValueError('Overlapping drawing clips need a blended preview and are not supported yet.')
        if not spans:
            raise ValueError('A drawing clip has no recoverable sprite key holds.')
        if spans[0][0] > start + EPSILON:
            raise ValueError('A drawing clip starts before its first sprite key; its default sprite cannot be inferred.')
        if start > previous_end + EPSILON:
            if frames and previous_post == 1:
                held = frames[-1]
            elif int(segment.get('preExtrapolationMode') or 0) == 1:
                first = spans[0][2]
                first_id = first.get('spritePathID')
                if first.get('spriteFileID'):
                    raise ValueError('A drawing references a sprite in another bundle.')
                if first_id and first_id not in images:
                    images[first_id] = sprite_image(bundle, exporter, first_id)
                    total += len(images[first_id]['image'])
                held = images[first_id] if first_id else blank
            else:
                held = blank
            frames.append({**held, 'time': previous_end, 'duration': start - previous_end})
        for time, span, key in spans:
            path_id = key.get('spritePathID')
            if key.get('spriteFileID'):
                raise ValueError('A drawing references a sprite in another bundle.')
            if path_id and path_id not in images:
                images[path_id] = sprite_image(bundle, exporter, path_id)
                total += len(images[path_id]['image'])
                if total > MAX_TOTAL_BYTES:
                    raise ValueError('This preview exceeds the 16 MB image budget.')
            frames.append({**(images[path_id] if path_id else blank), 'time': round(time, 6), 'duration': round(span, 6)})
        previous_end, previous_post = start + length, int(segment.get('postExtrapolationMode') or 0)
    if previous_end < duration - EPSILON:
        held = frames[-1] if previous_post == 1 else blank
        frames.append({**held, 'time': previous_end, 'duration': duration - previous_end})
    if len(frames) > MAX_FRAMES:
        raise ValueError('This preview exceeds the 1,200 frame limit.')
    return dict(version=1, duration=duration, spritePath=renderer_path, frames=frames,
                source='game', appearance=appearance.name, bundle=label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--game-dir', required=True)
    parser.add_argument('--appearance', required=True)
    parser.add_argument('--motion')
    parser.add_argument('--coin', type=int)
    parser.add_argument('--mang-controller', type=int)
    parser.add_argument('--list-motions', action='store_true')
    args = parser.parse_args()
    try:
        # Libraries may print asset-version diagnostics; stdout is JSON only.
        with contextlib.redirect_stdout(sys.stderr):
            if args.list_motions:
                _, appearance, _ = open_appearance(BundleIndex(args.game_dir, find_cache_dir()), args.appearance)
                preview = dict(motions=[dict(motion=s['motionName'], coins=s['coinCount'], spine=s['isSpineAnim']) for s in appearance.slots()])
            elif args.mang_controller is not None:
                from limbusx.mang_preview import export_mang_artwork
                bundle, appearance, _ = open_appearance(BundleIndex(args.game_dir, find_cache_dir()), args.appearance)
                preview = export_mang_artwork(bundle, appearance, args.mang_controller, sprite_image, SpriteExporter(bundle))
            else:
                preview = export_preview(args.game_dir, args.appearance, args.motion, args.coin)
        result = dict(ok=True, preview=preview)
    except Exception as exc:
        result = dict(ok=False, error=str(exc)[:1500])
    encoded = json.dumps(result, ensure_ascii=True, separators=(',', ':'))
    if len(encoded) > 24 * 1024 * 1024:
        encoded = json.dumps(dict(ok=False, error='This preview exceeds the 24 MB response limit.'))
    sys.stdout.write(encoded)


if __name__ == '__main__':
    main()
