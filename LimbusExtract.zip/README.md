# LimbusExtract

Extract Limbus Company sprites and Spine skeletons from locally downloaded game
AssetBundles. Runs offline with Python; the game does not need to be running.

This guide covers two different results:

- **Sprite frames:** individual PNG drawings from a character's battle animations.
- **An editable Spine 3.8 project:** extract a Spine rig, convert its data to 3.8,
  import it in the Spine editor, and save a `.spine` file.

## 1. Set up the tool

Requirements:

- Windows and Python 3.9 or newer.
- An installed copy of Limbus Company and the downloaded content you want to extract.
- For the Spine project workflow: Spine Editor **3.8.99**, with saving enabled,
  and `SpineSkeletonDataConverter.exe` for the data conversion.

Open PowerShell in the folder containing `limbus_extract.py`, `spine38.py`, and
`requirements.txt`. All commands below run from that folder:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

No virtual environment activation is required. The commands use its Python directly.
Keep the pinned UnityPy version in `requirements.txt`; newer versions change its API.

The tool tries known game installation paths and the current user's cache at:

```text
%USERPROFILE%\AppData\LocalLow\Unity\ProjectMoon_LimbusCompany
```

For a different installation or cache location, add these options to the extraction
or listing command (replace the example paths with your actual folders):

```powershell
.\.venv\Scripts\python.exe limbus_extract.py list 10916 --game-dir "D:\SteamLibrary\steamapps\common\Limbus Company" --cache-dir "C:\Users\YourName\AppData\LocalLow\Unity\ProjectMoon_LimbusCompany"
```

The game folder is the folder containing `LimbusCompany.exe`. The cache folder is
`ProjectMoon_LimbusCompany`, not one of its hash-named subfolders. Extraction does
not download missing bundles; first download the relevant content through the game.

## 2. Find the appearance

Search by name or number, then inspect the appearance you want:

```powershell
.\.venv\Scripts\python.exe limbus_extract.py list --find Rodion
.\.venv\Scripts\python.exe limbus_extract.py list --find 10916
.\.venv\Scripts\python.exe limbus_extract.py list 10916
```

Use the **appearance ID**, which can differ from a unit ID. Search results indicate
whether its bundle is on disk. The appearance catalogue identifies the bundle;
you do not need to find or rename cached files manually.

### Choose the right extraction

| Asset you want | Command | What you get |
|---|---|---|
| Sinner battle attacks | `motion` | Hand-drawn sprite frames and timeline metadata |
| Sinner battle idle | `spine` | A skeletal rig, usually with one animation |
| Animated identity illustration | `spine` | A separate illustration rig, when present |
| Enemy or abnormality | Inspect with `list`, then use `motion` and/or `spine` | Depends on how that appearance was authored |

**A sinner's attack frames are not a Spine skeleton.** Extracting its idle rig does
not recover the hand-drawn attacks as skeletal animations. PNGs alone contain no
bones, weights, or animation keys.

## 3. Extract sprite frames

For all available sprite motions and unlinked pose clips:

```powershell
.\.venv\Scripts\python.exe limbus_extract.py motion 10916 --out .\out --no-sidecars --strict
```

`--no-sidecars` leaves out optional timing sidecar files; PNGs and the complete
`appearance.json` manifest are still written. `--strict` returns a failure exit
code when extraction reports errors. Check the printed warnings as well.

Example output:

```text
out/
  10916_Rodion_Thumb_FatherAppearance/
    appearance.json
    sprites/
      skill1_1.png
      ...
      index.json
```

Open the PNGs in `sprites/` to view or edit the drawings. They are unique images,
not a numbered movie: repeated animation frames may reuse the same file.

For frame order and timing, read `appearance.json`:

- `motions` -> the desired `motionName` -> `coins` -> `layers` -> `frames`.
  Each frame's `file` points to its PNG relative to the appearance folder.
- `time` is seconds on that coin's timeline; `clipTime` is source clip time.
  `animationSegments` records the clip slices and playback speed.
- Each active layer is a separate simultaneous sprite sequence. `frames` at the
  coin level is an alias of one layer, not a combined animation.
- `unlinkedSpriteClips.clips` contains sprite clips without coin timelines,
  including available Animator-driven poses such as Move, Guard, and Damaged.
- `sprites/index.json` records each PNG's source Sprite ID, dimensions, pivot,
  pixels per unit (`ppu`), and whether extraction was lossless.

Use `file` or `spritePathID` to identify artwork. Sprite names can repeat with
different drawings and pivots; duplicate filenames receive an ID suffix.
Motion slots are authoritative: source clip names can disagree with the slot.
Muted tracks appear separately in `inactiveLayers` / `inactiveTracks` and should
not be played alongside active layers. Atlas-derived art can retain compression
artifacts; extraction cannot recover an uncompressed original that was not shipped.

To extract only a particular motion, use the names shown by `list`:

```powershell
.\.venv\Scripts\python.exe limbus_extract.py motion 10916 --motion S1 --out .\out-s1 --no-sidecars --strict
```

Use the full extraction when you also need unlinked pose clips; filtering by motion
omits that collection.

## 4. Extract the Spine rig and its individual images

```powershell
.\.venv\Scripts\python.exe limbus_extract.py spine 10916 --out .\out --unpack-parts --strict
```

**Keep `--unpack-parts`.** It produces the separate images needed by the editor
workflow. Leave `--keep-pma` and `--no-resize-pages` off for this workflow.

The console lists each rig's name, original Spine version, and animation names.
The game data inspected by this tool uses Spine 4.0.x, predominantly 4.0.64;
that data needs conversion before importing into 3.8.

```text
out/<appearance>/spine/
  spine.json                       extraction report, NOT skeleton data
  <rig-folder>/
    <skeleton>.json                skeleton data
    <atlas>.atlas                  packed region metadata
    <page>.png                     atlas texture page(s)
    parts/
      <region>.png                 unpacked images for editing
```

Actual names come from the bundle. There may be separate idle and illustration
folders. Inspect `spine.json` and the console's animation list to choose the rig.
An appearance extraction skips rigs owned by neighbouring appearances in shared
bundles, though unclaimed rigs can also be exported.

## 5. Prepare that rig for Spine 3.8.99

`spine38.py` prepares import files; the editor creates the final `.spine` project.
It requires `SpineSkeletonDataConverter.exe` as an external conversion dependency.
Obtain that executable from its publisher's release download, then place it here:

```text
LimbusExtract/
  spine38.py
  spine38-tools/
    SpineSkeletonDataConverter.exe
```

Alternatively, pass its full path with `--converter`, as shown below. The helper
does not download it automatically. Its publisher's release address is printed
if you run the helper without the executable installed.

Convert the extracted appearance (replace the folder if you chose another ID):

```powershell
.\.venv\Scripts\python.exe spine38.py .\out\10916_Rodion_Thumb_FatherAppearance --out .\spine38 --spine-version 3.8.99
```

Or specify the converter location explicitly:

```powershell
.\.venv\Scripts\python.exe spine38.py .\out\10916_Rodion_Thumb_FatherAppearance --out .\spine38 --spine-version 3.8.99 --converter "C:\Tools\SpineSkeletonDataConverter.exe"
```

An appearance folder is searched recursively, so each extracted rig gets its own
output folder. You can instead pass one `<rig-folder>` to convert only that rig.
Use a separate output root for each appearance: output uses the rig folder's name,
and different appearances can have the same rig names. Keep output outside the
extraction folder to avoid finding converted files in a later recursive run.

```text
spine38/<rig-folder>/
  <skeleton>.json                   converted 3.8.99 skeleton
  images/
    ...                            images under their attachment paths
```

Check that the console reports `now 3.8.99`, all required attachment images were
written, and no missing-image or Pillow warnings occurred. A successful process
exit alone does not establish that every rig and every image converted.

The helper restores attachment subfolders and resizes images to the dimensions
the skeleton expects. Copying `parts/` directly can leave missing attachments or
small region images. Leave `--no-scale-parts` off. Upscaling restores expected
size, not additional image detail. `--atlas` is optional runtime output and is
unnecessary for creating an editor project.

Existing output folders are skipped. Prefer a fresh output directory for a rerun.
`--force` **deletes and rebuilds each matching rig output folder**, including any
`.spine` files or edits you saved there. Back up edited projects before using it.

**Conversion from 4.0 to 3.8 is approximate.** Curves, rotations, and path spacing
can change. Do not just edit the JSON's version string: the data formats differ.

## 6. Create and save the project in Spine 3.8

Use Spine Editor **3.8.99** for the commands above. If using another 3.8 patch,
match `--spine-version` to its complete version and check the conversion result.

1. Start Spine and confirm the editor version is 3.8.99.
2. Create a blank project from the main menu.
3. Choose **Import Data** from the main menu. Select the converted
   `spine38/<rig-folder>/<skeleton>.json`.
4. Set import **Scale** to **1**. Uncheck **New project**, choose **Create a new
   skeleton**, give it a name, and import. This imports a complete skeleton into
   the blank project. Avoid **Import into an existing skeleton** for this first
   import, since that mode does not import animations.
5. Switch to **Setup** mode. In the Tree, select the imported skeleton's
   **Images** node. Set its path using **Browse** to the absolute path of
   `spine38/<rig-folder>/images/`. This replaces any original author's image path
   retained in the JSON.
6. Confirm the art appears. Select an appropriate skin if the rig uses skins.
   Switch to **Animate**, select an imported animation, and play it. Check image
   alignment, region sizes, meshes, and missing-image indicators.
7. Choose **Save As** and save an editable file such as `Character.spine`.
   Prefer a separate working folder, and copy the prepared `images/` folder
   alongside it. Point the Images node at that copied folder; after saving, a
   relative path of `./images/` makes the project portable. Save again.
8. Reopen the saved `.spine` file and check the images and animation once more.

Result:

```text
MyCharacter/
  Character.spine
  images/
    ...
```

Keep both the `.spine` file and its images when moving or sharing the project.
The extracted JSON is runtime skeleton data, not the original authoring project;
a reconstructed project may lack editor-only information that was never exported.

The editor's import modes and image lookup rules are described in the official
[Import guide](https://en.esotericsoftware.com/spine-import) and
[Images guide](https://us.esotericsoftware.com/spine-images).

### If you only have attack-frame PNGs

To author a new Spine 3.8 project from the `motion` output, create a blank project,
set its Images path to `sprites/`, and drag a desired image onto a bone in Setup
mode to create an attachment. For a flipbook, put successive drawings as
attachments in the same slot and key attachment changes in Animate mode using
the manifest's frame times. Use separate slots for simultaneous layers and align
each drawing using its recorded pivot. This is manual authoring: the tool does
not generate a Spine rig or animation from sprite motion manifests. To make a
skeletal character instead, separate the drawing into movable parts and rig them.

## Troubleshooting

| Symptom | What to check |
|---|---|
| Appearance not found | Search with `list --find`; use an appearance ID rather than assuming a unit ID. |
| Bundle not downloaded | Load/download the relevant content in the game, then retry. |
| Game or cache not found | Supply `--game-dir` and `--cache-dir` with your real paths. |
| No `parts/` folder | Repeat `spine` extraction with `--unpack-parts`. |
| Converter not found | Put the executable in `spine38-tools/` or use `--converter`. |
| Spine rejects the JSON version | Import the converted JSON, confirm `now 3.8.99`, and match the editor version. |
| Bones visible but artwork missing | Select Images in Setup and point to that converted rig's `images/`, preserving its subfolders. |
| Head or accessories much smaller than meshes | Reconvert with Pillow installed in the virtual environment and without `--no-scale-parts`. |
| Dark image edges | Extract parts without `--keep-pma`; packed atlas pages retain premultiplied alpha. |
| Only idle exists | The attacks may be sprite flipbooks; inspect `motion` output. |
| Conversion says SKIPPED | The output rig folder already exists; choose a fresh output root. |
| Animation differs from the game | Downgrading can alter animation behavior; retain the original 4.0 extraction for comparison. |

## Other commands and checks

```powershell
.\.venv\Scripts\python.exe limbus_extract.py --help
.\.venv\Scripts\python.exe limbus_extract.py spine --help
.\.venv\Scripts\python.exe spine38.py --help
.\.venv\Scripts\python.exe limbus_extract.py verify --out .\verify-out --unpack-parts
```

`verify` checks known appearances, timing, sprite references, PNGs, and atlas
handling. It needs the corresponding game bundles locally. It does not validate
the external converter or the saved project inside Spine; do the editor checks
in step 6 as well.

| Command | Additional use |
|---|---|
| `list --grep <regex>` | Search catalogue bundle names. |
| `list --bundle <name-or-file> --container` | Inspect a bundle's asset paths. |
| `spine --bundle <name-or-file> --out .\out --unpack-parts` | Extract all candidate rigs in a specific bundle. |
| `spine <id> --skeleton <text>` | Filter skeletons by matching name text. |
| `vfx <id> --out .\out --textures` | Export an effects catalogue and referenced textures; does not recreate usable effect prefabs or shader source. |
| `index --filter <regex>` | Scan selected cached bundles into an asset-path index. |
